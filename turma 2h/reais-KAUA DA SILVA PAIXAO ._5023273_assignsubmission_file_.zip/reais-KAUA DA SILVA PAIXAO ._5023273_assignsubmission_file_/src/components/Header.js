import React from 'react';

function Header() {
  return (
    <header>
        <img src="/images/logo-mackenzie.png" alt="Logo do Mackenzie" />
    </header>
  );
}

export default Header;
