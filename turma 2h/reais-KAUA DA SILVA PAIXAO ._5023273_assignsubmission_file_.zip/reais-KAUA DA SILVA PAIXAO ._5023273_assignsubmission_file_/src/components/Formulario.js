import React from 'react';

function Formulario({
  escola,
  setEscola,
  renda,
  setRenda,
  escolaNome,
  setEscolaNome,
  calcularBolsa,
  porcentagemBolsa,
  resultadoVisivel,
}) {
  return (
    <form>
      <p>Você se formou em escola:</p>
      <label>
        <input
          type="radio"
          name="escola"
          value="publica"
          onChange={() => setEscola('publica')}
        />
        Pública
      </label>
      <label>
        <input
          type="radio"
          name="escola"
          value="particular"
          onChange={() => setEscola('particular')}
        />
        Particular
      </label>

      {escola === 'particular' && (
        <div>
          <p>Qual a renda mensal do seu responsável?</p>
          <input
            type="text"
            id="renda"
            name="renda"
            placeholder="Digite a renda em reais"
            value={renda}
            onChange={(e) => setRenda(e.target.value)}
          />
        </div>
      )}

      {escola === 'publica' && (
        <div>
          <p>Em qual escola você cursou o Ensino Médio?</p>
          <input
            type="text"
            id="escola-publica"
            name="escola-publica"
            placeholder="Nome da escola"
            value={escolaNome}
            onChange={(e) => setEscolaNome(e.target.value)}
          />
        </div>
      )}

      <br />
      <button type="button" onClick={calcularBolsa}>
        Calcular Bolsa
      </button>
      <br />

      {resultadoVisivel && (
        <div>
          <p>
            Ótimo! Você consegue um desconto de até{' '}
            <span id="porcentagem-bolsa">{porcentagemBolsa}</span>%. Agende
            sua prova aqui:
          </p>
          <input type="date" id="data-agendamento" />
        </div>
      )}
    </form>
  );
}

export default Formulario;
