import React from 'react';

function Rodape() {
  return (
    <footer>
      <p>
        Para aumentar a porcentagem de bolsa, você deverá realizar uma prova
        avaliativa para análise.
      </p>
    </footer>
  );
}

export default Rodape;
