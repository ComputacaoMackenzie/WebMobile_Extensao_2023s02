import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UniversityInfoComponent = () => {
  const [universities, setUniversities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://universities.hipolabs.com/search?country=United States');

        setUniversities(response.data);
        setLoading(false);
      } catch (error) {
        console.error('Erro ao obter informações sobre universidades:', error);
        setError('Erro ao obter informações sobre universidades. Tente novamente mais tarde.');
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <h2>Informações sobre Universidades:</h2>
      {loading ? (
        <p>Carregando informações sobre universidades...</p>
      ) : error ? (
        <p>{error}</p>
      ) : universities.length > 0 ? (
        <ul>
          {universities.map((university) => (
            <li key={university.name}>
              <strong>Nome:</strong> {university.name}<br />
              <strong>Domínio:</strong> {university.domains ? university.domains.join(', ') : 'N/A'}<br />
              <strong>País:</strong> {university.country || 'N/A'}<br />
            </li>
          ))}
        </ul>
      ) : (
        <p>Nenhuma informação sobre universidades disponível.</p>
      )}
    </div>
  );
};

export default UniversityInfoComponent;
