import React, { useState } from 'react';
import Header from './components/Header';
import Formulario from './components/Formulario';
import Rodape from './components/Rodape';
import UniversityInfoComponent from './components/UniversityInfoComponent';
import './App.css';

function App() {
  const [escola, setEscola] = useState('');
  const [renda, setRenda] = useState('');
  const [escolaNome, setEscolaNome] = useState('');
  const [porcentagemBolsa, setPorcentagemBolsa] = useState('');
  const [resultadoVisivel, setResultadoVisivel] = useState(false);

  const calcularBolsa = () => {
    if (escola === 'publica') {
      setPorcentagemBolsa('100');
    } else if (escola === 'particular') {
      const rendaFloat = parseFloat(renda);

      if (rendaFloat <= 5000) {
        setPorcentagemBolsa('70');
      } else if (rendaFloat <= 7500) {
        setPorcentagemBolsa('60');
      } else if (rendaFloat <= 15000) {
        setPorcentagemBolsa('45');
      } else {
        setPorcentagemBolsa('30');
      }
    }

    setResultadoVisivel(true);
  };

  return (
    <div className="App">
      <Header />
      <main>
        <h1>Bem vindos ao MackBolsa!</h1>
        <Formulario
          escola={escola}
          setEscola={setEscola}
          renda={renda}
          setRenda={setRenda}
          escolaNome={escolaNome}
          setEscolaNome={setEscolaNome}
          calcularBolsa={calcularBolsa}
          porcentagemBolsa={porcentagemBolsa}
          resultadoVisivel={resultadoVisivel}
        />
        <UniversityInfoComponent />
      </main>
      <Rodape />
    </div>
  );
}

export default App;
