import Iniciar from "./components/Iniciar.jsx";

export default function Home() {
  return (
    <div>
      <Iniciar />
      <h1></h1>
    </div>
  );
}
