import IndexPage from "../components/index.jsx";

export default function Pagina1() {
  return (
    <IndexPage/>
  )
}
