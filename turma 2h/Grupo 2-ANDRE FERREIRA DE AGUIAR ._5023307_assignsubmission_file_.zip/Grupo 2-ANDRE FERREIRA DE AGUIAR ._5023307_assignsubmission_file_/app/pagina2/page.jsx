import Lipsum from "../components/Lipsum";
import Menu from "../components/Menu";

export default function Pagina2() {
  return (
    <section>
      <Menu />
      <h1>Página 2</h1>
      <Lipsum />
    </section>
  );
}
