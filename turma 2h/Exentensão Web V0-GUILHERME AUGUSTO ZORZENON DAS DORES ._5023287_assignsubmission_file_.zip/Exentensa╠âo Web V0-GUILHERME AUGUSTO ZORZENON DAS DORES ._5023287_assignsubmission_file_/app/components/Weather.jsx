// "use client"
import "./style.css";
import { useState, useEffect } from "react";

let Weather = ({ city = "São Paulo" }) => {
  var cityAPI = city.replace(" ", " ");
  var apiKey = "bb9c60be2df87534b9e9e21b0a44f531";
  var url = `https://api.openweathermap.org/geo/1.0/direct?q=${cityAPI}&appid=${apiKey}`;

  const [content, setContent] = useState({});

  let getGeo = () => {
    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        var coords = {
          lat: data[0].lat,
          lon: data[0].lon,
        };
        getWeather(coords);
      });
  };

  let getWeather = (coords) => {
    var url2 = `https://api.openweathermap.org/data/2.5/weather?lat=${coords.lat}&lon=${coords.lon}&appid=${apiKey}&units=metric`;
    fetch(url2)
      .then((response) => response.json())
      .then((data) => {
        var newContent = {
          temp: data.main.temp,
          max: data.main.temp_max,
          min: data.main.temp_min,
          name: data.name,
          country: data.sys.country,
          lat: data.coord.lat,
          lon: data.coord.lon,
        };
        setContent(newContent);
      });
  };

  useEffect(getGeo, []);

  return (
    <article style={{ color: "white" }}>
      <p>
        <strong>
          {city} - {content.name} - ({content.country})
        </strong>
      </p>
      <p>
        <small>
          {content.lat}, {content.lon}
        </small>
      </p>
      <p>
        {content.temp}°C <br />
      </p>
      <small>
        <em>
          min: {content.min}°C, max: {content.max}°C
        </em>
      </small>
      <p>{city}</p>
      <p>{cityAPI}</p>
    </article>
  );
};

export default Weather;
