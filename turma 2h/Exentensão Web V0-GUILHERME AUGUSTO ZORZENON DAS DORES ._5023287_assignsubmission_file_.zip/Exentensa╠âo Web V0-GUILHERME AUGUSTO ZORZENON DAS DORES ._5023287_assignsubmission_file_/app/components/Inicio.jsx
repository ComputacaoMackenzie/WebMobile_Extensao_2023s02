"use client";
import React, { useState } from "react";
import "./style.css";
import Contact from "./Contact";
import Weather from "./Weather";

function Myhome(props) {
  return (
    <section>
      <Weather />
      <div
        className="Img"
        style={{ backgroundImage: `url(${props.url})` }}
      ></div>
    </section>
  );
}

function Htexto() {
  const [showContact, setShowContact] = useState(false);

  return (
    <section className="home">
      <div className="image">
        <img
          src="https://res.cloudinary.com/dvnearckj/image/upload/v1695682880/2016045707fd2c274f2_zgpgdg.webp"
          alt="Mack"
        />
      </div>
      <div className="content">
        <h3>Denuncia Anônima Estudantil</h3>
        <span>Proteja sua Faculdade!</span>
        <p>
          Nossa missão é simples: proporcionar um espaço seguro onde qualquer
          pessoa pode reportar anonimamente comportamentos prejudiciais, riscos
          à segurança e violações acadêmicas na faculdade. Acreditamos que cada
          voz é valiosa, e é por isso que estamos aqui para ouvir você. Junte-se
          a nós na construção de um campus mais seguro e respeitoso. Sua
          faculdade e sua comunidade agradecem.
        </p>
        <button className="btn" onClick={() => setShowContact(true)}>
          Reporte Agora <i className="fas fa-user"></i>
        </button>
        {showContact && <Contact />}
      </div>
    </section>
  );
}

function Inicio() {
  return (
    <section className="cartao">
      <Myhome url="https://th.bing.com/th/id/OIP.zoCW6XOv9gJiTkmLFLr_nwHaHa?pid=ImgDet&rs=1" />
      <Htexto />
    </section>
  );
}

export default Inicio;
