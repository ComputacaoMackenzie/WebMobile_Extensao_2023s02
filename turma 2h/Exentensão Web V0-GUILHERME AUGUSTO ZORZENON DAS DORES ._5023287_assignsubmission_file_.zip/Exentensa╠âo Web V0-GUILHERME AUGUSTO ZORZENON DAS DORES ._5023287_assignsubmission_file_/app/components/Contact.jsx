import React from "react";
import "./style.css";

function Myreport() {
    return (
        <section className="contact">
            <h1 className="heading"> Entre em contato <span>!</span> </h1>
            <div className="row">
                <div className="info-container">
                    <h1>Conte o ocorrido!</h1>
                    <p>Estamos aqui para ajudar a compreender e denunciar eventos. Nossa equipe experiente está pronta para
                        responder às suas perguntas e fornecer apoio personalizado, garantindo que você possa relatar os
                        acontecimentos de forma clara e eficaz a alcançar seus</p>
                    <div className="box-container">
                        <div className="box">
                            <i className="fas fa-map"></i>
                            <div className="info">
                                <h3>Qual seu Campus? :</h3>
                                <p>Indentifique onde foi o ocorrido</p>
                            </div>
                        </div>
                        <div className="box">
                            <i className="fas fa-envelope"></i>
                            <div className="info">
                                <h3>Site :</h3>
                                <p><a href="https://www.mackenzie.br/universidade/processos-academicos-para-coordenadoria-geral-de-relacionamento-e-atendimento/informacoes-ao-aluno/fale-conosco"
                                        target="_blank" rel="noopener noreferrer">https://www.mackenzie.br/universidade/processos-academicos-para-coordenadoria-geral-de-relacionamento-e-atendimento/informacoes-ao-aluno/fale-conosco</a>
                                </p>
                            </div>
                        </div>
                        <div className="box">
                            <i className="fas fa-phone"></i>
                            <div className="info">
                                <h3>Numero :</h3>
                                <p>(11)2114-8000</p>
                            </div>
                        </div>
                    </div>
                </div>
                <form action="">
                    <div className="inputBox">
                        <input type="text" placeholder="seu nome"/>
                        <input type="number" placeholder="seu numero"/>
                    </div>
                    <div className="inputBox">
                        <input type="email" placeholder="seu email"/>
                        <input type="text" placeholder="assunto"/>
                    </div>
                    <textarea placeholder="mande uma mensagem falando sobre o ocorrido!" cols="30" rows="10"></textarea>
                    <input type="submit" value="enviar mensagem" className="btn"/>
                    <label htmlFor="file-upload" className="btn">
                        Enviar imagem
                    </label>
                    <input id="file-upload" type="file" style={{display: "none"}}/>
                </form>
            </div>
        </section>
    );
}

function Inicio() {
  return (
    <section className="cartao">
      <Myreport />
    </section>
  );
}

export default Inicio;