"use client";
import Inicio from "./components/Inicio";
//  Grupo:
// Rodrygo Rogerio Vasconcellos - 42014492
// Pedro Andrade - 32307721
// Guilherme Dores - 32368089

export default function Home() {
  return (
    <main>
      <Inicio />
    </main>
  );
}
