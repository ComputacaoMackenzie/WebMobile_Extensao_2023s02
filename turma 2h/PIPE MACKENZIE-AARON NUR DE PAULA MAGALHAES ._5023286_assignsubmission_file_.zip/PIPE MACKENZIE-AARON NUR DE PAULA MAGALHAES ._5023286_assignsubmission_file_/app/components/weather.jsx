"use client";
import React from "react";
import "../styles.css";
import Image from "next/image";

import { useState, useEffect } from "react";

const now = new Date();
const weekDays = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];
const weekDay = weekDays[now.getDay()];
const months = ["janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
const date = `${now.getDate()} de ${months[now.getMonth()]}`;

const getImagePath = (temp) => {
  if (temp <= 15) {
    return "/img/frio.png"; 
  } else if (temp <= 25) {
    return "/img/basico.png"; 
  } else {
    return "/img/quente.png"; 
  }
};

let Weather = ({ city = "Sao Paulo" }) => {


  var cityAPI = city.replace(" ", "%20");
  //   COLOCAR AQUI A CHAVE DA API
  var apiKey = "49ccd65ab424aa17e02acad0c0db4059";
  var url1 = `https://api.openweathermap.org/geo/1.0/direct?q=${cityAPI}&appid=${apiKey}`;
  
  const [content, setContent] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [clothingRecommendation, setClothingRecommendation] = useState('');

  const getClothingRecommendation = (temp) => {
    const adjustedTemp = temp + 3; 
    if (adjustedTemp <= 15) {
      return "Está frio lá fora, vista-se em camadas. Um bom casaco e calça comprida são essenciais.";
    } else if (adjustedTemp <= 25) {
      return "O clima está confortável. Uma camiseta e calça são adequadas. Levar uma blusa na mochila pode ser útil se esfriar.";
    } else {
      return "Está calor! Roupas leves e confortáveis são recomendadas. Shorts e camisetas são ideais.";
    }
  };

  let getGeo = () => {
    setIsLoading(true);
    fetch(url1)
      .then((response) => response.json())
      .then((data) => {
        var coords = {
          lat: data[0].lat,
          lon: data[0].lon,
        };
        getWeather(coords);
      });
  };

  let getWeather = (coords) => {
    let url2 = `https://api.openweathermap.org/data/2.5/weather?lat=${coords.lat}&lon=${coords.lon}&appid=${apiKey}&units=metric`;
    fetch(url2)
      .then((response) => response.json())
      .then((data) => {
        var newContent = {
          temp: data.main.temp,
          max: data.main.temp_max,
          min: data.main.temp_min,
          name: data.name,
          country: data.sys.country,
          lat: data.coord.lat,
          lon: data.coord.lon,
        };
        setContent(newContent);
        setIsLoading(false);
        const weatherImagePath = getImagePath(newContent.temp);
      });
  };

  useEffect(getGeo,[]);
  useEffect(() => {
    if (content && content.temp) {
      setClothingRecommendation(getClothingRecommendation(content.temp));
    }
  }, [content])



  if (isLoading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', backgroundColor: 'white', color: 'black' }}>
        Carregando o clima...
      </div>
    );
  }
  return (
    <article>
      <div style={{ backgroundColor: 'white', color: 'black' }}>
        <header>
          <h1>CLIMACK</h1>
        </header>

        <div id="divisao">
          <p id="corpo1">{weekDay}</p>
          <p id="corpo2">{date}</p>

          <div id="divisao2">
            <h2>{Math.round(content.temp)}&#186;C</h2>
            <img src={getImagePath(content.temp)} alt="Imagem do clima" />
          </div>
          <p id="corpo3">{clothingRecommendation}</p>
        </div>

        <div id="divisao3">
          <h3>Max: {Math.round(content.temp)}&#186;C</h3>
          <h4>Min: {Math.trunc(content.temp)}&#186;C</h4>
        </div>

        <footer>
          &copy; climack - Aaron Magalhaes, Henrique Kenzo, Henrique Aguiar e
          Lucca Pivoto
        </footer>
      </div>
    </article>
  );
};

export default Weather;
