import Weather from "./components/weather";

export default function Home() {
  return (
    <main>
      <Weather />
    </main>
  );
}
