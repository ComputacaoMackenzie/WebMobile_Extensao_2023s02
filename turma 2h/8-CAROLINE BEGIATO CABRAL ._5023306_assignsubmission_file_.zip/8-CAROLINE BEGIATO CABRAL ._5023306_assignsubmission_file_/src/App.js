import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <div class="cabecalho">
        <h1>MackEstudos</h1>
      </div>
      <div class="left-paragraph">
        <p>Caroline Begiato Cabral</p>
        <p>Sistemas de Informação</p>
        <p>2º Semestre</p>
      </div>
      <img id="img1" src={require("../img/img3.jpeg")} />
      <div class="section">
        <h2>Histórico</h2>
      </div>
      <div class="article">
      <img src={require("../img/img4.png")} />
      <img src={require("../img/img9.png")} />
      </div>
      <form onsubmit="validateForm()">
        <fieldset>
          <h3>Sobre o arquivo:</h3>
          <p>
            <label for="title">Título...</label>
            <input type="text" id="title" name="title" placeholder="Título" />
          </p>
          <p>
            <label for="description">Descrição...</label>
            <input
              type="description"
              id="description"
              name="description"
              placeholder="Descrição"
            />
          </p>
        </fieldset>
      </form>
    </div>
  );
}
