import React from "react";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <div id="cabecalho">
        <h1>MackEstudos</h1>
      </div>
      <div class="login">
        <h2>LOGIN</h2>
      </div>
      <div clss="formulário">
        <form onsubmit="validateForm()">
          <section>
            <p>
              <input type="text" id="tia" name="tia" placeholder="T.I.A" />
            </p>
            <p>
              <input
                type="text"
                id="password"
                name="password"
                placeholder="Senha"
              />
            </p>
            <p>
              <input type="submit" id="botao" />
            </p>
          </section>
        </form>
      </div>
    </div>
  );
}
