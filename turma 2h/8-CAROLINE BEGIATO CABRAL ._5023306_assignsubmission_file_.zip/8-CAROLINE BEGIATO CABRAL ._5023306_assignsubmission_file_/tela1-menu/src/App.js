import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <div class="cabecalho">
        <h1>MackEstudos</h1>
      </div>
      <img src={require("../img/img1.png")} />
      <div class="link1">
        <a href="">Fazer cadastro</a>
      </div>
      <div class="link2">
        <a href="">Fazer login</a>
      </div>
    </div>
  );
}
