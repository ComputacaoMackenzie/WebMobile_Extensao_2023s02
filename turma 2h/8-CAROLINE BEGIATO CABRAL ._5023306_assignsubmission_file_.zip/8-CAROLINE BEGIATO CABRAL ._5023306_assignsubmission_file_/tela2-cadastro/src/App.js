import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <div class="cabecalho">
        <h1>MackEstudos</h1>
      </div>
      <div class="informacaos">
        <h2>Preencher Informações Pessoais:</h2>
      </div>
      <img src={require("../img/img2.png")} />
      <div id="formulario">
        <form onsubmit="validateForm()">
          <fieldset>
            <p>
              <label for="fullname"></label>
              <input
                type="text"
                id="info"
                name="fullname"
                placeholder="nome completo"
              />
            </p>
            <p>
              <label for=""></label>
              <input type="text" id="info" name="" placeholder="T.I.A" />
            </p>
            <p>
              <label for="email"></label>
              <input
                type="email"
                id="info"
                name="email"
                placeholder="Email pessoal:"
              />
            </p>
            <p>
              <label for="email"></label>
              <input
                type="email"
                id="info"
                name="email"
                placeholder="Email Mackenzista"
              />
            </p>
            <p>
              <label for=""></label>
              <input type="text" id="info" placeholder="Curso" />
            </p>
            <p>
              <label for=""></label>
              <input type="text" id="info" placeholder="Semestre" />
            </p>
            <p>
              <input type="submit" />
            </p>
          </fieldset>
        </form>
      </div>
    </div>
  );
}
