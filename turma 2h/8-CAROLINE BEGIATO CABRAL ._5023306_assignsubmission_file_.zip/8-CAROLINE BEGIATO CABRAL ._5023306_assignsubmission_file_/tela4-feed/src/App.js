import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <div class="cabecalho">
        <h1>MackEstudos</h1>
      </div>
      <div class="left-paragraph">
        <p>Caroline Begiato Cabral</p>
        <p>Sistemas de Informação</p>
        <p>2º Semestre</p>
      </div>
      <img id="img1" src={require("../img/img3.png")} />
      <form onsubmit="validateForm()">
        <fieldset>
          <p>
            <label for="search">Search...</label>
            <input type="text" id="search" name="search" />
          </p>
        </fieldset>
      </form>
      <div class="post">
        <h2>Recentely Posted</h2>
      </div>
      <div class="article">
        <img src={require("../img/img5.png")} />
        <img src={require("../img/img6.png")} />
        <img src={require("../img/img7.png")} />
        <img src={require("../img/img8.png")} />
      </div>
    </div>
  );
}
