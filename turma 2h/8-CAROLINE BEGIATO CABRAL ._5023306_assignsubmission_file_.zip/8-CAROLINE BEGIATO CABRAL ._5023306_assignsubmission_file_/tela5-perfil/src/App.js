import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <div class="cabecalho">
        <h1>MackEstudos</h1>
      </div>
      <img src={require("../img/img3.png")} />
      <div class="main">
        <p>
          <strong>Caroline Begiato Cabral</strong>
        </p>
        <p>Sistemas de Informação</p>
        <p>2º Semestre</p>
      </div>
      <div class="direita">
        <h3>Dados Pessoais:</h3>
        <li>Email: CarolA.b@blablabla.com</li>
        <li>Caroline Begiato Cabral</li>
      </div>
      <div class="section">
        <h4>Dados Mackenzista:</h4>
        <li>T.I.A:32326579</li>
        <li>Curso: Sistemas de Informação</li>
        <li>Semestre: 2º Semestre</li>
      </div>
    </div>
  );
}
