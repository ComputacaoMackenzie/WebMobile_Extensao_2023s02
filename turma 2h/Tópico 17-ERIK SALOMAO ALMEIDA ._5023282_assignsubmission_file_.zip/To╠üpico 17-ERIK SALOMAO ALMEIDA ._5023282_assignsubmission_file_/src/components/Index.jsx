import React from "react";
import "../style/noiafinder.css";
import Login from "./Login";
import seta from "./seta.png";
import marcador from "./marcador.png";
import filtrar from "./filtrar.png";
import encerrar from "./encerrar.png";
import perfil from "./perfil.png";
import configura from "./configura.png";
import "../styles.css";
import "leaflet/dist/leaflet.css";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import { Icon, divIcon, point } from "leaflet";

export default function Index({ onClick }) {
  const customIcon = new Icon({
    iconUrl: "https://cdn-icons-png.flaticon.com/512/447/447031.png",
    iconSize: [38, 38] // size of the icon
  });
  const markers = [
    {
      geocode: [-23.548153788653806, -46.652937125986185],
      popUp: "Tem um noia aqui!!!"
    },
    {
      geocode: [-23.54583558048813, -46.652522807558064],
      popUp: "Tem outro noia aqui!!!"
    },
    {
      geocode: [-23.54858142038848, -46.65144920864306],
      popUp: "Mais um ein, cuidado!!!"
    },
  ];
  
  const paginaLogin = (event) => {
    event.preventDefault();
    onClick("login");
  };

  const paginaAjuda = (event) => {
    event.preventDefault();
    onClick("ajuda");
  };

  return (
    <div className="app">
      <header>
        <img src="img/lista.png" alt="Foto Cabeçalho" id="fotocabecalho" />
        <p id="titulocabecalho">Adicionar Localização</p>
        <p id="textocabecalho">Publicar</p>
      </header>
      <div className="conteudo">
      <aside>
        <button onClick={paginaLogin} id="seta">
          <a href="login.html">
            <img src={seta} alt="Foto Seta" id="fotoseta" />
          </a>
        </button>
        <section className="perfil">
          <img
            src="https://assetsio.reedpopcdn.com/ghost-chegara-a-call-of-duty-modern-warfare-na-season-2-1580904365928.jpg?width=150&height=112&fit=crop&quality=100&format=png&enable=upscale&auto=webp"
            alt="Foto Perfil"
            id="fotoperfil"
            title="Perfil"
          />
          <p>Nome</p>
          <p id="user">@Nome</p>
        </section>
        <nav className="acoes1">
          <ul>
            <li>
              <button id="botao1">
                <img src={marcador} alt="Ícone" id="icones" />
                <div id="quadrado"> Reportar</div>
              </button>
            </li>
            <li>
              <button id="botao1">
                <img src={filtrar} alt="Ícone" id="icones" />
                <div id="quadrado"> Filtrar</div>
              </button>
            </li>
            <li>
              <button id="botao1">
                <img src={encerrar} alt="Ícone" id="icones" />
                <div id="quadrado"> Cancelar</div>
              </button>
            </li>
          </ul>
        </nav>
        <footer className="rodape">
          <div id="bordafoto1">
            <img src={perfil} alt="Foto" id="fotofim1" />
          </div>
          <div id="bordafoto2">
            <button onClick={paginaAjuda} className="botaoConfigura">
              <a href="ajuda.html">
                <img src={configura} alt="Foto" id="fotofim2" />
              </a>
            </button>
          </div>
        </footer>
      </aside>
      <section className="mapa">
        <div id="map">
        <MapContainer center={[-23.548492557330725, -46.65263878161557]} zoom={50}>
  <TileLayer
    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
  />
  {markers.map(marker => (
    <Marker position={marker.geocode} key={marker.id}
      icon={customIcon}>
      <Popup>{marker.popUp}</Popup>
    </Marker>
  ))}
</MapContainer>
        </div>
      </section>
    </div>
    </div>
  );
}
