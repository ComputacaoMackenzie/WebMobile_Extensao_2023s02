import React from 'react';
import '../style/ajuda.css';
import seta from "./seta.png";

export default function Ajuda() {
  return (
    <div className="login-bloco">
      <h2>Ajuda</h2>
      <p id="subtitulo">Seja bem-vindo ao nosso projeto!</p>
      <p>
        O Noia Finder foi criado com o objetivo de ajudar todos os alunos do Mackenzie que andam ao redor da universidade e vivem com a constante insegurança de encontrar alguém mal intencionado pela frente.
      </p>
      <p>
        Em nossa plataforma, os mackenzistas poderão colaborar entre-si com o propósito de alertar uns aos outros sobre a presença de alguém com más intenções.
      </p>
      <button id="seta">
        <a href="index.html">
          <img src={seta} id="fotoseta" alt="Seta" />
        </a>
      </button>
    </div>
  );
}
