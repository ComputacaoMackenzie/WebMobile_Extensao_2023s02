import React from 'react';
import '../style/styleLogin.css'; 

export default function Login() {
  return (
    <div className="login-bloco">
      <h2>Login</h2>
      <form>
        <div className="user-login">
          <input type="text" name="" required />
          <label htmlFor="user">Username</label>
        </div>
        <div className="user-login">
          <input type="password" password="" required />
          <label htmlFor="pass">Password</label>
        </div>
        <a href="index.html">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          Submit
        </a>
      </form>
    </div>
  );
}


