/*Nicolas Gonçalves - 32337590, Erik Almeida - 32333048, Guilherme Ponciano - 42016061 */
import React, { useState } from "react";
import Index from "./components/Index";
import Login from "./components/Login";
import Ajuda from "./components/Ajuda";
import "./styles.css";
import "leaflet/dist/leaflet.css";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";

export default function App() {

  const markers = [
    {
      geocode: [-23.548116571207157, -46.652937125986185],
      popUp: "Hello, I am pop up 1"
    },

  ];
  
  const [paginaAtual, setPaginaAtual] = useState("index"); 

  const handleClick = (page) => {
    setPaginaAtual(page);
  };

  let conteudo;
  if (paginaAtual === "login") {
    conteudo = <Login onClick={handleClick} />;
  } else if (paginaAtual === "ajuda") {
    conteudo = <Ajuda onClick={handleClick} />;
  } else {
    conteudo = <Index onClick={handleClick} />;
  }

  return (
    

    <div>
      {conteudo}
    </div>
    
  );
}

