'use client';
import "./music.css";
import React from "react";
import Head from "next/head";

const Home = () => {
  return (
    <div>
      <Head>
        <title>MACKENZIE</title>
        <link rel="stylesheet" href="/styles/fone.css" />
        <link
          href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
          rel="stylesheet"
        />
      </Head>

      <header className="header">
        <a href="#" className="logo">
          Mackenzie
        </a>

        <input type="checkbox" id="check" />
        <label htmlFor="check" className="icons">
          <i className="bx bx-menu" id="menu-icon"></i>
          <i className="bx bx-expand-alt" id="close-icon"></i>
        </label>

        <nav className="navbar">
          <a href="/">O QUE SOMOS</a>
          <a id="active" href="#">
            STUDY MUSICS
          </a>
          <a href="relogio.html">RELÓGIO</a>
          <a href="To Do List .html">CLIMA</a>
        </nav>
      </header>

      <div id="audios">
        <h3>Meditation Compilation</h3>
        <br />
        <div className="audios1">
          <audio controls volume="30" loop={false} autostart={false}>
            <source
              className="n1"
              src="/musics/Meditation Compilation.mp3"
              type="audio/mpeg"
            />
          </audio>
        </div>
        <br />
        <h3>Neve e Lareira</h3>
        <br />
        <div className="audios2">
          <audio controls volume="30" loop={false} autostart={false}>
            <source
              className="n2"
              src="/musics/neve e lareira.mp3"
              type="audio/ogg"
            />
          </audio>
        </div>
        <br />
        <h3>Relaxing Music Box</h3>
        <br />
        <div className="audios3">
          <audio controls volume="30" loop={false} autostart={false}>
            <source src="/musics/Relaxing Music Box.mp3" type="audio/ogg" />
          </audio>
        </div>
        <br />
        <h3>Som de Chuva e o Fogo</h3>
        <br />
        <div className="audios4">
          <audio controls volume="30" loop={false} autostart={false}>
            <source
              src="/musics/Som de Chuva e o Estalar do Fogo.mp3"
              type="audio/ogg"
            />
          </audio>
        </div>
      </div>
      <section id="msc">
        <h1>STUDY BUDDY</h1>
        <h3>Musicas para estudar</h3>
        <p>
          A música pode desempenhar um papel fundamental no processo de estudo,
          oferecendo uma série de benefícios. Ela pode melhorar o foco e a
          concentração, reduzir o estresse e a ansiedade, aumentar a motivação e
          tornar o estudo mais agradável. Além disso, a música pode estimular a
          criatividade, aumentar a retenção de informações e facilitar a
          administração do tempo. No entanto, é importante escolher o tipo de
          música adequado para cada situação e preferência pessoal, pois nem
          todos os estilos funcionam para todos. Em resumo, a música pode ser
          uma ferramenta valiosa para melhorar a produtividade e a experiência
          de estudo.
        </p>
      </section>
    </div>
  );
};

export default Home;
