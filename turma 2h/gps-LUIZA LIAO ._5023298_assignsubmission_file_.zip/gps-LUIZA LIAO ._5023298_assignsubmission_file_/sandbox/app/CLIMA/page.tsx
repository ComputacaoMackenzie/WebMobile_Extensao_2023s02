"use client"
import "./clima.css";
import { useState } from "react";
import Head from "next/head";

const apiKey = "4cbcfd6710a39cbba56f14ad499d6179";
const apiCountryURL = "https://countryflagsapi.com/png/";
const apiUnsplash = "https://source.unsplash.com/1600x900/?";

const Home = () => {
  const [city, setCity] = useState("");
  const [weatherData, setWeatherData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  const toggleLoader = () => {
    setLoading((prevLoading) => !prevLoading);
  };

  const getWeatherData = async (city) => {
    toggleLoader();

    try {
      const apiWeatherURL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}&lang=pt_br`;
      const res = await fetch(apiWeatherURL);
      const data = await res.json();

      if (data.cod === "404") {
        setError(true);
        setWeatherData(null);
      } else {
        setWeatherData(data);
      }
    } catch (error) {
      setError(true);
      setWeatherData(null);
    } finally {
      toggleLoader();
    }
  };

  const showErrorMessage = () => {
    setError(true);
    setWeatherData(null);
  };

  const hideInformation = () => {
    setError(false);
    setWeatherData(null);
  };

  const showWeatherData = async (city) => {
    hideInformation();
    getWeatherData(city);
  };

  const suggestionClickHandler = async (selectedCity) => {
    setCity(selectedCity);
    await showWeatherData(selectedCity);
  };

  return (
    <div className="container">
      <Head>
        <title>Clima agora!</title>
        <meta charSet="UTF-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link
          href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap"
          rel="stylesheet"
        />
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"
          integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A=="
          crossOrigin="anonymous"
          referrerPolicy="no-referrer"
        />
        <link rel="stylesheet" href="/styles/tomato.css" />
        <script src="/scripts/clima.js" defer></script>
      </Head>

      <a href="/" ClassName="back">Menu</a>

      <div className="form">
        <h3>Confira o clima de uma cidade:</h3>
        <div className="form-input-container">
          <input
            type="text"
            placeholder="Digite o nome da cidade"
            value={city}
            onChange={(e) => setCity(e.target.value)}
          />
          <button onClick={() => showWeatherData(city)}>
            <i className="fa-solid fa-magnifying-glass"></i>
          </button>
        </div>
      </div>

      {loading && (
        <div id="loader">
          {" "}
          <i className="fa-solid fa-spinner"></i>{" "}
        </div>
      )}

      {error && (
        <div id="error-message">
          <p>Não foi possível encontrar o clima de uma cidade com este nome.</p>
        </div>
      )}

      {weatherData && (
        <div id="weather-data">
          <h2>
            <i className="fa-solid fa-location-dot"></i> {weatherData.name}{" "}
            <img src={apiCountryURL + weatherData.sys.country} alt="" />
          </h2>
          <p id="temperature">
            <span>{parseInt(weatherData.main.temp)}</span>&deg;C
          </p>
          <div id="description-container">
            <p id="description">{weatherData.weather[0].description}</p>
            <img
              id="weather-icon"
              src={`http://openweathermap.org/img/wn/${weatherData.weather[0].icon}.png`}
              alt="Condições atuais"
            />
          </div>
          <div id="details-container">
            <p id="umidity">
              <i className="fa-solid fa-droplet"></i>
              <span>{weatherData.main.humidity}%</span>
            </p>
            <p id="wind">
              <i className="fa-solid fa-wind"></i>
              <span>{weatherData.wind.speed}km/h</span>
            </p>
          </div>
        </div>
      )}

      <div id="suggestions">
        <button onClick={() => suggestionClickHandler("Viena")}>Viena</button>
        <button onClick={() => suggestionClickHandler("Copenhague")}>
          Copenhague
        </button>
        <button onClick={() => suggestionClickHandler("Zurique")}>
          Zurique
        </button>
        <button onClick={() => suggestionClickHandler("Vancouver")}>
          Vancouver
        </button>
        <button onClick={() => suggestionClickHandler("Genebra")}>
          Genebra
        </button>
        <button onClick={() => suggestionClickHandler("Frankfurt")}>
          Frankfurt
        </button>
        <button onClick={() => suggestionClickHandler("Osaka")}>Osaka</button>
        <button onClick={() => suggestionClickHandler("Maceió")}>Maceió</button>
      </div>
    </div>
  );
};

export default Home;
