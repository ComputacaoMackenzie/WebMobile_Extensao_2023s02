// pages/index.js
import React from "react";
import Head from "next/head";

const Home = () => {
  return (
    <div>
      <Head>
        <title>MACKENZIE</title>
        <link
          href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
          rel="stylesheet"
        />
      </Head>

      <header className="header">
        <a href="#" className="logo">
          Mackenzie
        </a>

        <input type="checkbox" id="check" />
        <label htmlFor="check" className="icons">
          <i className="bx bx-menu" id="menu-icon"></i>
          <i className="bx bx-expand-alt" id="close-icon"></i>
        </label>

        <nav className="navbar">
          <a id="active" href="#">
            O QUE SOMOS
          </a>
          <a href="MUSIC">STUDY MUSICS</a>
          <a href="RELOGIO">RELÓGIO</a>
          <a href="CLIMA">CLIMA</a>
        </nav>
      </header>

      <section>
        <h1>STUDY BUDDY</h1>
        <h3>Explicação do site e de cada método</h3>
        <p>
          O Study Buddy é uma plataforma abrangente, projetada para apoiar
          estudantes em sua jornada de aprendizado. Uma de suas funcionalidades
          permite que os alunos acessem uma variedade de recursos de áudio,
          incluindo músicas de ambiente e sons ASMR, para aprimorar a
          concentração durante o estudo. Além disso, o Study Buddy oferece
          orientações detalhadas sobre como criar mapas mentais, uma técnica
          valiosa de organização visual de informações que ajuda os estudantes a
          sintetizar e estruturar conceitos complexos.
        </p>
        <p>
          Para aqueles que desejam monitorar seu tempo de estudo de forma mais
          precisa, a plataforma disponibiliza um relógio visual, tornando o
          gerenciamento do tempo mais eficaz. E, para melhorar a produtividade,
          o método Pomodoro está integrado, com um cronômetro configurado para
          sessões de estudo de 25 minutos seguidas por pausas de 5 minutos.
          Essas ferramentas visam tornar o processo de aprendizado mais
          eficiente, produtivo e agradável para os estudantes.
        </p>
      </section>
    </div>
  );
};

export default Home;
