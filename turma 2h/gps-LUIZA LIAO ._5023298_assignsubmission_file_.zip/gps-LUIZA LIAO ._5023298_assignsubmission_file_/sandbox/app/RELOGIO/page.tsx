'use client';
import React, { useEffect, useState } from "react";
import Head from "next/head";
import "./relogio.css";

const Relogio = () => {
  const [time, setTime] = useState({
    hour: "00",
    min: "00",
    sec: "00",
  });

  useEffect(() => {
    const intervalId = setInterval(() => {
      const date = new Date();
      const dHour = date.getHours();
      const dMinute = date.getMinutes();
      const dSec = date.getSeconds();

      setTime({
        hour: formatTime(dHour),
        min: formatTime(dMinute),
        sec: formatTime(dSec),
      });
    }, 1000);

    return () => clearInterval(intervalId);
  }, []);

  const formatTime = (time) => {
    return time < 10 ? "0" + time : time;
  };

  return (
    <div>
      <Head>
        <title>MACKENZIE</title>
        <link rel="stylesheet" href="/styles/relogio.css" />
        <link
          href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
          rel="stylesheet"
        />
      </Head>

      <header className="header">
        <a href="#" className="logo">
          Mackenzie
        </a>

        <input type="checkbox" id="check" />
        <label htmlFor="check" className="icons">
          <i className="bx bx-menu" id="menu-icon"></i>
          <i className="bx bx-expand-alt" id="close-icon"></i>
        </label>

        <nav className="navbar">
          <a href="index.html">O QUE SOMOS</a>
          <a href="fone.html">STUDY MUSICS</a>
          <a id="active" href="#">
            RELÓGIO
          </a>
          <a href="To Do List .html">CLIMA</a>
        </nav>
      </header>

      <div>
        <span id="hour">{time.hour}</span>
        <span id="min">{time.min}</span>
        <span id="sec">{time.sec}</span>
       
      </div>
    </div>
  );
};

export default Relogio;
