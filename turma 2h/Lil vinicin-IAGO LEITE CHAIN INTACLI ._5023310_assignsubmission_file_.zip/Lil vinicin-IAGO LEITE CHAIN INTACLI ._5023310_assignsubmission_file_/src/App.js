import React from "react";
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import "./styles.css";


function App() {

  const redirectTo = (url) => {
    window.location.href = url;
  };


  const position = [-23.5475, -46.6361]; 
  return (
    <div className="App">
      <header>
        <h1>MackInterativo</h1>
        <img src="../img/mack.png" alt="Mack Logo" />
      </header>

      <MapContainer center={position} zoom={13} scrollWheelZoom={false} className="map-container">
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        <Marker position={position}>
          <Popup>
            Um ponto de interesse em São Paulo. {}
          </Popup>
        </Marker>
      </MapContainer>

      <aside>
        <div
          id="image2"
          onClick={() => redirectTo("https://www3.mackenzie.br/tia/")}
        ></div>
        <div
          id="image3"
          onClick={() =>
            redirectTo(
              "https://www.google.com/maps/place/MackGraphe/@-23.5473438,-46.651857,18z/data=!4m6!3m5!1s0x94ce58362648b6e9:0x705ec8dd240cc12!8m2!3d-23.5475622!4d-46.6514951!16s%2Fg%2F11bxf023pd?authuser=0&entry=ttu"
            )
          }
        ></div>
        <div
          id="image4"
          onClick={() => redirectTo("https://graduacao.mackenzie.br/calendar/view.php?view=month")}
        ></div>
        <div
          id="image5"
          onClick={() => redirectTo("https://www.mackenzie.br/atendimento/central-de-informacoes")}
        ></div>
        <div
          id="image6"
          onClick={() =>
            redirectTo(
              "https://www.google.com.br/maps/place/Universidade+Presbiteriana+Mackenzie/@-23.5480455,-46.6529395,17z/data=!3m1!4b1!4m6!3m5!1s0x94ce584992d1355b:0x2619a4227c175a85!8m2!3d-23.5480504!4d-46.6503646!16s%2Fg%2F1tg7t3_1?entry=ttu"
            )
          }
        ></div>
      </aside>

      <footer></footer>
    </div>
  );
}

export default App;