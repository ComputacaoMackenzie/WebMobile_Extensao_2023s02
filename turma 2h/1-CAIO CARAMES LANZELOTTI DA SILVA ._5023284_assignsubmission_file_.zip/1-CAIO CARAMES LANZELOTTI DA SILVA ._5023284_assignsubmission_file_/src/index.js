import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import HomePage from './components/HomePage';


import Avaliacoes from './components/Avaliacoes';
import NovaViagem from './components/NovaViagem';
import './styles.css';
import { BrowserRouter } from 'react-router-dom';

ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>,
  document.getElementById('root')
);