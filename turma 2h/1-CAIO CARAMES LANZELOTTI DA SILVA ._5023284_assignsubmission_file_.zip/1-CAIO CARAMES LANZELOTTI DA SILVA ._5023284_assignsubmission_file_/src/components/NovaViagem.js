import "ol/ol.css";
import Map from "ol/Map";
import View from "ol/View";
import { fromLonLat } from "ol/proj";
import TileLayer from "ol/layer/Tile";
import OSM from "ol/source/OSM";
import { useEffect, useRef } from "react";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./NovaViagem.css";

function NovaViagem() {
  const [localizacaoAtual, setLocalizacaoAtual] = useState("");
  const [endereco, setEndereco] = useState("");
  const [novaLocalizacao, setNovaLocalizacao] = useState(null);
  const mapElemento = useRef(null);

  useEffect(() => {
    const map = new Map({
      target: mapElemento.current,
      layers: [
        new TileLayer({
          source: new OSM(),
        }),
      ],
      view: new View({
        zoom: 17,
      }),
    });

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const novaLocalizacao = fromLonLat([longitude, latitude]);
        setNovaLocalizacao(novaLocalizacao);
        map.getView().setCenter(novaLocalizacao);
      },
      (error) => console.error("Erro ao obter localização atual:", error),
    );
  }, []);

  const buscarLocalizacao = () => {
    const apiKey = "52e5fe6d6ce8cf2d2d005bb0c339ff7b";
    const apiUrl = `https://api.openweathermap.org/geo/1.0/direct?q=${endereco}&limit=1&appid=${apiKey}`;

    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => {
        const { lat, lon } = data[0];
        const novaLocalizacao = fromLonLat([lon, lat]);
        setNovaLocalizacao(novaLocalizacao);
      })
      .catch((error) => console.error("Erro ao buscar localização:", error));
  };

  return (
    <div className="nova-viagem">
      <div ref={mapElemento} className="mapa"></div>
      <div className="busca-container">
        <label htmlFor="localizacao-atual">Localização Atual</label>
        <input
          type="text"
          id="localizacao-atual"
          value={localizacaoAtual}
          onChange={(e) => setLocalizacaoAtual(e.target.value)}
          placeholder="Digite sua localização atual"
        />

        <label htmlFor="pesquisar-endereco">Pesquisar Endereço</label>
        <input
          type="text"
          id="pesquisar-endereco"
          value={endereco}
          onChange={(e) => setEndereco(e.target.value)}
          placeholder="Para onde você quer ir?"
        />

        <button type="button" onClick={buscarLocalizacao}>
          Buscar
        </button>

        <Link to="/" className="back-button">
          Voltar
        </Link>
      </div>
    </div>
  );
}

export default NovaViagem;
