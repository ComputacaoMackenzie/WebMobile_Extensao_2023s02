import React from "react";
import { Link } from "react-router-dom";

function TopBar() {
  return (
    <div className="top-bar">
      <div className="site-title">MackCar</div>
      <div className="login-section">
        <input type="text" placeholder="Usuário" />
        <input type="password" placeholder="Senha" />
        <button>Entrar</button>
        <a href="#">Não tem cadastro?</a>
      </div>
    </div>
  );
}

export default TopBar;
