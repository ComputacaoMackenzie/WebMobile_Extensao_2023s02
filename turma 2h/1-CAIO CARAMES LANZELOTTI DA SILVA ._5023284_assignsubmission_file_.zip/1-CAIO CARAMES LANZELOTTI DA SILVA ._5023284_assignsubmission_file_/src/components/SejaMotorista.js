import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./SejaMotorista.css";

function SejaMotorista() {
  const [nome, setNome] = useState("");
  const [sobrenome, setSobrenome] = useState("");
  const [modeloVeiculo, setModeloVeiculo] = useState("");
  const [corVeiculo, setCorVeiculo] = useState("");
  const [placaVeiculo, setPlacaVeiculo] = useState("");
  const [foto, setFoto] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();

    console.log("Dados do Motorista:");
    console.log("Nome:", nome);
    console.log("Sobrenome:", sobrenome);
    console.log("Modelo/Cor do Veículo:", modeloVeiculo, corVeiculo);
    console.log("Placa do Veículo:", placaVeiculo);
    console.log("Foto:", foto);
  };

  const handleFoto = (e) => {
    const arquivo = e.target.files[0];
    setFoto(arquivo);
  };

  return (
    <div className="formulario-container">
      <h2>Formulário de Inscrição Mackcar</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="nome">Nome:</label>
          <input
            type="text"
            id="nome"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="sobrenome">Sobrenome:</label>
          <input
            type="text"
            id="sobrenome"
            value={sobrenome}
            onChange={(e) => setSobrenome(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="modeloVeiculo">Modelo do Veículo:</label>
          <input
            type="text"
            id="modeloVeiculo"
            value={modeloVeiculo}
            onChange={(e) => setModeloVeiculo(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="corVeiculo">Cor do Veículo:</label>
          <input
            type="text"
            id="corVeiculo"
            value={corVeiculo}
            onChange={(e) => setCorVeiculo(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="placaVeiculo">Placa do Veículo:</label>
          <input
            type="text"
            id="placaVeiculo"
            value={placaVeiculo}
            onChange={(e) => setPlacaVeiculo(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="foto">Foto do Motorista:</label>
          <input type="file" id="foto" accept="image/*" onChange={handleFoto} />
        </div>
        <button type="submit">Enviar</button>
        <Link to="/" className="back-button">
          Voltar
        </Link>
      </form>
    </div>
  );
}

export default SejaMotorista;
