import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Avaliacoes.css';

function Avaliacoes() {

  const maxAvaliacao = 5;
  const [avaliacoes, setAvaliacoes] = useState([
    
    { motorista: "Motorista 1", avaliacao: 5, data: "25/11/23", hora: "22h15", preco: "R$24,60" },
    { motorista: "Motorista 2", avaliacao: 4, data: "25/11/23", hora: "00h33", preco: "R$19,05" },
    { motorista: "Motorista 3", avaliacao: 3, data: "26/11/23", hora: "08h25", preco: "R$26,30" },
    { motorista: "Motorista 4", avaliacao: 4, data: "27/11/23", hora: "14h40", preco: "R$38,50" },
    { motorista: "Motorista 5", avaliacao: 3, data: "27/11/23", hora: "12h35", preco: "R$35,00" },
    
  ]);
    
  
  useEffect(() => {
    const fetchFotos = async () => {
      const response = await fetch('https://randomuser.me/api/?results=5'); //API das fotos
      const data = await response.json();
      const fotos = data.results.map(user => user.picture.medium);

      // Atualização das fotos dos motoristas
      setAvaliacoes(avaliacoes.map((avaliacao, index) => ({
        ...avaliacao,
        foto: fotos[index]
      })));
    };

    fetchFotos();
  }, []);

  return (
    <div className="avaliacoes-container">
      <h2>Motoristas Avaliados</h2>
      {avaliacoes.map((avaliacao, index) => (
        <div key={index} className="avaliacao-item">
          <div className="foto-motorista" style={{ backgroundImage: `url(${avaliacao.foto})` }}> {}</div>
          <div className="info-avaliacao">
            <div>
              <div className="nome-motorista">{avaliacao.motorista}</div>
              <div>Data da corrida: {avaliacao.data}</div>
              <div>Horário da corrida: {avaliacao.hora}</div>
            </div>
            <div className="avaliacao-detalhes">
              <div className="preco-corrida">{avaliacao.preco}</div>
            <div className="estrelas-avaliacao">
              {'★'.repeat(avaliacao.avaliacao)}
              {'☆'.repeat(maxAvaliacao - avaliacao.avaliacao)}
            </div>
          </div>
        </div>
       </div>
      ))}
      <Link to="/" className="back-button">Voltar</Link>
    </div>
  );
}

export default Avaliacoes;