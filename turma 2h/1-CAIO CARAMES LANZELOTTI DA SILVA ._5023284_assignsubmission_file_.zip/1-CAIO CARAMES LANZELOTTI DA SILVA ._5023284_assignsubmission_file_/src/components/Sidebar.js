import React from "react";
import { Link } from "react-router-dom";

function Sidebar() {
  return (
    <div className="sidebar">
      <Link to="/NovaViagem">
        <button>Nova Viagem</button>
      </Link>
      <Link to="/SejaMotorista">
      <button>Seja um Motorista</button>
      </Link>
      <Link to="/Avaliacoes">
        <button>Avaliações</button>
      </Link>
      <Link to="/DuvidasFrequentes">
        <button>Dúvidas Frequentes</button>
      </Link>
      <div className="contact-info">
        <p>Telefone: (11) 9999-9999</p>
        <p>E-mail: mackcar@gmail.com</p>
      </div>
    </div>
  );
}

export default Sidebar;
