import React from 'react';
import TopBar from '../components/TopBar';
import Sidebar from '../components/Sidebar';

function HomePage() {
  return (
    <>
      <TopBar />
      <Sidebar />
    </>
  );
}

export default HomePage;