import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./DuvidasFrequentes.css";

function DuvidasFrequentes() {
  return (
    <div className="DuvidasFrequentes">
      <h1>Dúvidas Frequentes</h1>

      <div className="pergunta-container">
        <h2 className="pergunta">Como faço para solicitar uma viagem?</h2>
        <div className="resposta">
          Para solicitar uma viagem com Mackcar, abra o aplicativo Mackcar em seu
          dispositivo móvel, insira o destino desejado e confirme a solicitação.
        </div>
      </div>

      <div className="pergunta-container">
        <h2 className="pergunta">Quanto custa uma viagem com Mackcar?</h2>
        <div className="resposta">
          O custo de uma viagem com Mackcar pode variar com base na distância, no
          tempo estimado e em outros fatores. Você verá o preço estimado antes de
          confirmar a solicitação.
        </div>
      </div>

      <div className="pergunta-container">
        <h2 className="pergunta">Posso cancelar uma viagem após solicitá-la?</h2>
        <div className="resposta">
          Sim, você pode cancelar uma viagem antes que ela seja aceita por um
          motorista sem qualquer cobrança. Após a aceitação, podem ser aplicadas
          taxas de cancelamento.
        </div>
      </div>

      <Link to="/" className="back-button">
        Voltar
      </Link>
    </div>
  );
}

export default DuvidasFrequentes;