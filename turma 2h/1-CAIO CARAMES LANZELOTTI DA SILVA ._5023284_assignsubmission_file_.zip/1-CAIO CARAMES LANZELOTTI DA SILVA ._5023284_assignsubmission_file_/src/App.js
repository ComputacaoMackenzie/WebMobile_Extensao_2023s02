import React from "react";
import { Routes, Route } from "react-router-dom";

import HomePage from "./components/HomePage";
import SejaMotorista from "./components/SejaMotorista";
import Avaliacoes from "./components/Avaliacoes";
import NovaViagem from "./components/NovaViagem";
import DuvidasFrequentes from "./components/DuvidasFrequentes";
import "./styles.css";

function App() {
  return (
    <div className="app">
          <div className="content">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/SejaMotorista" element={<SejaMotorista />} />
          <Route path="/Avaliacoes" element={<Avaliacoes />} />
          <Route path="/NovaViagem" element={<NovaViagem />} />
          <Route path="/DuvidasFrequentes" element={<DuvidasFrequentes />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
