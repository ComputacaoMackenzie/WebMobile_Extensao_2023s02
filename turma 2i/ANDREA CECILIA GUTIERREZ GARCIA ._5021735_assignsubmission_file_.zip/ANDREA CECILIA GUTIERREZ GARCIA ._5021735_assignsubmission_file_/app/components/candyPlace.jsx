
export default function CandyPlaceGourmet() {
    return (
        <>
        <h1> Candy place gourmet </h1> 
        <section className ="loja">
        <section className ="cardapio1">        
            <h2>Cardapio</h2>
            <h3>BUFFET</h3>
            <p>100G = R$7,49 <br/></p>
            <h3>SALGADOS</h3>
            <p>Coxinha  <br/>
            Pão de queijo <br/>
            Croassant <br/>
            Esfiha carne<br/>
            Tortinha alho poró com queijo <br/>
            Tortinha frango <br/>
            Tortinha palmito <br/>
            Empanada de carne<br/></p>
        </section>
        <section className ="cardapio2">
            <h3>COOKIES</h3>
            <p> Original<br/>
            Red velvet c/ leite ninho<br/>
            Bicho de pé <br/>
            Brigadeiro<br/>
            Nutell<br/></p>
        
            <h3>BEBIDAS </h3>
            <p>Aguá sem gás<br/>
            Aguá com gás<br/>
            Refrigerantes<br/>
            Suco Lata Sabores <br/>
            Chá Gelado<br/></p>
        </section>
        </section>
        </>
    );
}