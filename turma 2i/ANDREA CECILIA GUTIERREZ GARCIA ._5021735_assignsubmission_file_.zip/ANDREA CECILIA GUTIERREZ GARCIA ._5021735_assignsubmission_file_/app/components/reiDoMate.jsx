export default function ReiDoMate() {
  return(
    <>
    <h1>Rei Do Mate</h1>
    <section className="loja">
        <section className="cardapio1">
          <h3>Pão de queijo</h3>
          <p>Copão de pão de queijo 12 unid<br/>
          Super copão de pão de queijo 18 unid<br/>
          Pão de queijo lanche<br/>
          Pão queijo crocante e gratinado unid<br/>
          Waffle de pão de queijo unid<br/></p>
          
          <h3>Croissants e Folhados</h3>
          <p>Croissant de chocolate unid<br/>
          Pizza folhada unid<br/></p>
          
          <h3>Salgados Unitários</h3>
          <p>Empanadas <br/>
          Mini Toast (sanduíche preparado no pão de batata recheado)<br/>
          Pastel de queijo cremoso (mussarela, requeijão, ricota, minas padrão e parmesão)<br/>
          Pastel integral de brócolis unid<br/>
          Pães na chapa <br/>
          Pães de batata <br/>
          Esfiha integral de peito de peru com queijo branco unid<br/>
          Cestinha de broan 6 Unidades<br/>
          Coxinhas <br/>
          Esfihas unid<br/></p>
          
          <h3>Monte seu Tost</h3>
          <p>Você escolhe seu Pão e seu Recheio!<br/></p>
          
          <h3>Tost sugestões do Rei</h3>
          <p>Tost Nutella c/ banana<br/>
          Tost dog especial (2 salsichas grelhadas, queijo prato, tomate e requeijão)<br/>
          Tost misto (presunto, queijo prato, requeijão, tomate e orégano)<br/>
          Tost peito peru c/ queijo branco (peito de peru, queijo branco, tomate, orégano e requeijão)<br/>
          Tost queijo branco c/ tomate (queijo brando, tomate, requeijão e orégano)<br/></p>
          
          <h3>Açaí do seu Jeito</h3>
          <p>Escolha de até 12 toppings diferentes.<br/></p>
          
          <h3>Suco e Vitaminas</h3>
          <p>Suco natural (polpa)<br/>
          Suco ao leite <br/>
          Guaraná natural<br/>
          Suco com Guaraná<br/></p>
          
          <h3>Bebidas quentes</h3>
          <p>Café expresso c/ leite<br/>
          Cappuccino cremoso quente<br/>
          Chocolate cremoso quente<br/>
          Submarino ao leite 240ml (Mate com leite quente e pedaços de chocolate ao leite)<br/>
          Ovomaltine quente 240ml (Mate com leite quente e Ovomaltine)<br/>
          Muvuca 240ml (Mate quente com uva rosada, cravo e canela)<br/>
          Cappuccino belga 240ml (c/ pedaços de chocolate belga Callebaut)<br/>
          Chocolate quente belga 240ml (c/ Pedaços de Chocolate Belga Callebaut)<br/>
          Mate quente 240ml<br/>
          Cappuccino tradicional italiano 240ml (Café expresso, leite, chocolate em pó e "crema di latte")<br/>
          Submarino belga 240ml (Mate com leite quente e pedaços de chocolate belga)<br/></p>
        </section>
        <section className="cardapio2">
          <h3>Mates Gelados</h3>
          <p>Beijo na boca (Mate batido com polpa de maracujá e acerola)<br/>
          Moka 240ml (Café expresso com leite, "crema di latte" e calda de chocolate)<br/>
          Chocacau (Mate batido com leite em pó, polpa de cacau e chocolate)<br/>
          Continental (Mate batido com leite em pó, polpa de morango e Guaraná)<br/>
          Delicias tropicais (Mate batido com leite em pó, polpa de morango, polpa de goiaba e Guaraná)<br/>
          Frescão (Mate batido com leite, polpa de morango e canela.)<br/>
          Gabriela (Mate batido com xarope de menta e polpa de fruta.)<br/>
          Ginger Mate (Mate batido com polpa de fruta e gengibre.)<br/>
          Homem aranha (Mate batido com leite em pó, polpa de manga, aveia e Guaraná.)<br/>
          Ginger Mate especial (Mate batido com polpa de fruta, gengibre e leite condensado.)<br/>
          Mate batido c/ leite (em pó)<br/>
          Mate c/ Guaraná (xarope de Guaraná.)<br/>
          Mate c/ groselha (xarope de groselha.)<br/>
          Mate c/ limão<br/>
          Mate c/ polpa de fruta<br/>
          Mate puro<br/>
          Sensação (leite em pó, polpa de morango e chocolate.)<br/>
          Mate c/ menta<br/>
          Mate pirueta (Mate com xarope de Guaraná, marapuama e extrato de açai)<br/>
          Mate suíço (Mate batido com leite condensado e polpa de fruta.)<br/>
          Tropical (Mate batido com xarope de Guaraná e polpa de fruta.)<br/>
          Tropicália (Mate batido com xarope de groselha e polpa de fruta.)<br/>
          Mate com Red Bull <br/></p>
          
          <h3>Shakes </h3>
          <p>Mate shake Nutella <br/>
          Mate shake crocante (chocolate crocante)<br/>
          Vitamate (Mate + leite em pó + 1 ingrediente.)<br/>
          Mate shake cappuccino <br/>
          Mate shake morango <br/>
          (cobertura a sua escolha.)<br/></p>
          
          <h3>Especiais Gelados</h3>
          <p>Cappuccino gelado<br/>
          Cappuccino shake de Nutella.<br/>
          Frappe de cappuccino<br/>
          Ovomaltine gelado<br/>
          Cappuccino gelado crocante de Ovomaltine<br/></p>
          
          <h3>Bebidas Energéticas</h3>
          <p>Banana lock (Mate batido com açaí, banana e xarope de Guaraná.)<br/>
          Bomba baiana (Mate batido com açaí, polpa de morango, xarope de guaraná e marapuama.)<br/>
          Jiu jitsu (Mate batido com açaí, leite em pó e xarope de Guaraná.)<br/>
          Pressão total (Mate batido com açaí, leite em pó, polpa de morango e xarope de Guaraná.)<br/>
          Bomba atômica (Mate batido com açaí, xarope de guaraná e guaraná em pó.)<br/>
          Bomba energética (Mate Batido com açaí e xarope de guaraná.)<br/>
          Pressão (Mate batido com açaí, polpa de morango e xarope de Guaraná.)<br/>
          Viagrinha (Mate batido com açaí, xarope de Guaraná e paçoca.)<br/>
          Açaíbull (Açaí batido com Red Bull e xarope de Guaraná)<br/></p>
          
          <h3>Doces</h3>
          <p>Brownie<br/>
          Alfajor<br/>
          Croissant de chocolate <br/>
          Pão de mel <br/>
          Baby churros (6 unidades)<br/>
          Cookie de baunilha com gotas de chocolate <br/>
          Brigadeiros sortidos<br/>
          Trufas<br/></p>
        </section>
      </section>
      </>
      );
}