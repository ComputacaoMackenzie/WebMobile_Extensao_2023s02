

export default function AllNaturalFit() {
    return (
        <>
        <h1> All natural fit </h1>
        <section className ="loja">
        <section className ="cardapio1">      
            <h2>Cardapio</h2>
            <h3>SALADA</h3>
            <p>Caesar Salad<br/>
            Alface americana , frango  filetado , queso parmesio , croutons e molho caesar <br/>
            Light <br/>
            Mix de alfaces americana e crespa , cenoura , abacaxi , peito de peru queso branco e croutons<br/>
            Oriental <br/>
            Mix de afaces americana e crespa broto de feia concura , quinos , tomate , gergelim , croutons e molho havaland <br/>
            Verão <br/>
            Mis do alfaces americana o crespa cenoura , milho , frango desfiado quejo branco e croutons<br/><br/>
            </p>
            
            <h3>TAPIOCAS</h3>
            <p> 
            SALGADAS   <br/>
            Frango desfiado  <br/>
            Frango desfiado tomate  <br/>  
            Peito de peru   <br/>
            Quejo branco  <br/>
            X - ovos mexidos com mussarla  <br/>
            Abobrinto grelhada com mussarla   <br/>
            PREMIUM   <br/>
            Salmão grelhado com cream cheese   <br/>
            DOCES   <br/>
            Banana com leite condensado   <br/>
            Coco com  leite condensado   <br/>
            Morango com nutela  <br/>
            Banana com Nuttal   <br/>
            Banana com doce de leite Aviação
            <br/><br/></p>
        </section>
        <section className ="cardapio2">
            <h3>WRAP</h3>
            <p> Peito de Peru<br/>
            Frango <br/>
            Bauru<br/>
            Vegetariano<br/>
            Vegan<br/>
            <br/></p>
            
            <h3>POKES</h3>
            <p> SALMÃO <br/>
            Arroz gohan , salmão cru emcubos manga em cubos pepino em rodelas , cenoura ralada , coco crocante , cebola roxa fatiada gergelim crispy de nori cebolinha echips de batata doce <br/>
            SALMÃO PHILADELPHIA <br/>
            Arroz gohan , salmão cru em cubos , cream cheese , crispy  non gergelim , cebolinha e chips de batata - doce<br/>
            SHIMEJI ( VEGANO )<br/>
            Arroz gohan , shimej , pepino em  rodelas , abacate em tiras de brócolis , crispy denori , gergelim  cebolinhaechos de batata doce <br/>
            FRANGO <br/>
            Arroz gohan , fie de frango grelhado em tiras , cenoura falada , abacaxi em cubos tomate - cereja crispyde norgergelim , cebolinha chips de batata - doceo<br/><br/></p>
        </section>
        <section className ="cardapio3">
            <h3>BEBIDAS </h3>
            <p>Aguá sem gás<br/>
            Aguá com gás<br/>
            Chá Gelado<br/>
            Suco Natural<br/>
            Laranja | Limão | Melancia <br/><br/>
            </p>   
        </section> 
        </section>
        </>
    );
}