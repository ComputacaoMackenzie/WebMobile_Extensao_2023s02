import Link from "next/link";

export default function Menu() {
  return (
    <section className="menu">
      <Link href="pagina1">Predio 19</Link>
      <Link href="pagina2">Predio 45</Link>
    </section>
  );
}
