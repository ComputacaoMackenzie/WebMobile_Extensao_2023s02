
export default function CasaDoPao() {
    return (
        <>
         <h1> Casa do Pão de Queijo</h1>   
        <section class ="loja">
        <section class ="cardapio1">   
            <h2>Cardapio</h2>
            <h3>SANDUÍCHES</h3>
            <p>Queijo Quente Mineirinho Grill<br/>
            Club Light | Club Light Centeio<br/>
            Misto Presunto e Queijo Grill<br/>
            Frango Grill<br/>
            Beirute de Frios Grill<br/>
            Beirute de Peru Grill<br/>
            Beirute de Rosbife grill<br/>
            Italiano Ciabatta Grill<br/>
            </p>
            <h3>PANINI</h3>
            <p>Presunto e Queijo<br/>
            Queijo Branco<br/>
            Mussarela com Tomate Seco<br/></p>
            <h3>FOLHADO SALGADO</h3>
            <p>Peito de Peru e <br/>
            Frango com Requeijão<br/>
            Palmito <br/></p>
        </section>
        <section class ="cardapio2">
            <h3>PASTEL DE FORNO DA VOVÓ</h3>
            <p>Frango com milho<br/>
            Carne<br/>
            Ricota com peito de peru<br/>
            Espinafre com ricota<br/></p>
            <h3>PÃO DE QUEIJO</h3>
            <p>Requeijão da Casa<br/>
            Requeijão com Azeitona<br/>
            Doce de Leite<br/>
            </p>
            <h3>DOCES DA CASA</h3>
            <h3>COOKIESA</h3>
            <p> Baunilha com gotas de Chocolate<br/>
            Chocolate com gotas de Chocolate<br/>
            BRIGADEIRO<br/>
            QUINDIM<br/></p>
            <h3>BOLO CASEIROA</h3>
            <p>Cenoura<br/>
            Milho<br/>
            Chocolate</p>
        </section>
        <section class ="cardapio3">
            <h3>BEBIDAS FRIAS</h3>
            <h3>SHAKES</h3>
            <p>Nescau Shake<br/>
            Cappuccino Shake<br/></p>   
            <h3>BEBIDAS QUENTES</h3>
            <p><br/>Café Espresso com Leite<br/>
            Café Tricolore<br/>
            Chocolate Quente<br/>
            Chocolates Especiais: Amora e Baunilha<br/>
            Café com Chantilly<br/>
            Chá<br/>
            Mochas Caramelo e Chocolate<br/>
            Cappuccino<br/>
            </p>
        </section> 
        </section>
        </>
    );
}