
export default function Bobs() {
    return (
        <>
        <h1> Bob's</h1>  
        <section className ="loja">
        <section className ="cardapio1">       
            <h2>Cardapio</h2>
            <h3>SANDUÍCHES</h3>
            <p>Bob's Bacon de Responsa<br/>
            Super Cheddar de Responsa<br/>
            Mega Queijo de Responsa<br/>
            Big Bob<br/> 
            Big Bob Frango<br/>
            Cheddar Australiano <br/>
            Double Cheese<br/>
            Bob's Premium<br/>
            Chicken Bacon<br/>
            Crispy Bacon<br/>
            Tentador Carne<br/>
            Tentador Frango<br/>
            Bob's Costela<br/>
            Salada Fatuche<br/>
            Bob's Costela Dois Queijos e Bacon<br/> 
            Chicken Crispy<br/>
            Cheese Egg<br/>
            Bob's Burger Frango<br/>
            Cheddar Australiano Frango<br/>
            Double Barbecue Cheese<br/>
            Cheese Salad<br/>
            Bob's Burger<br/>
            Bob's Cheddar<br/> 
            Cheeseburger <br/>
            Cheeseburger Frango<br/>
            Cheddar Frango<br/>
            Double Cheese Frango<br/>
            Bob's Burger Veggie Carne<br/>
            Big Bob Veggie Carne <br/>
            Cheddar Australiano Veggie Carne<br/>
            Double Cheese Veggie Carne<br/>
            Cheeseburger Veggie Carne<br/>
            Cheddar Veggie Carne<br/></p>
        </section>
        <section className ="cardapio2">
            <h3>ACOMPANHAMENTO</h3>
            <p> Batata MEGA 4 Queijos e Bacon<br/>
            Batata Palito<br/>
            Batata Canoa Grande + Franlitos<br/>
            Batata Canoa<br/>
            Batata Ondulada<br/>
            Franlitos<br/>
            Refrigerantes<br/>
            Água mineral<br/>
            Wrap ( Atum)<br/></p>
            <h3>SALADAS </h3>
            <p>Salada com Frango<br/>
            Salada com Carne<br/>
            Salada Veggie<br/></p> 
            <h3> SOBREMESA</h3>
            <p>Milk Shake <br/>
            Big Cascão<br/>
            Bob's Max <br/>
            Milk Café Shake<br/>
            Sundae <br/>
            Casquinha <br/>
            Casquinha Recheada<br/>
            </p>
        </section>
        </section>
        </>
    );
}