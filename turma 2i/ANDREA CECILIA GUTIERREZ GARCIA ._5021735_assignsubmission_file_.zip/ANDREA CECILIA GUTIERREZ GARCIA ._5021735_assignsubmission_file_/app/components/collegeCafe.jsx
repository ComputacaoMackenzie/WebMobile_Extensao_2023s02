
export default function ColegeCafe() {
    return (
        <>
        <h1> College café </h1>  
        <section class="loja">
        <section class="cardapio1"> 
        <h2>Cardapio</h2>
        <h3>CROISSANTS</h3>
        <p> Presunto e queijos<br />
        Quatro queijos <br />
        Peru com cream Cheese <br />
        Calabresa <br />
        Frango com requeijão <br />
        Doguinho <br />
        Folhado queijo minas <br />
        Chocolatel<br /><br /></p>
        
        <h3>SALGADOS</h3>
        
        <p>Coxinha grande <br />
        Quiche alho poró <br />
        Quiche tomate e manjericão <br />
        Tortinha frango <br />
        Tortinha palmito <br />
        Esfiha carne<br />
        Esfiha calabresaMinis <br />
        Empanada de carne<br /><br /></p>
        
        <h3>MINIS</h3>
        
        <p>Mini Coxinha <br />
        Bolinha de queijo <br />
        Enroladinho de salsicha<br /><br /></p>
        
        </section>
        <section class="cardapio2">
        <h3>COMBOS BURGERS </h3>
        <p>COMBO COM FRITAS + REFRI OU SUCO LARANJA ( 300 ML )<br />
        1 PCQ <br />
        Pão + carne + queijo <br />
        2 PCQ LUXO <br />
        Pão + carne + queijo + molho da casa + picles<br />
        3 XISSA <br />
        Pão + carne + queijo + maionese + alface + tomate<br />
        4 BONION<br />
        Pão + carne + queijo + cebola caramelizada + maionese + alface <br />
        5 BACON É VIDA <br />
        Pão + carne + queijo + bacon + molho da casa + picles <br />
        6 UEGG <br />
        Pão + carne + queijo + ovo frito na mantega + bacon + maionese<br /><br /></p>
        
        <h3>BEBIDAS QUENTES</h3>
        
        <p><br/>Espresso Curto<br />
        Espresso Longo<br />
        Cappuccino<br />
        Moccaccino<br />
        Café com Leite<br />
        Chocolate<br />
        Chocoleite<br />
        Macchiato<br />
        Cappuccino Canela<br />
        Cappuccino Avelã<br /><br /><br/></p>
        </section>
        </section>  
        </>   
    );
}