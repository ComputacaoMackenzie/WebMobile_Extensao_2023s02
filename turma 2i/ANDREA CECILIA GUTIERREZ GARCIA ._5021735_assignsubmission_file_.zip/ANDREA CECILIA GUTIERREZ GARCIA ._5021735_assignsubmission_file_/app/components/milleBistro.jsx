
export default function MilleBistro() {
    return (
        <>
        <h1> Mille bistro </h1>
        <section className="loja">
        <section className="cardapio1">   
            <h2>CAFÉ DA MANHÃ</h2>
            <h3>Bebidas quentes</h3>
            <p>Café coado <br/>
            Café com leite<br/><br/></p>
            <h3>Sucos</h3>
            <p>Laranja<br/> Limão <br/>Maracujá <br/>Abacaxi<br/>Frutas vermelhas<br/><br/></p>
            <h3>Bebidas geladas</h3>
            <p>Morango com leite <br/>
            Iogurte batido<br/><br/></p>
            <h2>ALMOÇO</h2>
            <h3>Pratos executivos</h3>
            <p>Polpetone a parmegiana: fettuccine molho sugo<br/>
            File de carne acebolado: arroz, feijão e saladinha<br/>
            File de carne à parmegiana: arroz, batata fritas<br/>
            File de carne à cavalo: arroz, feijão, ovo, fritas e saladinha<br/>
            Filé de carne a milanesa: arroz, feijão e fritas<br/>
            File de frango a milanesa: arroz, feijão e fritas <br/>
            File de frango com legumes: arroz integral, legumes na manteiga e saladinha <br/>
            File de frango a cavalo: arroz, feijão, ovo, fritas e saladinha<br/>
            File de frango a parmegiana: arroz e fritas <br/>
            File de peixe ao molho ervas finas: saint peter, arroz, legumes na manteiga e saladinha<br/>
            Strogonoff de carne: arroz e batata palha<br/>
            Strogonoff de frango: arroz e batata palha <br/>
            Berinjela a parmegiana (vegetariano): arroz integral e saladinha<br/>
            Omelete: (queijo, presunto, tomate e cebola, arroz, feijão e saladinha)<br/><br/></p>
            <h3>Kids</h3>
            <p>Strogonoff de frango (arroz e batata palha)<br/>
            Da casa (arroz, feijão, iscas de fraldinha)<br/>
            Almondegas (arroz, feijão, 2 almondegas e saladinha)<br/>
            Filé frango grelhado (arroz, feijão e fritas)<br/><br/></p>
            <h3>Saladas</h3>
            <p>Salada caesar (alface americana, parmesão, crountons e filé de frango)<br/>
            Salada da casa (folhas verdes, tomate cereja, cenoura, mussarela e filé de frango)<br/><br/></p>
            <h3>Omeletes</h3>
            <p>Omelete completo (queijo, tomate, cebola e presunto)<br/>
            Omelete com saladinha (queijo, tomate, cebola e presunto)<br/><br/></p>
        </section>
        <section className="cardapio2">
            <br/><br/><br/>
            <h3>Lanches</h3>
            <p>Pão na chapa <br/>
            Pão com ovo<br/>
            Queijo quente<br/>
            Misto quente <br/>
            Seladinho de requeijão.<br/>
            Wrap (atum ou frango)<br/><br/></p>
            <h3>Tapioca</h3>
            <p>Pizza<br/>
            2 queijos<br/>
            Atum com tomate<br/>
            Frango com queijo<br/>
            Nutella.<br/><br/></p>
            <br/><br/><br/><br/><br/>
            <h3>Massas</h3>
            <p>Molhos a sua escolha: sugo, branco, rose e bolonhesa<br/>
            Nhoque de batata<br/>
            Spaguetti<br/>
            Penne<br/>
            Fettuccine<br/> 
            Ravioli verde de bufala<br/>
            Ravioli de carne<br/>
            Lasanha presunto e queijo a bolonhesa <br/>
            Lasanha mussarela com molho branco <br/>
            Ravioli zucca de abobora (vegetariano)<br/><br/></p>
            <p>Acompanhamentos massas <br/>
            File de frango a milanesa<br/>
            File de frango grelhado<br/><br/></p>
            <p>Acompanhamentos gerais:<br/>
            File de carne a milanesa. <br/>
            File de frango grelhado<br/>
            File de frango a milanesa.<br/>
            Feijão, arroz, legumes ou saladinha<br/>
            Fritas<br/><br/></p>
            <h3>Lanches</h3>
            <p>Carne louca na ciabata (carne temperada desfiada, mussarela e fritas) <br/>
            File de frango c/ queijo na ciabata (mussarela e fritas)<br/><br/></p>
            <h3>Consultar disponibilidade em loja</h3>
            <p>Refrigerantes, sucos, chás e água (consultar disponibilidade em loja)<br/><br/>
            Balas, chicletes e doces de embalagem pequena (consultar disponibilidade em loja)<br/><br/></p>
        </section>
        </section>
        </>
    );
}