

export default function Borges() {
    return (
        <>
        <h1> Borges </h1> 
        <section className="loja">
        <section className="cardapio1">  
            <h3>Omeletes</h3>
            <p>Dois ovos mexidos no pão francês<br/>
            Dois ovos mexidos + queijo prato no pão francês<br/>
            Dois ovos mexidos + queijo prato + presunto no pão francês<br/><br/>
            OPCIONAIS:<br/>
            + Tomate <br/>
            + Requeijão<br/><br/></p>
            <h3>Doces</h3>
            <p>Bolos<br/>Croissants<br/><br/></p>

            <h3>Bebidas</h3>
            <p>Café<br/>Capuccino<br/>
            Chocolate<br/>
            Sucos Naturais<br/><br/></p>
        </section>
        <section className="cardapio2">
            <h3>Lanches</h3>
            <p>Misto Quente <br/>
            Americano<br/>
            Bauru<br/>
            X Peito Peru<br/>
            Pão na chapa <br/>
            Pão com ovo<br/>
            Pão c/ requeijão <br/>
            X Burguer<br/>
            Hamburguer <br/>
            Pão de Queijo<br/>
            Pão de queijo recheado<br/>
            Baguete recheada<br/>
            Tostex<br/>
            Salgados (consultar disponibilidade)<br/><br/></p>
            <h3>Consultar disponibilidade em loja</h3>
            <p>Refrigerantes, sucos, chás e água (consultar disponibilidade em loja)<br/><br/>
            Balas, chicletes e doces de embalagem pequena (consultar disponibilidade em loja)<br/><br/></p>
        </section>
        </section>
        </>
    );
}