
export default function Armeus() {
    return (   
        <> 
        <h1> Armeus </h1>
     <section class="loja">
<section class="cardapio1"> 
<h2>Cardapio</h2>
<h3>BUFFET</h3>
<h3>PRATO NOTURNO </h3>
<p>Charuto Repolho<br />
Arroz + Saladinha + um tipo de Pasta<br />
Charuto Uva<br />
Arroz + Saladinha + Um tipo de Pasta<br />
Espeto Frango <br />
Arroz + Saladinha + um tipo de Pasta <br />
Espeto Mignon Suino<br />
Arroz Saladinha + Lim tipo de Pasta <br />
Kibe de Bandeja <br /> Arroz + Saladinha + um tipo de Pasta <br />
Espeto Kafta <br />
Arroz + Saladinha + Um tipo de Pasta <br /><br />
Todos os pratos acompanham : Arroz do dia + Pão árabe + Uma<br /> Pasta sua escolha ( Homus | Coalhada | Babaganush ) <br /><br />
Salada Fatuche<br />
Aface Romana + Tomate + Rabanete + Pepino + Pimentão Vermelho<br /> + Cebola Roxa + Pao Arabe + Moho Fatuche<br />
Salada Arameus <br />
Mix Fohas + Grão De Bico + Cenoura Ratata + Beteraba Ralata + <br />Pão Arabe + Molho Rose<br /><br />
</p>

<h3>SALGADOS</h3>

<p> Kibe Frito  <br />
Esfiha Aberta e Fechada  <br />
Falafel <br />
Kibe de Abobora <br />
Kibe de Bandeja Recheadoo<br /><br /></p>

<h3>LANCHES</h3>
<p> Shawarma<br />
Arais<br />
Kebab de Frango Shish Taouk <br />
Kebab de Falafel<br />
X- Kafta Salada<br />
Kebab de Mignon Suino<br />
Kebab de Kafta<br />
Kebab Sujuk ( Kafta Apimentada ) <br />
Kebab Fajita <br />
Beirute Frango<br />
Beirute Arameus<br /><br /></p>

</section>
<section class="cardapio2">
<h3>PROMOÇÃO MANHÃ</h3>
<p> Pão na Chapa Arameus <br />
Pão Arabe com Manteiga na chapa <br />
Pão com Ovo Mexido<br />
Misto Quente<br />
</p>

<h3>WRAP</h3>
<p>  Wrap ( Frios )<br />
Pão Árabe + Peito de Peru e Mussarela + Tomate + Folhas <br />
Wrap ( Frango )<br />
Pão Árabe + Frango Desfiado + Tomate + Folhas<br />
Wrap ( Atum) <br />
Pão Árabe + Atum desfiado + Tomate + Folhas<br/>
Wrap ( Carne )<br />
Pão Árabe + Carne desfiada + Tomate + Folhas<br />
Wrap ( Queijo Branco )<br />
Pão Árabe + Queijo Branco + Tomate Seco<br /><br/></p>


<section class="cardapio3">
<h3>BEBIDAS </h3>
<p>Aguá sem gás<br />
Aguá com gás<br />
Café Expresso <br />
Café c / Leite <br />
Refrigerantes<br />
Suco Lata Sabores <br />
Chá Gelado<br />
Suco Natural<br />
Laranja | Limão | Melancia <br /><br /></p>

<h3> SOBREMESA</h3>

<p>Bolo Arameus ( Pedaço )<br />
Bolo Seco Diversos ( Pedaço )<br />
Doces Árabes Diversos <br />
Salada de Frutas<br />
Mousse ( Diversos Sabores )<br />
Tortinhas ( Sabores )<br />
Bolo Pote <br /><br /></p>
</section>
</section>
</section>
       </>
    );
}