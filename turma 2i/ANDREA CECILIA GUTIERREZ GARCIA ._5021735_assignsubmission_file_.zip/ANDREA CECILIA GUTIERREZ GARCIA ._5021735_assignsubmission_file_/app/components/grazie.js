
export default function Grazie() {
    return (
        <>
         <h1> Grazie </h1>   
        <section className ="loja">
        <section className ="cardapio1">      
            <h2>Cardapio</h2>
            <h3>SOPAS E CALDOS</h3><br/>
            <p> À CONSULTAR OS SABORES DO DIA COM NOSSOS ATENDENTES</p><br/>
            
            <h3>MASSAS </h3>
            <p>Espaguete<br/>
            Penne<br/>
            Fettuccine<br/>
            Fettuccine verde<br/> 
            Lasanha á bolonhesa<br/>
            Nhoque de batata ao sugo<br/>
            Ravioli verde com muçarela de bufálo<br/>
            </p>
        
            <h3>ACOMPANHAMENTOS PARA MASSAS </h3>
        
            <p>File de frango à milanesa  <br/>
            Almôndegas de carne<br/>
            Saladinha verde <br/> 
            Batata frita <br/></p>
            
            <h3>PIZZAS </h3>
            <p>  Muçarela<br/>
            Frango com catupiry<br/>
            4 queijos <br/>
            Calabresa<br/>
            Portuguesa<br/>
            Margherita<br/>
            Chocolate<br/></p>
            
        </section>
        <section className ="cardapio2">
            <h3>BEBIDAS </h3>
            <p>Aguá sem gás<br/>
            Aguá com gás<br/>
            Refrigerantes<br/>
            Suco Natural<br/></p> 

            <h3> À LA CARTE</h3>
            <p> Salada grazie<br/>
                Salada caesar <br/>
                File de frango grelhado com legumes <br/> 
                File de frango grelhado com fritas <br/>
                File de frango à milanesa com fritas <br/>
                File de frango a cavalo <br/>
                File de frango à parmegiana <br/>
                Filé de carne grelhado com fritas <br/>
                Filé de carne à parmegiana <br/>
                File de carne a cavalo <br/>
                Filé de carne acebolado <br/>
                Filé de carne à milanesa<br/>
                Strogonoff de carne <br/>
                Strogonoff de frango<br/>
                Panquecas <br/>
                Omelete<br/>
            </p>
        </section>
        </section>
        </>
    );
}