import Link from "next/link";
import Menu from "./Menu";

export default function Navigation() {
  return (
    <nav>
      <Link href="/">
        <img src="33735.png" className="logo" />
      </Link>
      <Menu />
    </nav>
  );
}
