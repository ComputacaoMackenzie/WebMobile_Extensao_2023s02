export default function Home() {
  return (
      
  <article class="local">
    <section class="separa">
      <p id="intro">
        Facilitando a Experiência Gastronômica Universitária<br/><br/>

Nos campus universitários, a busca por opções de refeições variadas e acessíveis é uma constante entre os estudantes. Neste contexto, a implementação de um site consolidando os cardápios dos restaurantes locais apresenta uma série de vantagens significativas.
        <br/><br/>
        Cardápios dos restaurantes e lanchonetes das praças de alimentação do Mackenzie, localizadas no Prédio 19 e no Prédio 45.</p>
    </section>
    <br/>
    <section class="separa">
      <p class="pred">Prédio 19: </p>
      <p class="nomes">Casa do Pão de Queijo <br/>Arameus <br/>College Café<br/>Bobs<br/>Grazie<br/>Candy place gourmet<br/>All Natural Fit</p>  
    </section>
    <br/>
    <section class="separa">
      <p class="pred">Prédio 45: </p>
      <p class="nomes">Rei do Mate <br/>Mille Bistro <br/>Borges</p>
    </section>
  </article>

  );
}
