"use client";
import Armeus from "../components/armeus";
import AllNaturalFit from "../components/allnatural";
import Bobs from "../components/bobs";
import CasaDoPao from "../components/casaPaoDe";
import CandyPlaceGourmet from "../components/candyPlace";
import ColegeCafe from "../components/collegeCafe";
import Grazie from "../components/grazie";

export default function Pagina1(props) {
  console.log(props);

  return (
    <main>
      <CasaDoPao/>
      <Armeus />
      <Bobs/>
      <CandyPlaceGourmet/>
      <ColegeCafe/>
      <Grazie/>
      <AllNaturalFit/>
    </main>
  );
}
