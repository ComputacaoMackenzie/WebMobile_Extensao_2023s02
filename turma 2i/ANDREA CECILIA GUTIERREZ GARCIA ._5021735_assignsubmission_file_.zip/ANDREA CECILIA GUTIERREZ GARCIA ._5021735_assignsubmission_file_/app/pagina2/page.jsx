"use client";
import Borges from "../components/borges";
import MilleBistro from "../components/milleBistro";
import ReiDoMate from "../components/reiDoMate";

export default function Pagina2() {
  return (
    <main>
      <h1>Prédio 45</h1>
      <Borges/>
      <MilleBistro/>
      <ReiDoMate/>
    </main>
 );
}