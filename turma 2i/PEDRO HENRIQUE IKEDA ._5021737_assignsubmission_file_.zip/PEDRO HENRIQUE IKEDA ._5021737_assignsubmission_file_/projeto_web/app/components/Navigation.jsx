import Menu from "./Menu";
import Link from "next/link";

export default function Navigation() {
  return (
    <nav>
      <Link href="/" className="logoLink">
        <h1 className="logo">Lab GamesVR</h1>
      </Link>
      <Menu />
    </nav>
  );
}
