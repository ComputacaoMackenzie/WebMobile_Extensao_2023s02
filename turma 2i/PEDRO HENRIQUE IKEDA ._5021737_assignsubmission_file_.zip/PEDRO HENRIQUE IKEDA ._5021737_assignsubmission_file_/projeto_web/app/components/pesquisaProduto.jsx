export default function Produto({produto}) {
    return (
        <section
            key={produto.position}
            className="produto"
        >
        <div className="produto_titulo">{produto.title}</div>
        <img src={produto.imageUrl} alt="produto" />
    </section>
    )
}