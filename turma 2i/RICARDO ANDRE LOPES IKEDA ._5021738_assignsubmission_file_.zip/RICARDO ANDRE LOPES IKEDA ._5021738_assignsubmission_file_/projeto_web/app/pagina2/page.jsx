import Link from "next/link";
import Image from "next/image";

import PapeteImg from "../../public/images/papete.png"
import Skate from "../../public/images/skate.png"

import "./pagina2.css"

import React from 'react';


export default function Pagina2() {
  return (
    <main>
      <h1 className='titulo'>Projetos</h1>
      <hr></hr>
      
      <section className="projetos">
        <article className="card">
          <h1>Desenvolvimento de um jogo sério controlado por dispositivo wearable para exercícios de dorsiflexão e flexão Plantar</h1>
          <Image src={PapeteImg} width={300} height={300} alt="Papete" className="cardImage"></Image>
          <Link href={"https://www.researchgate.net/profile/Bruno-Da-Silva-Rodrigues/publication/345753664_Desenvolvimento_de_um_Jogo_Serio_Controlado_por_Dispositivo_Wearable_para_Exercicios_de_Dorsiflexao_e_Flexao_Plantar/links/5faefafc299bf10c367c4510/Desenvolvimento-de-um-Jogo-Serio-Controlado-por-Dispositivo-Wearable-para-Exercicios-de-Dorsiflexao-e-Flexao-Plantar.pdf"}>Link para o artigo</Link>
          <hr />

        </article>

        <article className="card">
          <h1>Desenvolvimento de um jogo sério integrado a um dispositivo skateboard para treinamento de equilíbrio postural</h1>
          <Image src={Skate} width={300} height={300} alt="Skate" className="cardImage"></Image>
          <Link href={"https://www.conic-semesp.org.br/anais/files/2022/trabalho-1000009080.pdf"}>Link para o artigo</Link>
          <hr />

        </article>

      </section>

    </main>
  );
}
