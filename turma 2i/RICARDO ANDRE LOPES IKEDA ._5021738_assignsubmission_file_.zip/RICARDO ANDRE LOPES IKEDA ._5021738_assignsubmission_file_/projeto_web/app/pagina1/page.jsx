import React from 'react';
import Link from "next/link";

import "./pagina1.css"

import ProductCard from "../components/ProductCard";

import BreadboardImg from "../../public/images/breadboard.jpg";
import ButtonImg from "../../public/images/button.jpg";
import Hc06Img from "../../public/images/hc06.jpg";
import JumperImg from "../../public/images/jumper.jpg";
import Mpu6050Img from "../../public/images/mpu6050.webp";
import NrfImg from "../../public/images/nrf24l01.jpg";
import PotenciometroImg from "../../public/images/potenciometro.webp";
import ResistorImg from "../../public/images/resistor.jpg";
import ArduinoImg from "../../public/images/arduino.jpg";



export default function Pagina2() {



  return (
    <main >

      <h1 className='titulo'>Dispositivos</h1>
      <hr></hr>

      <div className='vitrine'>
        <ProductCard name="Arduino" imageName={ArduinoImg} qty={3} search="Arduino"/>
        <ProductCard name="Breadboard" imageName={BreadboardImg} qty={6} search="Breadboard"/>
        <ProductCard name="Button" imageName={ButtonImg} qty={10} search="Button"/>
        <ProductCard name="HC06" imageName={Hc06Img} qty={1} search="HC06"/>
        <ProductCard name="Jumper" imageName={JumperImg} qty={100} search="Jumper"/>
        <ProductCard name="MPU 6050" imageName={Mpu6050Img} qty={2} search="MPU6050"/>
        <ProductCard name="NRF24L01" imageName={NrfImg} qty={3} search="NRF24L01"/>
        <ProductCard name="Potenciômetro" imageName={PotenciometroImg} qty={1} search="Potenciometro"/>
        <ProductCard name="Resistor" imageName={ResistorImg} qty={40} search="Resistor"/>
      </div>
      

    </main>
  );
}
