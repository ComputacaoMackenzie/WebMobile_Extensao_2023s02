import Link from "next/link";


export default function Pagina2() {
  return (
    <main>
      <article>
          <h1 className='titulo'>Grupo:</h1>
          <hr></hr>

          <ul className="group">
              <li>Ricardo Andre Lopes Ikeda - TIA 32158378</li>
              <li>Pedro Henrique Ikeda - TIA 32016344</li>
          </ul>
      </article>
    </main>
  );
}
