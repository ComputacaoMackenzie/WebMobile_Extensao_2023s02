import Link from "next/link";

export default function Menu() {
  return (
    <section className="menu">
      <Link href="/">Home</Link>
      {/* <Link href="pagina1?chave=valor">Página 1 com parâmetro</Link> */}
      <Link href="pagina1">Dispositivos</Link>
      <Link href="pagina2">Projetos</Link>
      <Link href="pagina3">Grupo</Link>
    </section>
  );
}
