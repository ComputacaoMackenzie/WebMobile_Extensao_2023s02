"use client"
import React, { useState } from "react";
import Image from "next/image";
import "./ProductCard.css"
// import MostrarProduto from "./fetchProduct.jsx"


export default function ProductCard(props) {

  const [contador, setContador] = useState(props.qty);

  // Função pra decrementar contador
  const decrementar = () => {
    setContador(contador - 1);
  }


  const [produtos, setProdutos] = useState();

  // const carregarProdutos = () => {

  // }


  const MostrarProdutos = () => {
    const axios = require('axios');
    let data = JSON.stringify({
      "q": props.search,
      "gl": "br",
      "hl": "pt-br",
      "autocorrect": false
    });
  
    let config = {
      method: 'post',
      url: 'https://google.serper.dev/shopping',
      headers: { 
        'X-API-KEY': 'aa22a69ffc8216bbed32cd60c2c9c6fb8d60c028', 
        'Content-Type': 'application/json'
      },
      data : data
    };
  
    axios(config)
    .then((response) => {
      setProdutos(response.data)
      console.log(JSON.stringify(response.data));
    })
    .catch((error) => {
      console.log(error);
    }, []);
    
    
    // if (!produtos) return null;
    // return (
    //   <div>
    //     {produtos.map((produto) => {
    //       return (
    //         <section
    //           key={produto.position}>
    //             <p>{produto.title}</p>
    //         </section>
    //       )
    //     })
    //     }
    //   </div>
    // )
      
  }
  

  return (
    <section className="produto">

      <div className="imageContainer">
        <Image
          src={props.imageName}
          alt="product image"
          width={500}
          height={500}
        />
      </div>

      <p>{props.name}</p>
      <p className="quantidade">{contador} Disponível</p>


      { contador > 0
        ? <button onClick={decrementar}>Reservar</button>
        
        // :<button onClick={MostrarProdutos}
        // : <button onClick={<MostrarProdutos search={props.name + "mercado livre"} />}>Mostrar Produtos</button>
  

        :(<button onClick = {MostrarProdutos} className="semEstoque">Mostrar opções de compra</button>)
        
        // :<MostrarProduto search={props.search + "mercado livre"}  />
        

      }
  

    </section>
  );
}
