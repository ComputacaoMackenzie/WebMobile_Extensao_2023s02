"use client"
import React, {useEffect, useState} from 'react';
import axios from 'axios';
// import Produto from './pesquisaProduto';

export default function MostrarProduto(props) {
 

    const carregarProdutos = () => {
        
        const axios = require('axios');
        const [produtos, setProdutos] = useState();


        
        let data = JSON.stringify({
        "q": props.search,
        "gl": "br",
        "hl": "pt-br",
        "autocorrect": false
        });


        let config = {
        method: 'post',
        url: 'https://google.serper.dev/shopping',
        headers: { 
            'X-API-KEY': 'aa22a69ffc8216bbed32cd60c2c9c6fb8d60c028', 
            'Content-Type': 'application/json'
        },
        data : data
        };


        axios(config)
        .then((response) => {
        console.log(JSON.stringify(response.data));
        })
        .catch((error) => {
        console.log(error);
        });

        
    }
    useEffect(carregarProdutos, []);
    
    
//     return (
//         <article>
//             <p>{response.title}</p>
//             <p>Testeee</p>
//         </article>
//     )
}

