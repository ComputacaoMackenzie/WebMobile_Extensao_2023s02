import Link from "next/link";

export default function Pagina2() {
  return (
    <main>


      {/* <Home /> */}
    </main>
  );
}
