import Head from 'next/head';
import "./about.css";


const About = () => {
  return (
    <div>
      <Head>
        <title>MACKENZIE</title>
        <link rel="stylesheet" href="/about.css" />
      </Head>

      <header className={styles.header}>
        <a href="#" className={styles.logo}>
          Mackenzie
        </a>

        <input type="checkbox" id="check" />
        <label htmlFor="check" className={styles.icons}>
          <i className="bx bx-menu" id="menu-icon"></i>
          <i className="bx bx-expand-alt" id="close-icon"></i>
        </label>

        <nav className={styles.navbar}>
          <a href="/">home</a>
          <a id="active" href="/about">
            História
          </a>
          <a href="/campus">Campus</a>
          <a href="/todo">To Do List</a>
        </nav>
      </header>

      <h1 className={styles.title}>Discover.</h1>

      <section>
        <p className={styles.sobre}>
        O Instituto Presbiteriano Mackenzie iniciou suas atividades em 1870, quando o casal de missionários presbiterianos George e Mary Ann Annesley Chamberlain chega à cidade de São Paulo.<br>

A senhora Chamberlain recebeu meninos e meninas para a escola que se iniciava, fazendo valer o princípio que permanece até os dias de hoje: não fazer distinção de sexo, credo ou etnia. No ano seguinte, foi constituída a Escola Americana, embrião do Colégio, que abrigava filhos de escravos e de famílias tradicionais.

Em 1876, agora na esquina das ruas Ipiranga e São João, a Escola Americana implantou dois novos cursos: Escola Normal e o Curso de Filosofia. Em 1879, Dona Maria Antônia da Silva Ramos, baronesa de Antonina, vendeu ao reverendo Chamberlain área de sua chácara em Higienópolis. Era o início de uma nova fase.

A fama da Escola Americana não se restringia ao Brasil, chegando aos ouvidos do advogado americano John Theron Mackenzie que, sem nunca ter vindo ao Brasil, deixou em testamento uma doação à Igreja Presbiteriana americana para que se construísse no Brasil uma escola de Engenharia. Desta forma, tem início o nome utilizado até hoje: Mackenzie.

Em fevereiro de 1896, teve início o curso da Escola de Engenharia Mackenzie, com diplomas ainda expedidos pela Universidade de Nova Iorque. Na década de 1940, foram criados novos cursos, como a Faculdade de Filosofia, Ciências e Letras (1946); Faculdade de Arquitetura (1947); e a Faculdade de Ciências Econômicas (1950). Com essas quatro escolas superiores, em 1952, o Mackenzie é reconhecido como universidade pelo então presidente Getúlio Vargas. Em 1955, teve início a primeira turma da Faculdade de Direito.

Em 1965, o Mackenzie nomeia Esther de Figueiredo Ferraz como reitora, a primeira mulher a assumir esse cargo em universidades brasileiras.

Já em 1970, criou-se a Faculdade de Tecnologia, suprindo a demanda por profissionais qualificados em cursos superiores da área.

Visando à formação global de seus alunos, o Mackenzie oferece a oportunidade de permanecerem na instituição desde a Educação Básica até a Pós-Graduação, em níveis de especialização (lato sensu), mestrado e doutorado (stricto sensu).

Atualmente, o Mackenzie está em diversos locais do país, oferecendo educação e saúde para as pessoas, cuidando do ser humano de forma integral. Prova disso são seus Colégios, Faculdades, Universidade e Hospitais, em unidades em São Paulo (SP), Alphaville (SP), Tamboré (SP), Brasília (DF), Campinas (SP), Palmas (TO), Rio de Janeiro (RJ), Castro (PR), Curitiba (PR) e Dourados (MS).

Além da Educação, área na qual tem sólida tradição e pioneirismo, o Mackenzie ainda se dedica à Saúde, tendo reforçado esse viés a partir de 2019 com a aquisição do Hospital Universitário Evangélico Mackenzie (HUEM) e também da Faculdade Evangélica Mackenzie do Paraná (FEMPAR). O Instituto Presbiteriano Mackenzie é ainda um Associado Efetivo da Associação Beneficente Douradense (ABD), entidade mantenedora do Hospital Evangélico Dr. e Sra. Goldsby King, tradicional instituição do Mato Grosso do Sul.

Cuidado com o ser humano criado à imagem e semelhança de Deus, autonomia, educação, saúde e dignidade. O Mackenzie olha para as pessoas como um todo, a partir da perspectiva cristã. É a fé que o move, que norteia sua missão, a qual se alegra em poder realizar diariamente desde sua fundação, em 1870.
        </p>
        <div className={styles.border}>
          <img className={styles.image_george} src="/transferir.jfif" alt="george" />
        </div>
      </section>
    </div>
  );
};

export default About;
