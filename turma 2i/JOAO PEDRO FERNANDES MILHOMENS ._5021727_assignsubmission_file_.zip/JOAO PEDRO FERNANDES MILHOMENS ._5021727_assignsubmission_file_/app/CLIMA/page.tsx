import "./clima.css";
import React, { useState } from "react";

const Weather = () => {
  const [temperature, setTemperature] = useState("--°C");
  const [city, setCity] = useState("");

  const getTemperature = async () => {
    const apiKey = "79508a390feb87bb2cb319c35a90376e";

    try {
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`,
      );
      const data = await response.json();

      if (data.main && data.main.temp) {
        const newTemperature = `${data.main.temp}°C`;
        setTemperature(newTemperature);
      } else {
        setTemperature("Não foi possível obter a temperatura");
      }
    } catch (error) {
      console.error("Erro ao obter dados da API:", error);
    }
  };

  return (
    <div className="weather-container">
      <h1>Temperatura Atual</h1>
      <input
        type="text"
        className="city-input"
        id="cityInput"
        placeholder="Digite a cidade"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <button className="get-temperature-btn" onClick={getTemperature}>
        Obter Temperatura
      </button>
      <div className="temperature" id="temperature">
        {temperature}
      </div>
    </div>
  );
};

export default Weather;
