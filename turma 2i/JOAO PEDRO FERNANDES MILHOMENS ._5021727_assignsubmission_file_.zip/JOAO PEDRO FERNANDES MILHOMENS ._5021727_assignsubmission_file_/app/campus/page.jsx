import "./campus.css";
import Link from "next/link";

export default function Campus() {
  return (
    <>
      <header className="header">
        <Link href="/" className="logo">
          Mackenzie
        </Link>
        <input type="checkbox" id="check" />
        <label for="check" className="icons">
          <i className="bx bx-menu" id="menu-icon"></i>
          <i className="bx bx-expand-alt" id="close-icon"></i>
        </label>
        <nav className="navbar">
          <Link href="/">home</Link>
          <Link href="about">História</Link>
          <a id="active" href="campus.html">
            Campus
          </a>
          <a href="#">Services</a>
        </nav>
      </header>

      <div className="container">
        <div className="bg-slide active">
          <div className="circle bg">
            <img src="/CAMPUS/higianopolis1.jpg" />
          </div>

          <div className="circle large">
            <img src="/CAMPUS/higianopolis1.jpg" />
          </div>

          <div className="circle small">
            <img src="/CAMPUS/higianopolis1.jpg" />
          </div>

          <div className="content-text">
            <div className="place">
              <h1>Higienópolis</h1>
            </div>

            <div className="country">
              <h2>Campus</h2>
            </div>
          </div>
        </div>

        <div className="bg-slide">
          <div className="circle bg">
            <img src="/CAMPUS/alphaville2.jpg" />
          </div>

          <div className="circle large">
            <img src="/CAMPUS/alphaville2.jpg" />
          </div>

          <div className="circle small">
            <img src="/CAMPUS/alphaville2.jpg" />
          </div>

          <div className="content-text">
            <div className="place">
              <h1>Alphaville</h1>
            </div>

            <div className="country">
              <h2>Campus</h2>
            </div>
          </div>
        </div>

        <div className="bg-slide">
          <div className="circle bg">
            <img src="/CAMPUS/Campinas3.jpg" />
          </div>

          <div className="circle large">
            <img src="/CAMPUS/Campinas3.jpg" />
          </div>

          <div className="circle small">
            <img src="/CAMPUS/Campinas3.jpg" />
          </div>

          <div className="content-text">
            <div className="place">
              <h1>Campinas</h1>
            </div>

            <div className="country">
              <h2>Campus</h2>
            </div>
          </div>
        </div>

        <div className="bg-slide ">
          <div className="circle bg ">
            <img src="/CAMPUS/colégio4.jpg" />
          </div>

          <div className="circle large">
            <img src="/CAMPUS/colégio4.jpg" />
          </div>

          <div className="circle small">
            <img src="/CAMPUS/colégio4.jpg" />
          </div>

          <div className="content-text">
            <div className="place">
              <h1>Colégio</h1>
            </div>

            <div className="country">
              <h2>Mackenzie</h2>
            </div>
          </div>
        </div>

        <div className="bg-slide ">
          <div className="circle bg">
            <img src="/CAMPUS/ead5.png" />
          </div>

          <div className="circle large">
            <img src="/CAMPUS/ead5.png" />
          </div>

          <div className="circle small">
            <img src="/CAMPUS/ead5.png" />
          </div>

          <div className="content-text">
            <div className="place">
              <h1>graduação</h1>
            </div>

            <div className="country">
              <h2>EAD</h2>
            </div>
          </div>
        </div>

        <div className="circle-darktransp"></div>

        <span className="line"></span>

        <span className="rotate-btn">
          <i className="bx bx-rotate-right"></i>
        </span>
      </div>
    </>
  );
}
