import "./globals.css";
import Link from "next/link";

export default function Home() {
  return (
    <>
      <header className="header">
        <Link href="/" className="logo">
          Mackenzie
        </Link>
        <input type="checkbox" id="check" />
        <label htmlFor="check" className="icons">
          <i className="bx bx-menu" id="menu-icon"></i>
          <i className="bx bx-expand-alt" id="close-icon"></i>
        </label>
        <nav className="navbar">
          <Link id="active" href="#">
            home
          </Link>
          <Link href="ABOUT">História</Link>
          <Link href="CAMPUS">Campus</Link>
          <Link href="CLIMA">clima</Link>
        </nav>
      </header>

      <section>
        <p>
          Explore o mundo acadêmico da Universidade Presbiteriana{" "}
          <strong>Mackenzie</strong> em nosso site e descubra oportunidades
          educacionais excepcionais.
        </p>
      </section>
    </>
  );
}
