import "./globals.css";
import Highlights from "./components/featured_collection/Highlights";

export default function Home() {
  return (
    <main className="flex items-center pt-1 flex-col justify-center">
      <Highlights />
    </main>
  );
}
