"use client";
import { useState } from "react";
import Right from "@/app/components/featured_collection/Right";
import EventosJson from "@/app/api/eventos.json";
import { ArrowRightIcon, ArrowLeftIcon } from "@heroicons/react/24/outline";

export default function Categoria(props) {
  const [page, setPage] = useState(0);

  const { searchParams } = props;
  const { id } = searchParams;
  const [eventos, setEventos] = useState(EventosJson["eventos"]);

  const id_destaque = EventosJson["destaque"];
  const destaque = eventos[id_destaque];
  const max_page = Math.ceil(Object.entries(eventos).length / 10);

  const pageUp = () => {
    if (page < max_page - 1) {
      setPage(page + 1);
    }
  };
  const pageDown = () => {
    if (page > 0) {
      setPage(page - 1);
    }
  };

  return (
    <main>
      <div className="flex flex-col hightlight-col">
        {Object.entries(eventos)
          .filter(([k, evento]) => evento.categoria == id)
          .slice(page * 10, page * 10 + 10)
          .map(([k, evento]) => {
            return <Right key={k} id={k} event={evento} />;
          })}
      </div>
      <div className="flex content-center mt-5 justify-around">
        <button onClick={pageDown}>
          <ArrowLeftIcon strokeWidth={2} className="h-9 w-9" />
        </button>
        <div className="flex items-center px-4">
          <p>
            {page + 1} / {max_page}
          </p>
        </div>
        <button onClick={pageUp}>
          <ArrowRightIcon strokeWidth={2} className="h-9 w-9" />
        </button>
      </div>
    </main>
  );
}
