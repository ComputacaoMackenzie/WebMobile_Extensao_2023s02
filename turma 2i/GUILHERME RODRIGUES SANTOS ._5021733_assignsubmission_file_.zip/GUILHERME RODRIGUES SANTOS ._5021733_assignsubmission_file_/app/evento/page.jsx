"use client";

import Link from "next/link";
import EventosJson from "@/app/api/eventos.json";
import TimeBar from "@/app/components/timebar/TimeBar";

export default function evento(props) {
  const { searchParams } = props;
  const { id } = searchParams;
  const evento = EventosJson["eventos"][id];

  if (evento != undefined) {
    return (
      <main>
        <div className="">
          <div className="">
            <div className="">
              <img
                className="border-2 border-black mt-3 mx-auto h-64"
                src={evento.imagem}
                alt={evento.titulo}
              />

              <h1 className="font-bold text-xl mt-5">{evento.titulo}</h1>
              <p className="text-gray-500 mt-2">{evento.subtitulo}</p>
              <p className="text-sm text-red-700">{evento.categoria}</p>
              <p className="text-gray-500 mt-2">{evento.descritivo}</p>
              <TimeBar data={evento.data} />
            </div>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="flex flex-col items-center justify-center">
      <h1 className="text-2xl pb-4 pt-1 font-bold">Evento não encontrado.</h1>
      <Link
        className="border-2 border-black rounded hover:text-sky-500"
        href="/"
      >
        Voltar
      </Link>
    </main>
  );
}
