import Link from "next/link";
import TimeBar from "@/app/components/timebar/TimeBar";

export default function Left({ id, event }) {
  return (
    <div>
      <Link href={`evento?id=${id}`}>
        <img
          className="border-2 border-black"
          src={event.imagem}
          alt={event.titulo}
          width="100%"
        />
        <h2 className="text-3xl pb-1 pt-1 font-bold"> {event.titulo} </h2>
        <p className="text-sm text-red-700">{event.categoria}</p>
      </Link>
      <p className="text-sm text-gray-700">{event.descritivo}</p>
      <div>
        <TimeBar data={event.data} />
      </div>
    </div>
  );
}
