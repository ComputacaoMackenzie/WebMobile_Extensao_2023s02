import Link from "next/link";
import TimeBar from "@/app/components/timebar/TimeBar";

export default function Right({ id, event }) {
  return (
    <div className="w-full flex my-2 items-center">
      <Link className="contents" href={`evento?id=${id}`}>
        <div
          className="w-1/5 h-full bg-cover bg-center border-2 border-black"
          style={{
            backgroundImage: `url("${event.imagem}")`,
            height: 100,
          }}
        ></div>
      </Link>
      <div className="pl-4">
        <Link className="contents" href={`evento?id=${id}`}>
          <h1 className="text-base font-bold">{event.titulo}</h1>
          <p className="text-sm text-gray-700">{event.subtitulo}</p>
          <p className="text-sm text-red-700">{event.categoria}</p>
        </Link>
        <TimeBar data={event.data} />
      </div>
    </div>
  );
}
