import { BookmarkIcon } from "@heroicons/react/24/outline";
import { useState } from "react";

export default function TimeBar({ data }) {
  const [clicked, setClicked] = useState(false);

  const click_bookmark = () => {
    setClicked(!clicked);
  };

  return (
    <div className="flex items-center">
      {!clicked && (
        <button
          onClick={click_bookmark}
          className="hover:bg-red-800 border-2 font-bold py-2 px-2 mx-2 rounded-full"
        >
          <BookmarkIcon strokeWidth={2} className="h-4 w-4" />
        </button>
      )}
      {clicked && (
        <button
          onClick={click_bookmark}
          className="bg-red-800 text-white border-2 font-bold py-2 px-2 mx-2 rounded-full"
        >
          <BookmarkIcon strokeWidth={2} className="h-4 w-4" />
        </button>
      )}
      <div> {data} </div>
    </div>
  );
}
