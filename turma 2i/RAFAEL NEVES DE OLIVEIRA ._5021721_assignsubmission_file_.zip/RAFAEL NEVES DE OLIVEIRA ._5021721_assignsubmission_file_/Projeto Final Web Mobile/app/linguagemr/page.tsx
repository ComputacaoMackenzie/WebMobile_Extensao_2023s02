import Image from "next/image";
import Pagina from "../Components/Pagina";
export default function Home() {
  return (
    <Pagina
      banner="tn-img-03.jpg"
      evento="LINGUAGEM R"
      desc="Prof. Anderson Adaime | FCI"
      dia="02/10"
      hora="09h15"
      predio="31"
      sala="401"
    />
  );
}