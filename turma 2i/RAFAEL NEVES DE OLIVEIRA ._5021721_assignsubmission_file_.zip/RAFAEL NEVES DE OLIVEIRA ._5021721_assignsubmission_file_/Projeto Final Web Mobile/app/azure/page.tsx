import Image from "next/image";
import Pagina from "../Components/Pagina";
export default function Home() {
  return (
    <Pagina
      banner="post_azure.png"
      evento="AZURE OPENAI"
      desc="Afonso Menegola | Microsoft"
      dia="02/10"
      hora="09h15"
      predio="46"
      sala=""
    />
  );
}