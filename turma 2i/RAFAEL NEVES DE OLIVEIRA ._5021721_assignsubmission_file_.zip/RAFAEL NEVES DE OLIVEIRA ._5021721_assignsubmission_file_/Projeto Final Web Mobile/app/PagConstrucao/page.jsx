import Link from "next/link";

export default function PagConst() {
    return(
        <section className="conteudo_pag_construcao">
            <h2 id="subtitulo_pag_construcao">Sinto Muito!</h2>
            <h1 id="titulo_pag_construcao">Página em Construção</h1>
            <img id="imagem_construcao" src="/construcao.PNG" alt="Desenho representativo de site em construção"/>
            <p id="texto_pag_construcao">Clique <Link className="nav_link_pag_construcao" href="/"><strong>aqui</strong></Link> para voltar para a Homepage.</p>
        </section>
    )
}