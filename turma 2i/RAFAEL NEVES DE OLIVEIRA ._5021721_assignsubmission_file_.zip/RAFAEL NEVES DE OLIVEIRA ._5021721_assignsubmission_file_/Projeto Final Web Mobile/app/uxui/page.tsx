import Image from "next/image";
import Pagina from "../Components/Pagina";
export default function Home() {
  return (
    <Pagina
      banner="tn-img-02.jpg"
      evento="UX UI"
      desc="Profa. Ana Grasielle | FCI"
      dia="02/10"
      hora="09h15"
      predio="24"
      sala="108"
    />
  );
}