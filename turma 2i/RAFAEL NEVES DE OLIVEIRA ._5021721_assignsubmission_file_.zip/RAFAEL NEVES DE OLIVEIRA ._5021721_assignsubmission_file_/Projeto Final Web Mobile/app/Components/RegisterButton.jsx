import Link from "next/link";

export default function RegisterButton() {
    return(
        <button className="registre">
            <span className="circulo" aria-hidden="true">
                <span className="icone seta"></span>
            </span>
            <span className="texto_botao"><Link className="texto_botao" href="PagConstrucao">Registre-se Agora</Link></span>
        </button>
    )
}