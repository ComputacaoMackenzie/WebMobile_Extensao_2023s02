import './Semana.css';
import Link from "next/link";
import RegisterButton from '../RegisterButton';

export default function Semana(props){
    return(
        <section>
            <section className="capa">
                <div className="bloco_titulo">
                    <div id="data">
                        <p>Dias {props.dias} de {props.mes}</p>
                        <p>Horário: {props.horario}</p>
                    </div>
                    <p id="titulo_evento">{props.titulo}</p>
                    <p className="convite">Venha Participar!</p>
                </div>
            </section>
            <section className="reg">
                <p className="convite">Garanta já a sua vaga!</p>
                <RegisterButton/>
            </section>
            <section className="infos">
                <p id="subtitulo">Sobre o Evento</p>
                <div className="textos">
                    <p>{props.paragrafo1}</p>
                    <p>{props.paragrafo2}</p>
                    <p>{props.paragrafo3}</p>
                    <p>{props.paragrafo4}</p>
                    <p>{props.paragrafo5}</p>
                </div>
            </section>
            <section className="cronograma">
                <p id="crono">CRONOGRAMA</p>
                <div className="eventos">
                    <p id="data_crono">02/10</p>
                    <div className="evento">
                        <p>08:00 - 09:00</p>
                        <p className="tipos">Keynote</p>
                        <Link className="nav_link" href="PagConstrucao">Environmental, Social and Governance</Link>
                    </div>
                    <div className="evento">
                        <p>09:00 - 011:00</p>
                        <p className="tipos">Oficina</p>
                        <Link className="nav_link" href="deeplearning">Deep Learning</Link>
                    </div>
                    <div className="evento">
                        <p>09:00 - 011:00</p>
                        <p className="tipos">Oficina</p>
                        <Link className="nav_link" href="uxui">UX e UI</Link>
                    </div>
                    <div className="evento">
                        <p>09:00 - 011:00</p>
                        <p className="tipos">Oficina</p>
                        <Link className="nav_link" href="linguagemr">Introdução à Análise de Dados com a Linguagem R</Link>
                    </div>
                    <div className="evento">
                        <p>09:00 - 011:00</p>
                        <p className="tipos">Palestra</p>
                        <Link className="nav_link" href="azure">Inovação Exponencial com Azure OpenAI</Link>
                    </div>
                </div>
            </section>
    </section>
    )
}