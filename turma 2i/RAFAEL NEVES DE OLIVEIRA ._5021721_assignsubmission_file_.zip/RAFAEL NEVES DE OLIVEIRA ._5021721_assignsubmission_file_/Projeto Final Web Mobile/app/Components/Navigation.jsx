import Link from "next/link";
import Menu from "./Menu";

export default function Navigation() {
  return (
    <nav>
      <Link href="/">
        <img src="logo.jpg" className="logo" alt="Logo Mackenzie"/>
      </Link>
      <h1>MackEventos</h1>
      <Menu/>
    </nav>
  );
}
