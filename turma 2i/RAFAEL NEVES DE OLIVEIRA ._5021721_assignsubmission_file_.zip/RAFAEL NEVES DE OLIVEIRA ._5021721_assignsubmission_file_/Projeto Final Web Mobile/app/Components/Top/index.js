import "./Top.css"

export default function Top(){
    return (
        <div className="top">
            <div className="mackeventos">
                <img src="logo.jpg" alt="Logo Mackenzie"/>
                <h1> MackEventos </h1>
            </div>
            <a href="#">HOME</a>
        </div>
    )
}