export default function Footer() {
    return (
      <footer>
        <p>Copyright &copy; <span class="tm-current-year">2023</span> Enzo
              Ferroni - 32318014 | Leonardo Hofjud - 32338880 | Rafael Neves -
              32344317</p>
      </footer>
    );
  }