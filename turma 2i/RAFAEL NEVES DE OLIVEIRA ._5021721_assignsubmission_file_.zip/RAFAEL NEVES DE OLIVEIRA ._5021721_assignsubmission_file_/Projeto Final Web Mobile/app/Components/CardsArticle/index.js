import "./CardsArticle.css"
import PropTypes from 'prop-types';
import Link from "next/link";

const CardArticle = (props) => {
  return (
        <Link className="cardArticle" href={props.link}>
          <img src={props.img} />
          <h2>{props.titulo}</h2>
        </Link>
  )
}

CardArticle.propTypes = {
    titulo: PropTypes.string.isRequired,
    img: PropTypes.string.required,
}

export default CardArticle