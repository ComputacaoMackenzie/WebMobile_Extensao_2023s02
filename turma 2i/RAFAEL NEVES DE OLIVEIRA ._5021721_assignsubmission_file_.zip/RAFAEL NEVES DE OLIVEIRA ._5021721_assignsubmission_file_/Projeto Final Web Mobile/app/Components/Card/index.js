  import Link from "next/link";
import "./Card.css"
  import PropTypes from 'prop-types';

  const Card = (props) => {
    return (
      <div className="card">
        <img src={props.img} />
        <h2>{props.titulo}</h2>
        <p>{props.texto}</p>
        <button><Link href={props.link}>SAIBA MAIS</Link></button>
      </div>
    )
  }

  Card.propTypes = {
    titulo: PropTypes.string.isRequired,
    img: PropTypes.string.required,
    texto: PropTypes.string.required,    
}

  export default Card