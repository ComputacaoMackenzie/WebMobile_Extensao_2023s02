import Link from "next/link";

export default function Menu() {
  return (
    <section className="menu">
      <Link href="/">Home</Link>
      <Link href="PagConstrucao">Calendário</Link>
    </section>
  );
}