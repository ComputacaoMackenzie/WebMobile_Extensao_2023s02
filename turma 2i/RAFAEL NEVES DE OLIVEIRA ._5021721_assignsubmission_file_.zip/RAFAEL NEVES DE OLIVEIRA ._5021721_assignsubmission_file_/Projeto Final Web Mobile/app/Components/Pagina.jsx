"use client";
import { useEffect, useState } from "react";
import "./pagina.css";
import Link from "next/link";

export default function Pagina(props) {
  const [temp, setTemp] = useState();
  const [chuva, setChuva] = useState();
  const [dia, setDia] = useState();

  const getTempo = () => {
    fetch(
      "https://api.open-meteo.com/v1/forecast?latitude=-23.5458&longitude=-46.6599&current=temperature_2m,is_day,rain&forecast_days=1",
    )
      .then((r) => r.json())
      .then((f) => {
        console.log(f);
        setTemp(f.current.temperature_2m);
        setChuva(f.current.rain);
        setDia(f.current.is_day);
      });
  };

  useEffect(getTempo, []);

  return (
    <div className="site">
      <img className="cima" src={props.banner}></img>
      <div className="infos">
        <div className="map">
          <div className="mapa">
            <div className="dia">
              <img src={dia == 1 ? "solis.png" : "noite.png"} />
            </div>
            <div className="temp">
              <h1>{temp}ºC</h1>
              <h2>{chuva}mm</h2>
            </div>
          </div>
        </div>
        <span className="barra"></span>
        <div className="general-info">
          <div className="nome">
            <h1 className="titulo">{props.evento}</h1>
          </div>
          <div className="desc">
            <h1>{props.desc}</h1>
          </div>
          <div className="sub-info">
            <h1 className="hora">
              <span class="indi">Data</span>
              <span>{props.dia}</span>
              <span>{props.hora}</span>
            </h1>
            <h1 className="local">
              <span className="indi">Local</span>
              <span>{props.predio}</span>
              <span>{props.sala}</span>
            </h1>
          </div>
          <div className="insc-area">
            <div className="insc-button">
              <a href="#">
                <span>INSCREVER-SE</span>
              </a>
            </div>
            <div className="home">
              <Link href="/" className="A">
                <img src="icons8-home-32.png"></img>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
