import "./Components/CardsArticle/"
import Banner from "./Components/Banner"
import Card from "./Components/Card";
import CardArticle from "./Components/CardsArticle";
import Link from "next/link";

export default function Home() {
  return (
    <div className="App">
      <Banner/>
      <div className="cards">
        <Card link="/SemanaFCI"
              img="./tech1.jpg"
              titulo = "SEMANA DE TECNOLOGIA E INFORMAÇÃO"
              texto="É um evento organizado pela Faculdade de Computação e Informática, que reúne todos os alunos da graduação, para uma semana com hackathons, keynotes,  oficinas e  palestras, totalizando mais de 45 atividades que acontecerão simultaneamente de forma a atender a todos."/>

        <Card link="/PagConstrucao"
              img="./tech2.jpg"
              titulo = "XVI SEMANA DE CIÊNCIA E TECNOLOGIA"
              texto="Em sua 16ª edição, o CCSA realiza a Semana de Ciência e
              Tecnologia dos dias 26 a 28 de setembro de 2023, intulada
              Ciências Básicas para o Desenvolvimento Sustentável. Serão
              palestras e workshops on-line e presenciais, chegando a
              mais de 60 eventos. Faça sua inscrição com antecedência."/>
              
        <article className="article">
          <div className="head">
            <h2>Próximos Eventos</h2>
            <p>Descubra o que a Mackenzie tem a oferecer</p>
          </div>
            <div className="colunacard">
            <CardArticle link="/deeplearning"
                         img="./DeepLearning.jpg"
                         titulo="DEEP LEARNING"/>
            <CardArticle link="/uxui"
                         img="./UXUI.jpg"
                         titulo="UX/UI"/>
            <CardArticle link="/linguagemr"
                         img="./LinguagemR.jpg"
                         titulo="LINGUAGEM R"/>
            <CardArticle link="/azure"
                         img="./Azure.jpg"
                         titulo="AZURE"/>
            </div>
        </article>
          </div>
    </div>
  );
}
