import Semana from "../Components/Semanas/Semana";
export default function SemanaFCI() {
  return (
    <Semana 
        dias="2, 3 e 4"
        mes="Outubro"
        horario="08:00 - 21:00"
        titulo="Semana de Tecnologia e Inovação"
        paragrafo1="A Faculdade de Computação e Informática (FCI), da Universidade Presbiteriana Mackenzie (UPM), realizará nos dias 02, 03 e 04 de outubro a Semana da Tecnologia & Inovação (STI). A iniciativa ocorre nos campi Higienópolis e Alphaville, com transmissão ao vivo, e a programação completa está disponível aqui."
        paragrafo2="O evento, destinado aos alunos da graduação presencial e EaD; lato sensu e stricto sensu, busca a introduzir novas tecnologias; desenvolver soft e hard skills; e aproximar os participantes da realidade do mercado de trabalho."
        paragrafo3="Os três dias de evento com hackathons, keynotes, oficinas e palestras, totalizando mais de 45 atividades simultâneas. A programação será ministrada por profissionais de dez empresas: IBM; Google; Itaú; Atech; Nvidia; Microsoft; Accenture; Bayer; PRODAM; Wunderman Thompson Technology; Biti9; e ClearSale."
        paragrafo4="Durante o evento, a equipe do CIEE em Movimento estará de plantão com o objetivo de atuar na empregabilidade dos alunos, que poderão se cadastrar e receber encaminhamento para vagas de estágio. O evento também contará com a participação de egressos e professores da FCI."
        paragrafo5="A STI 2023 é uma grande oportunidade par ampliar o portfólio, aumentar o campo de experiências no seu currículo; realizar networking; adquirir novos conhecimentos, apoiados por mentores especialistas; e conhecer novas linguagens de programação."
      />
  );
}