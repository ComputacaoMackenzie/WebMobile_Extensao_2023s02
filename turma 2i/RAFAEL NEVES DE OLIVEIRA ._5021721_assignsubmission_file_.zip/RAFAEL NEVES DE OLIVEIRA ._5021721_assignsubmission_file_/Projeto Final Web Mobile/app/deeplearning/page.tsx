import Image from "next/image";
import Pagina from "../Components/Pagina";
export default function Home() {
  return (
    <Pagina
      banner="img-02.jpg"
      evento="DEEP LEARNING"
      desc="Lucas Golveia Omena Lopes | NVIDIA"
      dia="09/10"
      hora="09h15"
      predio="31"
      sala="404"
    />
  );
}