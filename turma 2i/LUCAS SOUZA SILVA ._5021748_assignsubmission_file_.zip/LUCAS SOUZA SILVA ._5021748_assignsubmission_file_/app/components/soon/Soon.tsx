import EventosJson from "@/app/api/eventos.json";

export default function Left({ event }) {
  const [eventos, setEventos] = useState(EventosJson["eventos"]);

  return (
    <div>
      <img src={event.imagem} alt="Festa do felipe" width="100%" />
      <h2 className="text-3xl pb-1 pt-1 font-bold"> {event.titulo} </h2>
      <p className="text-sm text-gray-700">{event.descritivo}</p>
      <div>
        <button></button>
      </div>
    </div>
  );
}
