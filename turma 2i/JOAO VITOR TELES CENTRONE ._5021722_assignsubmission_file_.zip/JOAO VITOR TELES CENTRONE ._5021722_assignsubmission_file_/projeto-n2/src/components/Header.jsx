
// Header.js

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Login from './Login';

const Header = () => {
  const navigate = useNavigate();

  const handleLogin = (username) => {
    // Adicione a lógica de autenticação do usuário se necessário
    console.log(`${username} logado`);
  };

  const handleLogout = () => {
    // Adicione a lógica de logout do usuário se necessário
    console.log('Usuário deslogado');
    navigate('/');
  };

  const[openLogin, setOpenLogin] = useState(false)

  return (
    <header className="bg-blue-800 p-4 text-white">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold">
          MackTag
        </Link>
        <Link to="/Eventos" className="text-2xl font-bold">
            Eventos
        </Link>
        <Link to="/Horas-complementares" className="text-2xl font-bold">
          Horas Complementares
        </Link>
        <Link to="/Sobre" className="text-2xl font-bold">
          Sobre
        </Link>
        <button onClick={() => setOpenLogin(!openLogin)} className='hover:bg-blue-700 border-white border-2 p-2 rounded-lg text-2xl font-bold'>Login</button>
        {openLogin && <Login onLogin={handleLogin} onLogout={handleLogout} /> }
        
      </div>
    </header>
  );
};

export default Header;
