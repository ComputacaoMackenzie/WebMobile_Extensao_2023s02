import React from 'react'
import { Link } from 'react-router-dom'
const evento = { id: 1, nome: 'Feira de Carreiras', data: '2023-12-15', descricao: 'Oportunidade para estudantes se conectarem com empresas, explorarem carreiras e participarem de palestras informativas sobre o mercado de trabalho.' }
const Evento1 = () => {
  return (
    <div className='h-screen bg-blue-800'>
        <div className='py-20 mx-10 my-20 border-2 border-white rounded-xl'>
            <div className='w-[80%] justify-center mx-auto'> 
                <h3 className='text-5xl font-bold text-white my-1'>{evento.nome}</h3>
                <p className='text-3xl font-bold text-white my-1'>Data: {evento.data}</p>
                <p className='text-3xl font-bold text-white my-1 mb-4'>{evento.descricao}</p>
                <Link to='/Eventos' className='text-lg font-bold text-blue-800 bg-white rounded-2xl p-2 hover:bg-blue-500'>Voltar para eventros</Link>
            </div>
        </div>
    </div>
  )
}

export default Evento1