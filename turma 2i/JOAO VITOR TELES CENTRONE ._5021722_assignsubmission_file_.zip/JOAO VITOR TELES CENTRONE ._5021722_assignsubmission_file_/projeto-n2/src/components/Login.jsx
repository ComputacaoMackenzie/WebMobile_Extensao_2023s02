// Login.js

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Login = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    // Adicione a lógica de autenticação aqui
    if (username === 'admin' && password === 'password') {
      onLogin(username);
      navigate('/'); // Redireciona para a página inicial após o login
    } else {
      alert('Credenciais inválidas. Tente novamente.');
    }
  };

  return (
    <div className='flex flex-col'>
      <div className="mb-4 p-4 bg-white rounded-md">
        <label htmlFor="username" className="block text-sm font-medium text-gray-700">
          Nome de Usuário:
        </label>
        <input
          type="text"
          id="username"
          name="username"
          value={username}
          placeholder='Digite o usuário'
          onChange={(e) => setUsername(e.target.value)}
          className="my-2 p-2 border-2 border-black text-black placeholder:text-black rounded-md w-full"
        />

        <label htmlFor="password" className="block text-sm font-medium text-gray-700">
          Senha:
        </label>
        <input
          type="password"
          id="password"
          name="password"
          value={password}
          placeholder='Digite a senha '
          onChange={(e) => setPassword(e.target.value)}
          className="my-2 p-2 border-2 border-black text-black placeholder:text-black rounded-md w-full"
        />
      </div>

       

      <button
        className="bg-blue-500 text-white p-2 rounded-md hover:bg-blue-700"
        onClick={handleLogin}
      >
        Entrar
      </button>
    </div>
  );
};

export default Login;
