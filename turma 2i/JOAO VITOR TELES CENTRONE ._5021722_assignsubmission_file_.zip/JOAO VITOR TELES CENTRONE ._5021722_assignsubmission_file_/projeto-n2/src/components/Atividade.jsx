import React from 'react'
import { Link } from 'react-router-dom';

const Atividade = ({ id, nome, descricao, preco, site }) => {
    return (
      <div className="border-2 border-white p-10 mb-6 rounded-lg hover:bg-white hover:bg-opacity-40">
        <div>
          <h3 className='text-3xl font-bold text-white'>{nome}</h3>
          <p className='text-2xl font-bold text-white '>{descricao}</p>
          <p className='text-2xl font-bold text-white mb-4'>{preco}</p>
          <a href={site} className='text-lg font-bold text-blue-800 bg-white rounded-2xl p-2 hover:bg-blue-500'>Ir ao site</a>
        </div>
        <img />
      </div>
    );
  };

export default Atividade