import React from 'react'
import Evento from './Evento'
import Atividade from './Atividade'

const HorasComplementares = ({atividades}) => {
  return (
    <div className='p-2 flex flex-col' >
    <h1 className="text-4xl font-bold my-4 mx-auto text-white">Locais que disponibilizam horas complementares</h1>
    <div className="">
      {atividades.map((e) => (
        <Atividade key={e.id} {...e} />
      ))}
    </div>
  </div>
  )
}

export default HorasComplementares