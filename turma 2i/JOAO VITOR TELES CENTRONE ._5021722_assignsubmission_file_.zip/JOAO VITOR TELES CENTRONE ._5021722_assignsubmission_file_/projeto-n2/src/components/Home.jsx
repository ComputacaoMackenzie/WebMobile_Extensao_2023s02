import React from 'react'
import { Link } from 'react-router-dom'
import image from '../assets/party.png'

const Home = () => {
  return (
    <div className='flex py-48 px-24 bg-blue-800 h-screen mt-10  '>
        <div className='w-[50%] flex flex-col mt-6'>
            <h1 className="text-6xl font-bold text-white">Chegou o MackTag!!!</h1>
            <p className="text-4xl font-bold my-4 text-white">O lugar certo para encontrar os eventos do Mackenzie !</p>
            <Link to="/Eventos" className=" text-blue-800 bg-white rounded-xl p-2 mt-3 text-2xl font-bold cursor-pointer w-[40%] text-center">Proximos eventos</Link>
        </div>
        <div>
        <img className='' src={image} /> 
        </div>
        
    </div>
  )
}

export default Home