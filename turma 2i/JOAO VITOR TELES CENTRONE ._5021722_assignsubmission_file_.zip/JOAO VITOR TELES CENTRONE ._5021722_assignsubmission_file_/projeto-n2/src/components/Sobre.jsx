
import React from 'react';

const Sobre = () => {
  return (
    <div className='py-40 px-20 bg-blue-800 h-screen'>
      <h1 className="text-6xl p-4 text-white font-bold mb-4">Sobre Nós.</h1>
      <p className='p-4 text-white font-bold text-3xl'>
        Bem-vindo ao nosso site de eventos na universidade! Este site foi criado para fornecer
        informações sobre os eventos que acontecem em nossa universidade.
      </p>
      <p className='p-4 text-white font-bold text-3xl'>
        Explore a lista de eventos, faça login para gerenciar seus próprios
        eventos e muito mais. Esperamos que você encontre as informações que procura e aproveite a
        experiência no site.
      </p>
    </div>
  );
};

export default Sobre;
