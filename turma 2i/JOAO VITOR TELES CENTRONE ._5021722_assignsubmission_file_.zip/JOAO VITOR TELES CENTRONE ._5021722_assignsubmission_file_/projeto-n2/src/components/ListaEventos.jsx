// ListaEventos.js

import React, { useState } from 'react';
import Evento from './Evento';

const ListaEventos = ({ eventos }) => {

  return (
    <div className='p-2 flex flex-col h-full bg-blue-800' >
      <h1 className="text-4xl font-bold my-4 mx-auto text-white">Próximos Eventos</h1>
      <div className="">
        {eventos.map((evento) => (
          <Evento key={evento.id} {...evento} />
        ))}
      </div>
    </div>
  );
};

export default ListaEventos;
