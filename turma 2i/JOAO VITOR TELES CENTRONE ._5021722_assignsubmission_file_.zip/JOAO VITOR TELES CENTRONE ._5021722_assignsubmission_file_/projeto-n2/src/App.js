// App.js

import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import ListaEventos from './components/ListaEventos';
import Sobre from './components/Sobre';
import Home from './components/Home';
import HorasComplementares from './components/Horas-complementares';
import Evento1 from './components/Eventos/Evento1';
import Evento2 from './components/Eventos/Evento2';
import Evento3 from './components/Eventos/Evento3';
import Evento4 from './components/Eventos/Evento4';


const eventosMock = [
  { id: 1, nome: 'Feira de Carreiras', data: '2023-12-15', descricao: 'Oportunidade para estudantes se conectarem com empresas, explorarem carreiras e participarem de palestras informativas sobre o mercado de trabalho.' },
  { id: 2, nome: 'Semana Acadêmica de Ciências Sociais', data: '2023-12-15', descricao: 'Evento anual que promove discussões, palestras e workshops abordando temas relevantes nas áreas de sociologia, antropologia e ciência política.' },
  { id: 3, nome: 'Hackathon Tecnológico:', data: '2023-12-15', descricao: 'Competição intensiva de programação e inovação, reunindo estudantes para desenvolverem soluções criativas e práticas para desafios tecnológicos.' },
  { id: 4, nome: 'Festival Cultural Universitário:', data: '2023-12-15', descricao: 'Descrição do evento 5' },
  
];

const horasMocks = [
  { id: 1, nome: 'Udemy', descricao: ' Plataforma global de aprendizado online que oferece uma ampla variedade de cursos em diversas áreas, ministrados por instrutores independentes, permitindo aos alunos adquirir conhecimentos sob demanda.', preco: 'Site Pago', site: 'https://www.udemy.com/'},
  { id: 2, nome: 'Alura', descricao: 'Plataforma brasileira de educação online, anteriormente Caelum, conhecida por cursos práticos e focados no mercado de trabalho, abrangendo tecnologia, programação, design, marketing e negócios.', preco: 'Site Pago', site: 'https://www.alura.com.br/'},
  { id: 3, nome: 'Fundação Bradesco', descricao: 'Oferece cursos online gratuitos, abrangendo tecnologia, administração e idiomas, proporcionando uma opção acessível para aprendizado introdutório em português.', preco: 'Site Gratis', site: 'https://www.ev.org.br/' },
  { id: 4, nome: 'Plural Sight', descricao: 'Plataforma online especializada em cursos de tecnologia e desenvolvimento de software, proporcionando uma extensa biblioteca para profissionais que buscam aprimorar suas habilidades.', preco: 'Site Pago', site: 'https://www.pluralsight.com/' },
  
];

const App = () => { 
  return (
    <Router>
      <div className='bg-blue-800 h-full'>
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Eventos" element={<ListaEventos eventos={eventosMock} />} />
          <Route path="/Sobre" element={<Sobre />} />
          <Route path="/Horas-complementares" element={<HorasComplementares atividades={horasMocks} />} />
          <Route path="/Eventos/Evento-1" element={<Evento1 />} />
          <Route path="/Eventos/Evento-2" element={<Evento2 />} />
          <Route path="/Eventos/Evento-3" element={<Evento3 />} />
          <Route path="/Eventos/Evento-4" element={<Evento4 />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
