import React, { useState } from 'react';

const Flip = ({ imagemFrente, imagemVerso, textoFrente, textoVerso }) => {
  const [virado, setVirado] = useState(true);

  const handleClick = () => {
    setVirado(!virado);
  };

  return (
    <div className="container-card">
      <div className={`card ${virado ? 'virado' : ''}`} onClick={handleClick}>
        {virado ? (
          <div className="face-front">
            <div className="upper-half">
              <img src={imagemFrente} alt="Imagem da Frente do Card" />
            </div>
            <div className="lower-half">
            <span class = "desc-img">{textoFrente}</span>
            </div>
          </div>
        ) : (
          <div className="face-back">
            <div className="upper-half">
              <img src={imagemVerso} alt="Imagem do Verso do Card" />
            </div>
            <div className="lower-half">
              <span class = "desc-img">{textoVerso}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Flip;
