import React, { useEffect } from "react";
import React, { useState } from 'react';
import L from "leaflet";

const Map = () => {
  const [mapInitialized, setMapInitialized] = useState(false);

  useEffect(() => {
    if (!mapInitialized) {
      const map = L.map('map').setView([40.7128, -74.0060], 14);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
      }).addTo(map);

      L.marker([40.7128, -74.0060]).addTo(map);

      setMapInitialized(true);
    }
  }, [mapInitialized]);

  return <div id="map" style={{ height: '500px' }} />;
};

export default Map;