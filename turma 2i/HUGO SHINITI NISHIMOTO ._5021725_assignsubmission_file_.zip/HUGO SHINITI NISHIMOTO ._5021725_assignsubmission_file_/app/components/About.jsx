import React from 'react';

const About = () => {
  return (
    <section className="about">
      <div className="inner2">
        <h1>Sobre o projeto</h1>
        <div className="border2"></div>
        <p className="description">
          Esta página tem como objetivo auxiliar os estudantes a escolherem a melhor opção de banheiro, com base em reviews de usuários.
        </p>
      </div>
    </section>
  );
};

export default About;