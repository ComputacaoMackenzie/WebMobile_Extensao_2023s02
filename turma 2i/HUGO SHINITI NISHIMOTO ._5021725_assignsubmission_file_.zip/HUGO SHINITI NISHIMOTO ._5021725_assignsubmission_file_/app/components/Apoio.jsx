import Link from 'next/link';

const Apoio = ({ instagramUsername }) => {
  return (
    <div className="insta">
      <p>Página inspirada no @banheirosdomack</p>
      <Link href={`https://www.instagram.com/${instagramUsername}`}>
          <img src="https://cdn2.iconfinder.com/data/icons/social-media-2285/512/1_Instagram_colored_svg_1-1024.png" alt="Instagram Icon" />
      </Link>
    </div>
  );
};

export default Apoio;
