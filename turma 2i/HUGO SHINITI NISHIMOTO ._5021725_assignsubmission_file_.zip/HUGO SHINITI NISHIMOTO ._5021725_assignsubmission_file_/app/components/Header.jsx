import React from 'react';
import Link from 'next/link';

const Header = () => {
  return (
    <header className="header">
      <label class="logo">MackBanheiro</label>
    </header>
  );
};

export default Header;