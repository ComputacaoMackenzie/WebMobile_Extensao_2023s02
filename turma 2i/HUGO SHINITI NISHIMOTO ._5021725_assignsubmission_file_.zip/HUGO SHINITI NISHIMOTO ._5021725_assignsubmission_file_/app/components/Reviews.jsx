import React from 'react';

const Reviews = ({ opinion1, opinion2, opinion3 }) => {
  return (
    <section className="CS">
      <div className="inner">
        <h1>Reviews</h1>
        <div className="border"></div>
        <div className="row">
          <div className="col">
            <div className="CSI">
              <img src="pic-1.jpg" alt="Estagiário" />
              <div className="name">
                <h3>Estagiário</h3>
                <div className="stars">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
                  <i className="far fa-star"></i>
                  <i className="far fa-star"></i>
                </div>
              </div>
              {opinion1}
            </div>
          </div>
          <div className="col">
            <div className="CSI">
              <img src="Darth.png" alt="Darth Vader" />
              <div className="name">
                <h3>Darth Vader</h3>
                <div className="stars">
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
                  <i className="far fa-star"></i>
                  <i className="far fa-star"></i>
                  <i className="far fa-star"></i>
                </div>
              </div>
              {opinion2}
            </div>
          </div>
          <div className="col">
            <div className="CSI">
              <img src="Jjportrait.jpg" alt="Jarja" />
              <div className="name">
                <h3>Jarja</h3>
                <div className="stars">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="far fa-star"></i>
                  <i className="far fa-star"></i>
                  <i className="far fa-star"></i>
                </div>
              </div>
              {opinion3}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Reviews;