import React from "react";
import { useState } from "react";

const BathroomCard = ({ image, title, review }) => {
  const [itemAtual, setItemAtual] = useState(0);

  const imagemAnterior = () => {
    let aux = itemAtual - 1;
    if (aux < 0) aux = items.length - 1;
    setItemAtual(aux);
  };

  const imagemPosterior = () => {
    let aux = itemAtual + 1;
    if (aux >= items.length) aux = 0;
    setItemAtual(aux);
  };
  return (
    <div id="container">
      <button onClick={imagemAnterior}>&lt;</button>
      <div id="esquerdo">
        <div id="img">
          <img src={image} alt={title} />
        </div>
        <div id="texto-baixo">
          <h2>{title}</h2>
        </div>
        <div className="direita">
          <p>{review}</p>
        </div>
      </div>
      <button onClick={imagemPosterior}>&gt;</button>
    </div>
  );
};

export default BathroomCard;
