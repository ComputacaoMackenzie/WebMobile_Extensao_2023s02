import React from 'react';
import Link from 'next/link';


const Suporte = () => {
  return (
    <section className="support">
      <h1>Suporte</h1>
      <div className="support-content">
        <p>
          Você tem alguma dúvida ou problema? Entre em contato conosco e ficaremos felizes em ajudá-lo.
        </p>
        <p>
          Você pode nos contatar por telefone, e-mail ou chat ao vivo.
        </p>
        <ul className="support-links">
          <li><Link href="tel:123-456-7890">Telefone</Link></li>
          <li><Link href="mailto:support@mackbanheiro.com">E-mail</Link></li>
          <li><Link href="https://mackbanheiro.com/chat">Chat ao vivo</Link></li>
        </ul>
      </div>
      <div className="support-back">
        <Link href="/">Voltar</Link>
      </div>
    </section>
  );
};

export default Suporte;