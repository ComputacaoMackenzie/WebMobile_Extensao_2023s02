/*<!-- Lucas Tonin Leite - 32089759 -->
<!-- Hugo Shiniti Nishimoto - 32048416 -->
<!-- Fernando Bastos Arbache- 31806211 --> */

"use client";
import { useState } from "react";
import Header from "./components/Header";
import About from "./components/About";
import Reviews from "./components/Reviews";
import BathroomCard from "./components/Cards";
import SocialLinks from "./components/Social";
import Flip from "./components/Flip";
import Map from "./components/Map";
import FAQ from "./components/FAQ";
import Apoio from "./components/Apoio";
import "../public/style.css";

const faqData = [
  {
    question: "Pra que serve esse site?",
    answer: "O site tem o propósito de ajudar os alunos a encontrarem os melhores banheiros do campus.",
  },
  {
    question: 'É possível selecionar a localidade do banheiro em um mapa?',
    answer: 'Isso ainda não é possivel, mas no futuro será uma das funcionalidades',
  },
];

export default function Home() {
  return (
    <>
      <Header />
      <About />
      <Flip
        imagemFrente="/GOAT.png"
        imagemVerso="/map1.png"
        textoFrente="Banheiro do Lado da Praça de Alimentação"
        textoVerso="O banheiro fica localizado próximo a praça de alimentação principal, estando do lado do mack cópia"
      />
      <Reviews
        opinion1="Marcou uma geração"
        opinion2="Adoro soltar o lado negro da força nele"
        opinion3= "Melhor banheiro da galáxia" 
        />
      <Flip
        imagemFrente="/b1.png"
        imagemVerso="/map2.png"
        textoFrente="Banheiro do Lado Externo do 31"
        textoVerso="O banheiro fica localizado em frente ao prédio do MackGraphe e do lado do prédio 31"
      />
      <Reviews
        opinion1="Pior impossível"
        opinion2="Esse pertence ao dark side"
        opinion3= "Esse banheiro tá fedido"
        />
      <div className="faq-container">
        <h1>FAQ</h1>
        {faqData.map((faq, index) => (
          <FAQ key={index} question={faq.question} answer={faq.answer} />
        ))}
      </div>

      <Apoio instagramUsername="banheirosdomack" />

      <SocialLinks />
    </>
  );
}

