"use client";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

export default function Predio33() {
  const [showBack, setShowBack] = useState(false);

  const handleClick = () => {
    setShowBack(!showBack);
  };

  return (
    <div className="Predios">
      <h1> Prédio 33 </h1>
      <img className="imagemcampus" src="predio33.jpeg" alt="" />
      {showBack ? (
        <div>
          <div onClick={handleClick}>
            <div class="seta2">
              <h2> Estrutura do Prédio </h2>
              <img className="seta" src="baixo.jpg" alt="" />
            </div>
          </div>
            <p>1º Andar - Laboratório</p> 
            <p>2º Andar - Laboratório</p>  
            <p>3º Andar - Sala e Laboratório</p>  
            <p>4º Andar - Sala com computadores e estudo</p> 

        </div>
      ) : (
        <div onClick={handleClick}>
          <div class="seta2">
            <h2> Estrutura do Prédio </h2>
            <img className="seta" src="cima.jpg" alt="" />
          </div>
        </div>
      )}
      <Link href="/">&lt; Voltar</Link>
    </div>
  )
}