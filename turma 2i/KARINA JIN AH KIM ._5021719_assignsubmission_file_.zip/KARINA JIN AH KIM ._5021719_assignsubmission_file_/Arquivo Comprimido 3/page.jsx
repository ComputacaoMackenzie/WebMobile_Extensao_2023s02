"use client";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

export default function Predio31() {
    const [showBack, setShowBack] = useState(false);

    const handleClick = () => {
      setShowBack(!showBack);
    };
  
    return (
      <div className="Predios">
       
        <h1> Prédio 31 </h1>
        <img className="imagemcampus" src="predio31.jpg" alt="" />
        {showBack ? (
          <div>
            <div onClick={handleClick}>
            <div class="seta2">
              <h2> Estrutura do Prédio </h2>
              <img className="seta" src="baixo.jpg" alt="" />
              </div>
            </div>

              <p>Subsolo - Área administrativa </p> 
             <p> 1º Andar - Secretaria e Sala dos professores </p> 
             <p>2º Andar - 2 Salas de laboratório e 1 sala de aula </p> 
             <p> 3ºAndar - Auditório e 2 Salas de laboratório </p> 
             <p>4º Andar - 2 Salas de laboratório e 1 sala de aula </p> 
      
            
          </div>
        ) : (
          <div onClick={handleClick}>
            <div class="seta2">
            <h2> Estrutura do Prédio </h2>
            <img className="seta" src="cima.jpg" alt="" />
            </div>
            
          </div>
        )}
         <Link href="/">&lt; Voltar</Link>
      </div>
    )}