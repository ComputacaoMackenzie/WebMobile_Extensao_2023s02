import React, { useState, useEffect } from "react";
import LocalWeather from "../components/WeatherData";

const IndexContent = () => {
  const [temp, setTemp] = useState();
  const [chuva, setChuva] = useState();
  const [weatherData, setWeatherData] = useState(null);

  const getTempo = () => {
    fetch(
      "https://api.open-meteo.com/v1/forecast?latitude=-23.5458&longitude=-46.6599&current=temperature_2m,rain&forecast_days=1",
    )
      .then((r) => r.json())
      .then((f) => {
        console.log(f);
        setWeatherData(f);
        setTemp(f.current.temperature_2m);
        setChuva(f.current.rain);
      })
      .catch((error) => {
        console.error("Erro ao buscar dados da API:", error);
        setWeatherData({ error: true });
      });
  };

  useEffect(() => {
    getTempo();
  }, []);

  return (
    <div>
      <h1>Your Component Title</h1>
      <p>Temperature: {temp}°C</p>
      <p>Rain: {chuva}</p>
      <LocalWeather weatherData={weatherData} />
    </div>
  );
};

export default IndexContent;
