import React from "react";

const WeatherData = ({ children, weatherData }) => {
  if (!weatherData) {
    return <p>Carregando...</p>;
  }

  if (weatherData.error) {
    return (
      <p>
        Erro ao obter dados de tempo. Por favor, tente novamente mais tarde.
      </p>
    );
  }

  return (
    <div>
      <h1>
        {weatherData.name}, {weatherData.sys.country}
      </h1>
      <p>Temperatura: {weatherData.main.temp}°C</p>
      <p>Condição: {weatherData.weather[0].description}</p>
      <p>{children}</p>
    </div>
  );
};

export default LocalWeather;
export { WeatherData };
