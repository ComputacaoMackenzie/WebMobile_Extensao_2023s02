//Anshu Li 32329611
// David 
// Karina Jin Ah Kim 32343256

"use client";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import IndexContent from "./components/IndexContent";

export default function Home() {
  const [showBack, setShowBack] = useState(false);

  const handleClick = () => {
    setShowBack(!showBack);
  };

  return (
    <>
      <IndexContent />
      <div className="mackenzie">
        <h1> Mackenzie </h1>
        <img className="imagemcampus" src="/campus.jpg" alt="" />
        {showBack ? (
          <div>
            <div onClick={handleClick}>
              <div className="seta2">
                <h2> História do Mackenzie </h2>
                <img className="seta" src="/baixo.jpg" alt="" />
              </div>
            </div>
            <p>
              O Instituto Presbiteriano Mackenzie tem uma história rica e
              diversificada. Fundado em 1870 por missionários presbiterianos
              George e Mary Ann Annesley Chamberlain em São Paulo, Brasil, o
              instituto começou como uma escola que promovia a igualdade, não
              fazendo distinção de sexo, credo ou etnia. Em 1876, a Escola
              Americana, precursora do Colégio, foi estabelecida, atendendo a
              filhos de escravos e famílias tradicionais. Mais tarde, em 1879,
              uma área em Higienópolis foi adquirida, marcando uma nova fase na
              história do instituto. O nome "Mackenzie" surgiu graças a uma
              doação do advogado americano John Theron Mackenzie, que nunca
              visitou o Brasil, mas deixou uma doação em testamento para a
              construção de uma escola de Engenharia no país. O instituto passou
              a ser chamado Mackenzie em sua homenagem. O Mackenzie expandiu
              suas ofertas acadêmicas ao longo dos anos, criando escolas
              superiores, incluindo a Faculdade de Filosofia, Ciências e Letras,
              a Faculdade de Arquitetura, a Faculdade de Ciências Econômicas e a
              Faculdade de Direito. Em 1952, o Mackenzie foi reconhecido como
              uma universidade pelo presidente Getúlio Vargas. Uma nota especial
              é que em 1965, Esther de Figueiredo Ferraz se tornou a primeira
              mulher a assumir o cargo de reitora em uma universidade
              brasileira, no Mackenzie. O instituto também se dedicou à formação
              integral de seus alunos, oferecendo desde a Educação Básica até a
              Pós-Graduação em diversos níveis, incluindo especialização,
              mestrado e doutorado. Hoje, o Mackenzie possui presença em várias
              localidades no Brasil, oferecendo educação e saúde por meio de
              seus colégios, faculdades, universidades e hospitais. Além da
              educação, o instituto se envolve na área de saúde e é associado a
              entidades mantenedoras de hospitais, como o Hospital Universitário
              Evangélico Mackenzie e o Hospital Evangélico Dr. e Sra. Goldsby
              King. A instituição tem uma perspectiva cristã que enfatiza a
              importância da autonomia, educação, saúde e dignidade do ser
              humano, sendo guiada pela fé desde sua fundação em 1870.{" "}
            </p>
          </div>
        ) : (
          <div onClick={handleClick}>
            <div className="seta2">
              <h2> História do Mackenzie </h2>
              <img className="seta" src="/cima.jpg" alt="" />
            </div>
          </div>
        )}
        <h1> Prédios da Faculdade de Ciências e Informação: </h1>
        <div className="predios2">
          <div className="predios3">
            <Link href="/predio31">Predio 31</Link>
            <img className="predios" src="/predio31.jpg" alt="Prédio 31" />
          </div>

          <div className="predios3">
            <a href="/predio33">Predio33</a>
            <img className="predios" src="/predio33.jpeg" alt="Prédio 33" />
          </div>
        </div>
      </div>
    </>
  );
}
