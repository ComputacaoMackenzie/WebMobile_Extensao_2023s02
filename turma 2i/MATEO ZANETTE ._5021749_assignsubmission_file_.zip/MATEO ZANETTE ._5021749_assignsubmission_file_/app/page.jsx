
import Noticias from "./components/index/Noticias";
import Apresentacao from "./components/index/Apresentacao";
import Footer from "./components/index/Footer";
import Tempo from "./components/index/Tempo";

export default function Home() {
  return (
        <div class="flex">
          <Apresentacao/>
          <Tempo/>
          <section id="parte2">
            <Noticias/>
          </section>
          <Footer/>
        </div>

  );
}
