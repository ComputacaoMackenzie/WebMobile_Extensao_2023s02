import "./globals.css";
import Menu from "./components/index/Menu";

export const metadata = {
  title: "Mackgenda",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
          <Menu/>
            {children}
      </body>
    </html>
  );
}
