import "./times.css";

export default function Times() {
    return(
     <article id="principal">    
        <div id="secundario">
                <header>
                    <h1>Aqui você pode ver quais times estão agendando quais quadras</h1>
                </header>
            <div id="times">
                <section>
                    <img className="Img" src="https://github.com/LimitForm1/Web/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/atl_tec.png?raw=true"/>
                    <h2>Esse time irá usar a Quadra 18 no dia 4/10 as 18:00</h2>
                </section>
                <section>
                    <img className="Img" src="https://github.com/LimitForm1/Web/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/atl_economia.png?raw=true"/>
                    <h2>Esse time irá usar a Quadra 29 no dia 6/10 as 18:00</h2>
                </section>
                <section>
                    <img className="Img" src="https://github.com/LimitForm1/Web/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/atl_lep.png?raw=true"/>
                    <h2>Esse time irá usar a Quadra 18 no dia 3/10 as 20:00</h2>
                </section>
                <section>
                    <img className="Img" src="https://github.com/LimitForm1/Web/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/atl_arquitetura.png?raw=true"/>
                    <h2>Esse time não tem nenhuma quadra agendada por enquanto</h2>
                </section>
                <section>
                    <img className="Img" src="https://github.com/LimitForm1/Web/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/atl_comuni.png?raw=true"/>
                    <h2>Esse time irá usar a 20 no dia 7/10 as 19:00</h2>
                </section>
                <section>
                    <img className="Img" src="https://github.com/LimitForm1/Web/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/atl_direito.png?raw=true"/>
                    <h2>Esse time irá usar a Quadra 52 nó dia 4/10 as 21:00</h2>
                </section>
                <section>
                    <img className="Img" src="https://github.com/LimitForm1/Web/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/atl_engenharia.png?raw=true"/>
                    <h2>Esse time irá usar a Quadra 20 nó dia 6/10 as 22:00</h2>
                </section>
            </div>
        </div>
     </article>
    );
}