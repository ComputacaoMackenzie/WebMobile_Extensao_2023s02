import "./Apresentacao.css";
import Image from 'next/image';

export default function Apresentacao() {
  return (
    <div>
      <img src="https://www.mackenzie.br/fileadmin/user_upload/capa_instituto.jpg" width="100%" height="50%"/>
        <section id="conteudo">
            <div id="apresentacao">
              <h1>SEJA BEM VINDO AO AGENDAMENTO DE QUADRAS</h1>
                  <h3> Aqui, no Agendamento de Quadras, tornamos a sua experiência esportiva mais simples e conveniente.
                  Fique por dentro de todas as atualizações relacionadas ao seu agendamento.
                  Estamos aqui para simplificar o seu acesso aos espaços esportivos do Mackenzie.<br/>
                  Comece a usar nosso sistema agora mesmo e aproveite ao máximo sua experiência esportiva no campus. <br/>
                  Jogue, treine e divirta-se
                  </h3>
            </div>
            <a href="#tempo"><img src="https://github.com/LimitForm1/Web/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/seta3.png?raw=true"id="seta"/></a>
        </section>
    </div>
  );
}