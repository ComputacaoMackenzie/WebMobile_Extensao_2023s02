import "./Noticias.css";
import Image from "next/image";

export default function Noticias() {
  const slider = () => {
    radio=document.querySelector('.manual_btn')
  document.getElementById('radio1').checked=true}

  return (
    <div class="not">
      <h1>Acompanhe as notícias</h1>
      <section id="noticias">
        <div class="card1">
                  <img
                    class="futsal"
                    src="https://github.com/LimitForm1/Web/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/futsal.jpg?raw=true"
                    alt="futsal.jpg" 
                  />
                  <h4 class="desc">Time de tec do mackenzie ganha de 4x0 da puc </h4>
                  <p class="data_futsal">22.09.23</p>
        </div>
        <div class="card2">
                  <img
                    class="volei"
                    src="https://github.com/LimitForm1/Web/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/volei_rec.jpg?raw=true"
                    alt="volei_rec.jpg" 
                  />
                  <h4 class="desc_volei">
                    A tec de volei feminino está realizando testes{" "}
                  </h4>
                  <p class="data_volei">18.09.23</p>
          </div>
      </section>
    </div>
  );
}
