import "./Footer.css";
import Image from "next/image";

export default function Footer() {
  return (
    <footer id="footer2">
      <div id="tudo">
        <code id="ajuda "> Gostaria de ajuda? </code>
        <div id="chat_container">
          <img
            id="chat_img"
            src="https://github.com/LimitForm1/ProjetoWeb/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/Chat.png?raw=true"
          />
          <code id="chat_ajuda"> Chat </code>
        </div>
        <div id="whatsapp_container">
          <img
            id="wpp"
            src="https://github.com/LimitForm1/ProjetoWeb/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/Wpp.png?raw=true"
          />
          <code id="whats_ajuda"> WhatsApp </code>
        </div>
      </div>
    </footer>
  );
}
