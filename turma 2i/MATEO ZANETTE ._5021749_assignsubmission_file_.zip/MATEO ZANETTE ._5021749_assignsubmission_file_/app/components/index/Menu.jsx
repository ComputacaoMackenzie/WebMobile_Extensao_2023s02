import "./Menu.css";
import Image from "next/image";
import Link from "next/link";

export default function Menu() {
  return (
    <nav className="menu">
      <ul className="menu">
        <Link href="/">
          <img src="https://github.com/LimitForm1/Web/blob/1%C2%BAsemestre/Trabalho%20web%20Mobile%20Site/mackenzie-logo%20(1).png?raw=true" id="logo" />
        </Link>
        <Link className="link" href="/components/Agendamento">Agendamento</Link>
        <Link className="link" href="/components/times">Times</Link>
      </ul>
    </nav>
  );
}
