'use client'
import "./tempo.css";
import { useEffect,useState } from "react";

export default function Tempo() {
    const [temperatura,setTemperatura]=useState();
    useEffect(() =>{
        fetch('https://api.openweathermap.org/data/2.5/weather?lat=-23,5492&lon=-46,6521&appid=a850d0a29a93b2c4c5e49004e7b75a3b')
        .then((response)=>response.json())
        .then((dados)=>setTemperatura(dados))
    },[]);

  return ( 
    <div id="tempo">
        <h1>Tempo Higienópolis-Mackenzie</h1>
        {temperatura &&(
                <p> <br></br>
                    Temperatura Atual:
                    {temperatura['main']['temp']}K°
                    Clima:{temperatura['weather'][0].main}
                    <br></br><br></br>
                    Vento:{temperatura['wind']['speed']}m/s
                </p>
                )
            }
            {!temperatura && <p>Carregando..</p>}
    </div>
  )
}