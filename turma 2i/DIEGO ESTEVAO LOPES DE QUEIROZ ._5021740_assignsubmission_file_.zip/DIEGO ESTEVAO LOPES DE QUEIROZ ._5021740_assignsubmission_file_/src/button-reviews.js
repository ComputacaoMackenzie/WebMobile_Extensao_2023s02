import React, { useState, useEffect } from "react";
import Modal from "react-modal";

const YelpAPIKey = "GjgHuqym-lNGGa-ma54lgvpicJcTsnE6uVolbs8c0JXUEwnYEk9K8dQIixEH4Y_bY0aI8PqrVhkqTGQmQLu5dee4ZazASWOL1JcRvlVb54YdQL147NHq6AcGFwtkZXYx";

function ButtonReview({ placeId }) {
  const [modalIsOpen, setIsModalOpen] = useState(false);
  const [reviews, setReviews] = useState([]);

  const closeModal = () => setIsModalOpen(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          `https://api.yelp.com/v3/businesses/${placeId}/reviews?locale=pt_BR&limit=5&sort_by=newest`,
          {
            method: "GET",
            headers: {
              accept: "application/json",
              Authorization: `Bearer ${YelpAPIKey}`,
            },
          }
        );

        if (response.ok) {
          const data = await response.json();
          setReviews(data.reviews);
          setIsModalOpen(true);
        } else {
          console.error("Erro ao obter avaliações:", response.statusText);
        }
      } catch (error) {
        console.error("Erro ao obter avaliações:", error);
      }
    };

    if (modalIsOpen) {
      fetchData();
    }
  }, [modalIsOpen, placeId]);

  return (
    <div>
      <button onClick={() => setIsModalOpen(true)}>Ver Avaliações</button>
      <Modal isOpen={modalIsOpen} onRequestClose={closeModal}>
        <h2>Avaliações do Lugar</h2>
        <ul>
          {reviews.map((review) => (
            <li key={review.id}>
              <p>{review.text}</p>
            </li>
          ))}
        </ul>
        <button onClick={closeModal}>Fechar</button>
      </Modal>
    </div>
  );
}

export default ButtonReview;