import React, { useState } from "react";
import ButtonReview from "./button-reviews.js";
import "./styles.css";

const App = () => {
  return (
    <html lang="pt-br">
      <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Guia Estabelecimentos</title>
        <link rel="stylesheet" href="style.css" />
      </head>
      <body>
        <header>
          <img src="mack.png" alt="Universidade Presbiteriana Mackenzie" />
        </header>
        <h1>ESTABELECIMENTOS NO CAMPUS HIGIENÓPOLIS</h1>
        <div className="contender">
          <div id="ultra">
            <p>Bosque: Ultra Coffee</p>
            <img src="ultra.png" width="200px" alt="Ultra Coffee" />
            <ButtonReview placeId="hamburgueria-do-sujinho-são-paulo" />
          </div>
          <div id="starbucks">
            <p>Prédio 07: Starbucks</p>
            <img src="starbucks.png" width="200px" alt="Starbucks" />
            <ButtonReview placeId="hamburgueria-do-sujinho-são-paulo" />
          </div>
          <div id="pracaum">
            <p>
              Prédio 19: All Natural, Candy Place, Grazy Mille, Bobs, College Café, Arameus, Casa do Pão de Queijo
            </p>
            <img src="predio19.jpg" width="230" alt="Prédio 19" />
            <ButtonReview placeId="hamburgueria-do-sujinho-são-paulo" />
          </div>
          <div id="borges">
            <p>Prédio 25: Borges</p>
            <img src="borges.jpg" width="280px" alt="Borges" />
            <ButtonReview placeId="hamburgueria-do-sujinho-são-paulo" />
          </div>
          <div id="pracatres">
            <p>Prédio 38: Restaurante e Lanchonete</p>
            <img src="predio38.jpg" width="250px" alt="Prédio 38" />
            <ButtonReview placeId="hamburgueria-do-sujinho-são-paulo" />
          </div>
          <div id="mrCheney">
            <p>Proximo ao prédio 38: Mr. Cheney Cookies</p>
            <img src="cheney.jpg" width="250px" alt="Mr. Cheney Cookies" />
            <ButtonReview placeId="hamburgueria-do-sujinho-são-paulo" />
          </div>
          <div id="ruzzi">
            <p>Prédio 45: Ruzzi</p>
            <img src="ruzzi.jpg" width="250px" alt="Ruzzi" />
            <ButtonReview placeId="hamburgueria-do-sujinho-são-paulo" />
          </div>
          <div id="pracadois">
            <p>Prédio 45: Rei do Mate, Mille Bistrot, Borges</p>
            <img src="predio45.jpg" width="250px" alt="Prédio 45" />
            <ButtonReview placeId="hamburgueria-do-sujinho-são-paulo" />
          </div>
        </div>
      </body>
    </html>
  );
};
export default App;
