module.exports = {
  totalFaltas: 60,
  faltas: [
    {
      id: 1,
      nome: "Análise de dados",
      professor: "Professor 1",
      faltasPermitidas: 10,
      faltas: 9,
    },
    {
      id: 2,
      nome: "Inteligência artificial",
      professor: "Professor 2",
      faltasPermitidas: 15,
      faltas: 16,
    },
    {
      id: 3,
      nome: "Jogos digitais",
      professor: "Professor 3",
      faltasPermitidas: 17,
      faltas: 17,
    },
    {
      id: 4,
      nome: "Web mobile",
      professor: "Professor 3",
      faltasPermitidas: 12,
      faltas: 15,
    },
    {
      id: 5,
      nome: "Estrutura de dados",
      professor: "Professor 3",
      faltasPermitidas: 9,
      faltas: 3,
    },
  ],
};
