const express = require("express");
const data = require("./data/data");
const cors = require('cors');

const app = express();
const port = 3003;

app.use(express.json());
app.use(cors());

app.get("/faltas", (req, res) => {
  res.json(data);
});

app.get("/faltas/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const item = data.find((item) => item.id === id);
  if (item) {
    res.json(item);
  } else {
    res.status(404).json({ message: "Item não encontrado" });
  }
});

app.post("/faltas", (req, res) => {
  const newItem = req.body;
  newItem.id = data.length + 1;
  data.push(newItem);
  res.status(201).json(newItem);
});

app.put("/faltas/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const itemIndex = data.findIndex((item) => item.id === id);

  if (itemIndex !== -1) {
    data[itemIndex] = { id, ...req.body };
    res.json(data[itemIndex]);
  } else {
    res.status(404).json({ message: "Item não encontrado" });
  }
});

app.delete("/faltas/:id", (req, res) => {
  const id = parseInt(req.params.id);
  const itemIndex = data.findIndex((item) => item.id === id);

  if (itemIndex !== -1) {
    data.splice(itemIndex, 1);
    res.json({ message: "Item excluído com sucesso" });
  } else {
    res.status(404).json({ message: "Item não encontrado" });
  }
});

app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});
