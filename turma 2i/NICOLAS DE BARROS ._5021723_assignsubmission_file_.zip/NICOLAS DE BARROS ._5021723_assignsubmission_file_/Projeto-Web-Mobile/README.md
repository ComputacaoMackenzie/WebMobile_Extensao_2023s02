# Projeto-Web-Mobile
Nicolas de Barros 32070837
Eric Felipeli César Dias Pereira 41911296
Nicolas Pinsdorf 32036108

## Problema a ser resolvido: 
  - Alunos do Mackenzie não conseguem controlar suas faltas e nem saber como está 
    a situação de suas presenças por conta do sistema não ser tão claro e intuitivo
  
### Como Rodar: 

#### Front End
com node/npm/react instalados: 
1. cd front-end
2. npm i --force
3. npm run start

#### Back End
com node/npm/react instalados: 
1. cd back-end
2. npm i --force
3. npm run start

### Caso de algum erro ao rodar: 
Link do Vercel: https://projeto-web-mobile-k8ak05twr-nicolas123-coder.vercel.app/login