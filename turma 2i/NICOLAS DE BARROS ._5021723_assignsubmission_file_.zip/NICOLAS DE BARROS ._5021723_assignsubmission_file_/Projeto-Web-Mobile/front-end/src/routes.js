import React from "react";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import PrivateRoute from "./components/Routing";
import Login from "./pages/Login/Login";
import SignUp from "./pages/Signup/SignUp";
import { ToastContainer } from "react-toastify";
import CustomToast from "./components/Toast";
import Sidebar from "./components/Sidebar/Sidebar";
import Home from "./pages/Home/Home";
import Faltas from "./pages/Faltas/Faltas";
import LimiteFaltas from "./pages/LimiteFaltas/LimiteFaltas";
import NotFound from "./pages/NotFound/NotFound";
import { ApiProvider } from "./context/apiContext";

const ProjectRoutes = () => (
  <BrowserRouter>
    <ApiProvider>
      <Sidebar />
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={true}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        toastComponent={CustomToast}
      />
      <Routes>
        <Route exact path="/" element={<PrivateRoute />}>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/faltas" element={<Faltas />} />
          <Route exact path="/limites-faltas" element={<LimiteFaltas />} />
        </Route>
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </ApiProvider>
  </BrowserRouter>
);

export default ProjectRoutes;
