import React from "react";
import { AiFillHome } from "react-icons/ai";
import { TbAlertTriangleFilled } from "react-icons/tb";
import { FaChartSimple } from "react-icons/fa6";

export const SidebarData = [
  {
    title: "Home",
    path: "/",
    icon: <AiFillHome />,
    cName: "nav-text",
  },
  {
    title: "Faltas",
    path: "/faltas",
    icon: <FaChartSimple />,
    cName: "nav-text",
  },
  {
    title: "Limite de Faltas",
    path: "/limites-faltas",
    icon: <TbAlertTriangleFilled />,
    cName: "nav-text",
  },
];
