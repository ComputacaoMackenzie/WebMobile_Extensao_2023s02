import React, { useState } from "react";
import { Link } from "react-router-dom";
import { SidebarData } from "./SidebarData";
import { IconContext } from "react-icons";
import "./Sidebar.css";

function Sidebar() {
  const auth = localStorage.getItem("accessToken");

  return (
    <>
      <div>
        <div className="navbar"></div>
        <div className="navbar-up">
          <div className="navbar-toggle"></div>
          <Link to="#" className="menu-bars"></Link>
          {SidebarData.map((item, index) => {
            return (
              <Link to={item.path} className="no-link-style">
                <li key={index} className={item.cName}>
                  {item.icon}
                  <span>{item.title}</span>
                </li>
              </Link>
            );
          })}
        </div>

        <nav className="nav-menu active">
          <ul className="nav-menu-items">
            <li className="navbar-toggle">
              <Link to="#" className="menu-bars" />
            </li>
            {SidebarData.map((item, index) => {
              return (
                <Link to={item.path} className="no-link-style">
                  <li key={index} className={item.cName}>
                    {item.icon}
                    <span>{item.title}</span>
                  </li>
                </Link>
              );
            })}
          </ul>
        </nav>
      </div>
    </>
  );
}

export default Sidebar;
