import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { toast } from "react-toastify";

const PrivateRoute = () => {
  const auth = localStorage.getItem("accessToken");

  if (auth === null) {
    console.log("You must be logged in to access this page");
    toast.warning("You must be logged in to access this page");
  }

  return auth ? <Outlet /> : <Navigate to="/login" />;
};

export default PrivateRoute;
