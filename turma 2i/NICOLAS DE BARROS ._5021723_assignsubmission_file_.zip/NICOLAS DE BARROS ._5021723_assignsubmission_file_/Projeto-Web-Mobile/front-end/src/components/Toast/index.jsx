import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const useStyles = makeStyles((theme) => ({
  toastSuccess: {
    background: theme.palette.success.main,
  },
  toastError: {
    background: theme.palette.error.main,
  },
  toastInfo: {
    background: theme.palette.info.main
  },
}));

const CustomToast = ({ message, type }) => {
  const classes = useStyles();
  return (
    <div
      className={type === "success" ? classes.toastSuccess : classes.toastError}
    >
      {message}
    </div>
  );
};

export default CustomToast;
