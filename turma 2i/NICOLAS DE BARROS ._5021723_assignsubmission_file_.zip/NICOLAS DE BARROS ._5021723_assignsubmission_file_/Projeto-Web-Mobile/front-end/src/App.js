import React from "react";
import ProjectRoutes from "./routes";

const App = () => <ProjectRoutes />;
export default App;