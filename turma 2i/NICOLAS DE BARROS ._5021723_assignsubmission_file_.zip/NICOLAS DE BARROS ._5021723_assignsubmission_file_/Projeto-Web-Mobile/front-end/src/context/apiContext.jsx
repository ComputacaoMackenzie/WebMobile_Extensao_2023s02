import React, { createContext, useContext, useState, useEffect } from "react";
import axios from "axios";

const DataContext = createContext();

export function useData() {
  return useContext(DataContext);
}

export function ApiProvider({ children }) {
  const [faltas, setFaltas] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchApi = async () => {
      try {
        const response = await axios.get("http://localhost:3003/faltas", {
          headers: {
            "Content-Type": "application/json"
          },
        });
        setFaltas(response.data);
        setIsLoading(false);
      } catch (error) {
        console.error("Erro ao buscar dados da rota 1:", error);
        setIsLoading(false);
      }
    };

    fetchApi();
  }, []);

  return (
    <DataContext.Provider value={{ faltas, isLoading }}>
      {children}
    </DataContext.Provider>
  );
}
