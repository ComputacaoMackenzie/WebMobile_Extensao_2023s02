import React from 'react'
import './NotFound.css'

function NotFound() {
  return (
    <div className='not-found'>NotFound 🤔</div>
  )
}

export default NotFound