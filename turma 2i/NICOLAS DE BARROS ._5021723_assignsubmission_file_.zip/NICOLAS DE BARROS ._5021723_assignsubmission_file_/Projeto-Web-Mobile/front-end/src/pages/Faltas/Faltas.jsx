import React from "react";
import "./Faltas.css";
import { BarChart } from "@mui/x-charts/BarChart";
import { PiWarningFill } from "react-icons/pi";
import { useData } from "../../context/apiContext";


function Faltas() {
  const { faltas } = useData();
  const materias = faltas?.faltas?.map((materia) => materia.nome)
    ? faltas?.faltas?.map((materia) => materia.nome)
    : [];

  const numeroFaltas = faltas?.faltas?.map((materia) => materia.faltas)
    ? faltas?.faltas?.map((materia) => materia.faltas)
    : [0];

  return (
    <div className="faltas">
      <div className="faltas-column-1">
        <span className="faltas-header">Quantidade de Faltas</span>
        <div className="faltas-limits">
          <table className="table-2">
            <thead>
              <tr>
                <th>Aulas</th>
                <th>Faltas</th>
              </tr>
            </thead>
            <tbody>
              {faltas?.faltas?.map((aula, index) => (
                <tr key={index}>
                  <td>{aula.nome}</td>
                  <td>
                    {aula.faltas > aula.faltasPermitidas && <PiWarningFill />}
                    {aula.faltas}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <BarChart
        xAxis={[
          {
            id: "faltas-chart",
            data: materias,
            scaleType: "band",
          },
        ]}
        series={[
          {
            data: numeroFaltas,
            color: "#A03034",
          },
        ]}
        width={700}
        height={400}
      />
    </div>
  );
}

export default Faltas;
