import React from "react";
import "./Home.css";
import { useData } from "../../context/apiContext";
import { PiWarningFill } from "react-icons/pi";


function Home() {
  const { faltas } = useData();

  return (
    <div className="home">
      <div className="welcome">
        <p>Seja bem vindo {"Nicolas"}!</p>
      </div>
      <div className="container">
        <div className="faltas-info">
          <div className="faltas-info-header">
            <h3>Total de Faltas</h3>
          </div>
          <div className="faltas-info-content">
            {faltas?.totalFaltas > 50 ? (
              <span className="warning-icon">
                <PiWarningFill />
              </span>
            ) : (
              <></>
            )}
            <span className="faltas-total">{faltas?.totalFaltas}</span>
          </div>
        </div>
        <div className="materias-info">
          <div className="materias-info-header">
            <h3>Matérias</h3>
          </div>
          <div className="materias-info-content">
            {faltas?.faltas?.map((materia, index) => (
              <div className="materia" key={index}>
                <span className="materia-nome">{materia.nome}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
