import React from "react";
import { useData } from "../../context/apiContext";
import "./LimiteFaltas.css";


function LimiteFaltas() {
  const { faltas } = useData();

  return (
    <div className="faltas">
      <div className="faltas-column-1">
        <span className="faltas-header">Limite de Faltas</span>
        <div className="faltas-limits-2">
          <table className="table-1">
            <thead>
              <tr>
                <th>Aulas</th>
                <th>Limite</th>
              </tr>
            </thead>
            <tbody>
              {faltas?.faltas?.map((aula, index) => (
                <tr key={index}>
                  <td>{aula.nome}</td>
                  <td>{aula.faltasPermitidas}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default LimiteFaltas;
