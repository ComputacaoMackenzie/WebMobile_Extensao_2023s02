import * as React from "react";
import { useState } from "react";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import { styled } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import "./Login.css";


export default function Login() {
  const navigate = useNavigate();
  //TODO: transformar isso em um context
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);

    console.log(data.get("email"));

    setIsLoggedIn(true);
    toast.success("Login OK");

    const accessToken = "login-token";

    localStorage.setItem("accessToken", accessToken);

    navigate("/");
    return true;
  };

  const CssTextField = styled(TextField)({
    "& label.Mui-focused": {
      color: "#A03034",
    },
    "& .MuiInput-underline:after": {
      borderBottomColor: "#A03034",
    },
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        borderColor: "#E0E3E7",
      },
      "&:hover fieldset": {
        borderColor: "#B2BAC2",
      },
      "&.Mui-focused fieldset": {
        borderColor: "#A03034",
      },
    },
  });

  return (
    <div className="login">
      <CssBaseline />
      <Box
        sx={{
          width: 400,
          height: 400,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Avatar sx={{ bgcolor: "#dedede", width: 60, height: 60 }}>
          <h2>🔒</h2>
        </Avatar>
        <Typography component="h1" variant="h5">
          Login
        </Typography>
        <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
          <CssTextField
            label="Username"
            id="email"
            margin="normal"
            required
            fullWidth
            name="email"
            type="email"
            autoComplete="email"
          />
          <CssTextField
            margin="normal"
            required
            fullWidth
            name="password"
            label="Password"
            type="password"
            id="password"
            autoComplete="current-password"
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            sx={{
              mt: 3,
              mb: 2,
              backgroundColor: "#A03034",
              "&:hover": {
                backgroundColor: "#9d151a",
              },
            }}
          >
            Log In
          </Button>
        </Box>
      </Box>
    </div>
  );
}
