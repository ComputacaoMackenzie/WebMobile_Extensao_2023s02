import React from "react";
import "./PostCard.css";
import fotoPerfil from "../img/Oval.svg";
import fotoComunidade from "../img/Chat-1.svg";

function PostCard(post) {
  console.log(post);
  return (
    <div id="card">
      <div id="topCard">
        <div className="userInfo">
          <img src={fotoPerfil} alt="Foto de perfil do usuário" />
          <h4>{post.author}</h4>
        </div>
        <div>
          <a href="">
            <img id="icon" src={fotoComunidade} alt="Icone de comentário" />
          </a>
        </div>
      </div>
      <div>
        <p id="comunity">Comunidade: {post.commuinity}</p>
        <p id="content">Conteúdo: {post.content}</p>
        <br />
        <p id="info">{post.text}</p>
      </div>
    </div>
  );
}

export default PostCard;
