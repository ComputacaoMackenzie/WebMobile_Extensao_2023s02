import React from "react";
import "./NewPostForm.css";
import { createPost } from "../Class/Post.js";
import { useNavigate } from "react-router-dom";
function NewFormPost() {
  const navigate = useNavigate();
  return (
    <div className="container">
      <label for="comunidade">Comunidade</label>
      <select name="comunidade" className="formInput">
        <option value=""></option>
        <option value="option1">option 1</option>
        <option value="option2">option 2</option>
        <option value="option3">option 3</option>
      </select>

      <label for="conteudo">Conteúdo</label>
      <input type="text" name="conteudo" className="formInput" />

      <label for="texto">Texto</label>
      <textarea
        name="texto"
        id=""
        cols="30"
        rows="10"
        className="formInput"
      ></textarea>

      <button
        onClick={() => {
          const comunidadeInput = document.querySelector(
            "select[name='comunidade']",
          );
          const conteudoInput = document.querySelector(
            "input[name='conteudo']",
          );
          const textoInput = document.querySelector("textarea[name='texto']");
          console.log(
            createPost(
              "someone",
              comunidadeInput.value,
              conteudoInput.value,
              textoInput.value,
            ),
          );
          navigate("/feed/all");
        }}
        className="formInput submit-button"
      >
        POSTAR
      </button>
    </div>
  );
}

export default NewFormPost;
