import React from "react";
import "./Footer.css";
function Footer(){
    return(
        <footer>
            <p>Cristiane Luzia Silva dos Santos - 32338831</p>
            <p>Isabella Garcia Amantino - 32344155 </p>
            <p>João Simionato Neto - 32340168 </p>
            <p>Mack News &copy; 2023</p>
        </footer>
    );
}

export default Footer;