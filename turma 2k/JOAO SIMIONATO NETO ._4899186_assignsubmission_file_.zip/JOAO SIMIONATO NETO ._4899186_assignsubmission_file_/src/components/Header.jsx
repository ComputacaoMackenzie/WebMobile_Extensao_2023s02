import React, { useState } from "react";
import "./Header.css";
import logo from "../img/logo.png";
import search from "../img/search.png";
import menuBurguer from "../img/menu-burger.png";
import { Link } from "react-router-dom";

function Header() {
  const [show, showMenu] = useState(false);

  return (
    <>
      <header id="header" className={show ? "change-header" : ""}>
        <div className="navbar">
          <div
            className="icon"
            onClick={() => {
              showMenu(!show);
            }}
          >
            <img src={menuBurguer} alt="" />
          </div>
        </div>
        <div className="search">
          <img src={search} alt="" />
          <input id="search" type="text" />
        </div>
        <div className="logo">
          <img src={logo} />
        </div>
      </header>
      <div
        id="menu"
        className={
          show
            ? "mobile-menu nav-decoration change-nav"
            : "mobile-menu nav-decoration"
        }
      >
        <ul>
          <li>
            <img src={"../SiteAssets/img/Home.png"} alt="" />{" "}
            <Link to={"/feed/all"}>HOME</Link>
          </li>
          <li>
            <img src={"../SiteAssets/img/Group-person.png"} alt="" />
            <Link to={"/comunidades"}>COMUNIDADE</Link>
          </li>
          <li>
            <img src={"../SiteAssets/img/Pluse ellipse.png"} alt="" />
            <Link to={"/novoPost"}>POSTAR</Link>
          </li>
          <li className="sair">
            <img src={"../SiteAssets/img/sair.png"} alt="" />
            <a
              onClick={() => {
                showMenu(!show);
              }}
            >
              SAIR
            </a>
          </li>
        </ul>
      </div>
    </>
  );
}

export default Header;
