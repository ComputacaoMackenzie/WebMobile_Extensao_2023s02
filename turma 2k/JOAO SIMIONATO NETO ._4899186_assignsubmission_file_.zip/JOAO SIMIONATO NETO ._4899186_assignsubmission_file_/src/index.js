import React from "react";
import App from "./App";
import * as ReactDOM from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Feed from "./pages/feed";
import Communities from "./pages/communities";
import NewPost from "./pages/newPost";
const router = createBrowserRouter([
  {
    path: "/feed/:community",
    element: <Feed />,
  },
  {
    path: "comunidades",
    element: <Communities />,
  },
  {
    path: "novoPost",
    element: <NewPost />,
  },
]);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>,
);
