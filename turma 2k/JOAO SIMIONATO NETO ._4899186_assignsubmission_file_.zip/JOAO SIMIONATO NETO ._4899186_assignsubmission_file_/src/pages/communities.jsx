import React from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import Comunidade from "../components/Comunidade";

function Communities() {
  return (
    <>
      <Header />

      <div className="container">
        <Comunidade name="FCI" link={"/feed/FCI"} />
        <Comunidade name="Direito" link={"/feed/Direito"} />
        <Comunidade name="Engenharia" link={"/feed/Engenharia"} />
        <Comunidade name="FAU" link={"/feed/FAU"} />
      </div>
      <Footer />
    </>
  );
}

export default Communities;
