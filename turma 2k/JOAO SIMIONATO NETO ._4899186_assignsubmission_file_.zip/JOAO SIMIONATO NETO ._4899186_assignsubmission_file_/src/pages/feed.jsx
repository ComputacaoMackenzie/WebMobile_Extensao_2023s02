import React from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import PostCard from "../components/PostCard";
import { useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { getAllPosts, getPostByCommunity, createPost } from "../Class/Post.js";

// const fallback = resolve.fallback;
// fallback["querystring"] = '{"querystring": false}';
function Feed() {
  const { community } = useParams();
  //   const [news, setNews] = useState([]);

  //   const fetchNews = async () => {
  //     const NewsAPI = require("newsapi");
  //     const newsapi = new NewsAPI("04e811f1a99a4e4cabd9dbeab8f041a5");
  //     // To query /v2/top-headlines
  //     // All options passed to topHeadlines are optional, but you need to include at least one of them
  //     newsapi.v2
  //       .topHeadlines({
  //         sources: "all",
  //         q: "Universidade Mackenzie",
  //         category: "all",
  //         language: "pt",
  //         country: "br",
  //       })
  //       .then((response) => {
  //         console.log(response);
  //         const data = response.json();
  //       });

  //     setNews(data.articles);
  //   };

  //   fetchNews();

  //   news?.map((n) => createPost("API", "All", n.title, n.description));
  console.log(getAllPosts());
  return (
    <>
      <Header />
      {community === "all"
        ? getAllPosts()?.map((post) => <PostCard post={post} />)
        : getPostByCommunity(community)?.map((post) => (
            <PostCard post={post} />
          ))}
      <Footer />
    </>
  );
}

export default Feed;
