class Community {
    constructor(name, img){
        this.name = name;
        this.img = img;
    }
}