import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css'
import Header from './components/header'
import Footer from './components/footer'
import LandingPage from './components/landingpage'
import Signup from './components/signup'
import Feed from './components/feed'
import Communities from './components/communities'
import Community from './components/community'

export default function App() {
  return (
    <Router>
      <main>
        <Header />
        <Routes>
          <Route path="/signup" element={<Signup/>} />
          <Route path="/feed" element={<Feed/>} />
          <Route path="/communities" element={<Communities/>} />
          <Route path="/community" element={<Community/>} />
          <Route path="/" element={<LandingPage/>} />
        </Routes>
        <Footer />
      </main>
    </Router>
  )
}