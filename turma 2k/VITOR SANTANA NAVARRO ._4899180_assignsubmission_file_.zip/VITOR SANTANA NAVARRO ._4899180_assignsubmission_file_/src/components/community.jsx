import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../stylesheets/community.css';
import {Link} from 'react-router-dom'


const Community = () => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://www.arbeitnow.com/api/job-board-api');
        setJobs(response.data.data.slice(0, 9));
      } catch (error) {
        console.error('Erro ao buscar dados da API:', error);
      }
    };

    fetchData();
  }, []);


  const truncateDescription = (description, maxLength) => {
    const cleanedDescription = description.replace(/<[^>]*>/g, '');

    if (cleanedDescription.length <= maxLength) {
      return cleanedDescription;
    }

    // Split em palavras e remoção de palavras muito longas
    const words = cleanedDescription.split(' ').filter(word => word.length < 50);

    // Junte as palavras de volta
    const truncatedText = words.join(' ');

    return `${truncatedText.substring(0, maxLength)}...`;
  };
  return (
    <main>
      <div class="breadcrumbs">
        <Link to="/feed">Feed</Link> &gt;
        <Link to="/communities">Communities</Link>
        <span>Turma 08N - Ciência da Computação</span>
      </div>
      <div class="community-banner">
        <img class="community-logo" src="/images/community1.png" />
        <h2>Turma 08N - Ciência da Computação</h2>
        <img id="community-img" src="/images/promoimage.jpeg" />
      </div>
      <div className="wrapper">
        {jobs.map((job) => (
           <Link to={job.url} className="card" target="_blank">
              <div className="card-title">
                <p className="card-position"><b>{job.title}</b></p>
              </div>
              <p className="card-level jr"><b>{job.tags.join(', ')}</b></p>
              <p className="card-description">{truncateDescription(job.description, 200)}</p>
          </Link>
        ))}
      </div>
    </main>
  );
};
export default Community;
