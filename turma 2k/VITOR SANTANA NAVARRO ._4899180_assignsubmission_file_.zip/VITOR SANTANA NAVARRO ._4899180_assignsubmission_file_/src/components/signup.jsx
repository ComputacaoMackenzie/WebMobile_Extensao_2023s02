import React from 'react';
import { Link } from 'react-router-dom'
import '../stylesheets/signup.css';

const SignupPage = () => {
  return (
    <main>
      <h1>FAÇA SEU CADASTRO</h1>
      <form action="submit">
        <div className="form-group">
          <label htmlFor="name">Nome completo</label>
          <input
            type="text"
            name="name"
            id="name"
            required
            placeholder="João Fujão"
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            name="email"
            id="email"
            required
            placeholder="joao.fujao@gmail.com"
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Senha</label>
          <input
            type="password"
            name="password"
            id="password"
            required
            placeholder="********"
          />
        </div>
        <div className="form-group">
          <label htmlFor="confirm-password">Confirme Sua Senha</label>
          <input
            type="password"
            name="confirm-password"
            id="confirm-password"
            required
            placeholder="********"
          />
        </div>

        <Link id="signup" to="/feed">Se cadastre</Link>
        <Link to="/">já tem uma conta? faça login</Link>
      </form>
    </main>
  );
};

export default SignupPage;
