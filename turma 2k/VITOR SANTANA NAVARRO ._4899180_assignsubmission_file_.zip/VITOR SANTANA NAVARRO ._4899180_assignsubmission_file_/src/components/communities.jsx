import React from 'react';
import { Link } from 'react-router-dom'

const CommunitiesPage = () => {
  return (
    <main>
      <div class="breadcrumbs">
        <Link to="/feed">Feed</Link>
        <span>Communities</span>
      </div>
      <h1>Suas comunidades</h1>
      <div class="wrapper">
        <Link class="card" to="/community">
          <img src="images/hsimage.jpeg" />
          <div class="card-title">
            <p class="card-position">
              <b>Turma 08N - Ciência da Computação</b>
            </p>
          </div>
          <p class="card-description">
            Vagas para os guerreiros que sobreviveram os 4 anos do curso de
            ciência da computação no Mackenzie. Um grupo com os mais crânios.
          </p>
          <p class="card-footer">46 vagas</p>
        </Link>
        <Link class="card" to="/community">
          <img src="images/promoimage.jpeg" />
          <div class="card-title">
            <p class="card-position">
              <b>Pessoal de Tech do Colégio</b>
            </p>
          </div>
          <p class="card-description">
            Irmãos até o fim! Não é só porque o ensino médio acabou que vamos
            deixar de ajudarmos uns aos outros. Para quem viveu o colégio,
            buscar vaga é moleza.
          </p>
          <p class="card-footer">15 vagas</p>
        </Link>
      </div>
    </main>
  );
};

export default CommunitiesPage;