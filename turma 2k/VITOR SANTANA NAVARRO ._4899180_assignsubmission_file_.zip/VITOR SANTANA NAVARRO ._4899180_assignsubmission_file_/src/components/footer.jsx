import React from 'react';

export default function Footer() {
  const style = {
    color: 'var(--off-white)',
    width: '100%', // Adicione esta linha para ocupar toda a largura
    display: 'flex',
    fontFamily: "Montserrat Alternates, sans-serif",
    fontSize: 'small',
    height: 'fit-content',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '10px', 
    boxSizing: 'border-box',
  }

  return (
    <footer  style={style}>
      <h3>&copy; 2023 Indica aí.</h3>
      <p>Termos de uso</p>
      <p>Privacidade</p>
      <p>Cookies</p>
    </footer>
  );
};
