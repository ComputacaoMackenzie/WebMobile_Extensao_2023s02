import React, { useState } from 'react';// Certifique-se de ajustar o caminho do arquivo authService.js
import '../stylesheets/landingpage.css';
import {Link} from 'react-router-dom'

export default function LandingPage() {
  // Definindo os estados para o email e senha
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Funções para lidar com a mudança nos inputs
  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  // Função para lidar com a submissão do formulário
  const handleSubmit = async (e) => {
    e.preventDefault(); // Evita o comportamento padrão de recarregar a página ao submeter o formulário

    try {
      // Enviar dados para o back-end usando o serviço de autenticação
      const response = await authService.authenticate({ email, password });

      // Verificar se a autenticação foi bem-sucedida
      if (response.data && response.data.token) {
        // Salvar usuário logado no Local Storage
        authService.setLoggedUser(response.data.user);

        // Aqui você pode redirecionar para a página do feed ou executar outras ações necessárias
        console.log('Usuário autenticado com sucesso:', response.data.user);
        this.props.history.replace('/')
      } else {
        console.log('Falha na autenticação');
        // Adicione lógica para lidar com falha na autenticação, por exemplo, exibindo uma mensagem de erro
      }
    } catch (error) {
      console.error('Erro ao autenticar:', error);
      // Adicione lógica para lidar com erros durante a autenticação
    }
  };

  return (
    <div className="container">
      <div className="left">
        <h2>indique.</h2>
        <h2>seja indicado.</h2>
        <h2>ache a pessoa certa.</h2>
        <p>
          Construa uma comunidade mais forte e faça a diferença com o Indica Aí!
        </p>
      </div>
      <div className="right">
        <h1>FAÇA LOGIN</h1>
        <form>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              name="email"
              id="email"
              required
              placeholder="joao.fujao@gmail.com"
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Senha</label>
            <input
              type="password"
              name="password"
              id="password"
              required
              placeholder="********"
            />
            <a href="">esqueceu sua senha?</a>
          </div>
          <br/>
          <Link id="signin" to="/feed">Entrar</Link>
          <div className="divider">
            <div className="line"></div>
            <div className="or">or</div>
            <div className="line"></div>
          </div>
          <Link id="signup" to="/signup">Cadastre-se</Link>
        </form>
      </div>
    </div>
  );
}
