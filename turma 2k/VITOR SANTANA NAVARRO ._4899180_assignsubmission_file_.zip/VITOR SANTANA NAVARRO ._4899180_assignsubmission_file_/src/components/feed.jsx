import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import '../stylesheets/feed.css';

const Feed = () => {
  const [jobs, setJobs] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const jobsPerPage = 15;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('https://www.arbeitnow.com/api/job-board-api');
        setJobs(response.data.data);
      } catch (error) {
        console.error('Erro ao buscar dados da API:', error);
      }
    };

    fetchData();
  }, []);

  const truncateDescription = (description, maxLength) => {
    const cleanedDescription = description.replace(/<[^>]*>/g, '');

    if (cleanedDescription.length <= maxLength) {
      return cleanedDescription;
    }

    const words = cleanedDescription.split(' ').filter(word => word.length < 50);
    const truncatedText = words.join(' ');

    return `${truncatedText.substring(0, maxLength)}...`;
  };

  const indexOfLastJob = currentPage * jobsPerPage;
  const indexOfFirstJob = indexOfLastJob - jobsPerPage;
  const currentJobs = jobs.slice(indexOfFirstJob, indexOfLastJob);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div>
      <main>
        <div className="breadcrumbs">
          <span>Feed</span>
        </div>
        <h1>Oportunidades de Emprego</h1>
        <div className="wrapper">
          {currentJobs.map((job) => (
            <Link key={job.id} to={job.url} target="_blank" className="card">
              <div className="card-title">
                <p className="card-position"><b>{job.title}</b></p>
              </div>
              <p className="card-level jr"><b>{job.tags.join(', ')}</b></p>
              <p className="card-description">{truncateDescription(job.description, 200)}</p>
            </Link>
          ))}
        </div>
        <div className="pagination">
          {Array.from({ length: Math.ceil(jobs.length / jobsPerPage) }).map((_, index) => (
            <button
              key={index + 1}
              className={currentPage === index + 1 ? 'active' : ''}
              onClick={() => paginate(index + 1)}
            >
              {index + 1}
            </button>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Feed;
