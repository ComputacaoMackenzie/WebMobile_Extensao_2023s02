import React from 'react';
import { Link } from 'react-router-dom'


export default function Header() {

  return (
    <header>
      <div className="left">
        <Link to="/feed">
          <img src="/logo.svg" alt="Logo Indica Aí" />
        </Link>
      </div>
      <div className="right">
        <Link to="/communities">
          <img src="/persons.svg" alt="Logo comunidade" />
        </Link>
      </div>
    </header>
  );
};
