## Projeto Indica Ai
Anna Beatriz Santos Custódio     32048106
Ana Cecília Barbosa Alves        32084935
Vitor Sant'Ana Navarro           32022476

## URL do Repl.it
https://replit.com/@AnaCecliaCeclia/indica-ai-react - Público
https://replit.com/join/aryhenqroz-anacecliaceclia - Privado