import { useState } from 'react';
import './Home.css'
import logo from './assets/logo.jpg';
import mapa from './assets/mapa.jpg'

function App() {
  const [bol1, setBol1] = useState(false);
  const [bol2, setBol2] = useState(false);
  const [bol3, setBol3] = useState(false);



  return (
    <>
        <header className="header">
          <div className="Restaurantes">
          <h1>Mack Comunicativo</h1>
          </div>
          <div>
            <img src={logo} className="logo" width="110px" />
            <h2></h2>
          </div>
          <nav>
            <button >Home</button>
            <button onClick={() => setBol2(!bol2)}>Restaurantes</button>
            <button onClick={() => setBol3(!bol3)}>Mapas</button>
          </nav>
        </header>

        <h1>Bem-vindo ao nosso site!</h1>
        <br /> <br />
        {bol2 && (
          <div>
          <h1>Restaurantes</h1>
          <main>
            <div class="R1">
              <h2>GRAZZI</h2>
            </div>
            <div className='lista1'>
              <ul>
                <li>10:00 - 21:30</li>
                <li>Sopa de mandioca , pastel , carne moida e salada ceasar</li>
                <li>Praça de alimentação prédio 19</li>
              </ul>
            </div>
            
            <div class="R2">
              <h2>BORGES</h2>
            </div>
            <div class="lista2">
              <ul>
                <li>8:00 - 22:00</li>
                <li>strogonoff , x salada , saladinha</li>
                <li>Praça de alimentação prédio 45</li>
              </ul>
            </div>
  
            <div class="R3">
              <h2>CHAPADO</h2>
            </div>
            <div className='lista3'>
              <ul>
                <li>11:00 - 22:00</li>
                <li>frango grelhado , feijuca , bife acebolado</li>
                <li> prédio 39, em frente a saída da consolação</li>
              </ul>
            </div>
  
            <div class="R4">
              <h2>BOBS</h2>
            </div>
            <div className='lista4'>
              <ul>
                <li>12:00 - 21:30</li>
                <li>x salada, big bobs , nuggets </li>
                <li> Praça de alimentação prédio 45</li>
              </ul>
            </div>
  
            <div class="R5">
              <h2>STARBUCKS</h2>
            </div>
            <div className='lista5'>
              <ul>
                <li>06:30 - 23:30</li>
                <li>café, doces, frapuccinos</li>
                <li>em frente ao prédio 45 (praça de alimentação)</li>
              </ul>
            </div>
          </main>
          </div>
        )}

        {bol3 && (
          <div className="">
            <main>
              <br />
              <br />
              <h1>Mapa</h1>
              <div className="mapa">
                <img src={mapa} class="mapa"/>
              </div>
            </main>
          </div>
        )}
        
        
        <footer class="footer">
          <img src={logo} width={110} />
          <div class="logo">
            <h2></h2>
          </div>
          <div class="Nomes">
            <p> Antônio César 3248800</p>
            <p>Isabelle Ramos Miranda 42210836</p>
            <p> Pedro Augusto Rubacow Iotti 32026021</p>
            <p>Pedro Gabriel Marotta Silva 32338090</p>
          </div>
    </footer>
    </>
  )
}

export default App;
