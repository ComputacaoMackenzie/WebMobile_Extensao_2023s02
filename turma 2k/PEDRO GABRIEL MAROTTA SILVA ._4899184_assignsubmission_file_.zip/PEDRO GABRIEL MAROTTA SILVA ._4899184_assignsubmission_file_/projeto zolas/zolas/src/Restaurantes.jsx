export default function Restaurantes() {
    return(
        <h1>ola</h1>
    )
}