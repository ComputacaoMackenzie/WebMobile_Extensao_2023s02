export default function Mapa(){
    return(
        <h1>OI</h1>
    )
}