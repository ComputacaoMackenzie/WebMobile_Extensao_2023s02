import React from "react";
import './Home.css';

export default function Home() {
    return (
        <>
            <main>
                <div class="intro">
                    <h2>Bem-vindo!</h2>
                    <p>Conheça os restaurantes do Mackenzie Higienópolis e escolha a melhor opção para você!</p>
                    <a href="projeto.html" class="btn">CONHEÇA OS RESTAURANTES</a>
                    <a class="btn">MAPA DO MACKENZIE</a>
                    <br /><br />
                    <br /><br />
                    <a href="https://www.youtube.com/embed/reJ5Z65rCYo?si=NzaKsc4LKuNh-gqu" title="YouTube video player" />
                </div>
                
        </main>
    </>
    )
}