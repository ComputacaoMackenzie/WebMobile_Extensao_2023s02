import "./posts.css";
import tia from "./tia.jpeg";
import { useState } from "react";

export default function Posts() {
  const [posts, setPosts] = useState([
    <Post
      local="Prédio 31"
      contato="(11) 99999-9999"
      img={tia}
      date={"03/01/2023"}
    />,
    <Post
      local="Prédio 32"
      contato="(11) 11111-1111"
      img={tia}
      date={"02/01/2023"}
    />,
    <Post
      local="Prédio 33"
      contato="(11) 22222-2222"
      img={tia}
      date={"01/01/2023"}
    />,
    <Post
      local="Prédio 34"
      contato="(11) 33333-3333"
      img={tia}
      date={"01/01/2023"}
    />,
  ]);

  const [newPost, setNewPost] = useState(false);

  const handleNewPost = () => {
    setNewPost(true);
  };

  const createPost = () => {
    if (!document.querySelector(".new-post textarea:nth-child(1)").value) {
      alert("Insira um local");
      return;
    }
    if (!document.querySelector(".new-post textarea:nth-child(2)").value) {
      alert("Insira um contato");
      return;
    }
    if (!document.querySelector(".new-post input").files[0]) {
      alert("Insira uma imagem");
      return;
    }

    const local = document.querySelector(
      ".new-post textarea:nth-child(1)",
    ).value;
    const contato = document.querySelector(
      ".new-post textarea:nth-child(2)",
    ).value;
    const imgInput = document.querySelector(".new-post input");
    const img = imgInput.files[0]
      ? URL.createObjectURL(imgInput.files[0])
      : null;
    const date = new Date();
    const postDate =
      date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
    const newPost = (
      <Post local={local} contato={contato} img={img} date={postDate} />
    );
    setPosts([newPost, ...posts]);
    setNewPost(false);
  };

  const reload = () => {
    const postsDiv = document.querySelector(".posts");
    postsDiv.scrollLeft = 0;
    const posts = document.querySelectorAll(".post");
    for (let i = 0; i < posts.length; i++) {
      const post = posts[i];
      post.style.display = "block";
    }
  };

  const filter = () => {
    console.log("procurando");
    const dateInput = document.querySelector("#date");
    const selectedDate = dateInput.value.split("-").reverse().join("/");
    console.log(selectedDate);
    const posts = document.querySelectorAll(".post");

    for (let i = 0; i < posts.length; i++) {
      const post = posts[i];
      const postDate = post.getAttribute("data-date");
      console.log(postDate);
      if (postDate !== selectedDate) {
        post.style.display = "none";
      } else {
        post.style.display = "block";
      }
    }
  };

  if (!newPost) {
    return (
      <div className="posts-wrapper">
        <button onClick={handleNewPost} className="new-post-button">
          Poste um achado
        </button>
        <button className="reload" onClick={reload}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            fill="currentColor"
            class="bi bi-arrow-clockwise"
            viewBox="0 0 16 16"
          >
            <path
              fill-rule="evenodd"
              d="M8 3a5 5 0 1 0 4.546 2.914.5.5 0 0 1 .908-.417A6 6 0 1 1 8 2v1z"
            />
            <path d="M8 4.466V.534a.25.25 0 0 1 .41-.192l2.36 1.966c.12.1.12.284 0 .384L8.41 4.658A.25.25 0 0 1 8 4.466z" />
          </svg>
        </button>
        <input type="date" className="date" id="date" />
        <button className="reload" onClick={() => filter()}>
          Procurar
        </button>
        <div className="posts">
          {posts.map((post, index) => (
            <div key={index}>{post}</div>
          ))}
        </div>
      </div>
    );
  } else {
    return (
      <div className="posts-wrapper">
        <button onClick={() => setNewPost(false)} className="new-post-button">
          Voltar
        </button>
        <NewPost />
        <button
          className="new-post-button"
          style={{ marginTop: "20px" }}
          onClick={createPost}
        >
          Postar
        </button>
      </div>
    );
  }
}

function Post(props) {
  return (
    <div className="post" data-date={props.date}>
      <img src={props.img} alt="post-img" />
      <div className="info">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          fill="currentColor"
          className="bi bi-geo-alt-fill"
          viewBox="0 0 16 16"
        >
          <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z" />
        </svg>
        <span>{props.local}</span>
      </div>
      <div className="info">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          fill="currentColor"
          className="bi bi-telephone"
          viewBox="0 0 16 16"
        >
          <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122l-2.19.547a1.745 1.745 0 0 1-1.657-.459L5.482 8.062a1.745 1.745 0 0 1-.46-1.657l.548-2.19a.678.678 0 0 0-.122-.58L3.654 1.328zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z" />
        </svg>
        <span>{props.contato}</span>
      </div>
      <div className="info">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          fill="currentColor"
          className="bi bi-calendar4-week"
          viewBox="0 0 16 16"
        >
          <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM2 2a1 1 0 0 0-1 1v1h14V3a1 1 0 0 0-1-1H2zm13 3H1v9a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V5z" />
          <path d="M11 7.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-2 3a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1zm-3 0a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1z" />
        </svg>
        <span>{props.date}</span>
      </div>
    </div>
  );
}

function NewPost() {
  const [selectedImage, setSelectedImage] = useState(null);

  const handleImageChange = (e) => {
    setSelectedImage(URL.createObjectURL(e.target.files[0]));
  };

  return (
    <div className="new-post">
      <textarea placeholder="Local" maxLength={20} />
      <textarea placeholder="Contato" maxLength={20} />
      <input type="file" accept="image/*" onChange={handleImageChange} />
      {selectedImage && (
        <img src={selectedImage} alt="selected-img" className="preview-img" />
      )}
    </div>
  );
}
