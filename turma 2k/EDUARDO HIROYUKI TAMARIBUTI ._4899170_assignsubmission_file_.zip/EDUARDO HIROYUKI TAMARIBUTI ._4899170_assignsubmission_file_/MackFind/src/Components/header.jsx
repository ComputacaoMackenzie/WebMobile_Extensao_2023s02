import './header.css';
import logo from './logo.png';

export default function Header() {
    return (
        <div className="header">
            <div className='logo'> 
                <a href='/'><img src={logo} alt="logo" /></a>
                <a href='/'>
                    <div>
                        <h1>MackFind</h1>
                        <p>Achados e perdidos do Mackenzie</p>
                    </div>
                </a>
            </div>
        </div>
    )
}