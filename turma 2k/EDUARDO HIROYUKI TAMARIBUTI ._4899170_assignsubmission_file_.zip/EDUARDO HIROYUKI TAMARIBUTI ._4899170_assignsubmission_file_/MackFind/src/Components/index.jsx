import Header from "./header"
import Posts from "./posts"
import Filter from "./filter"
import './index.css';

export default function Index() {
    return (
        <div className="main-page">
            <Header />
            <Filter />
            <Posts />
        </div>
    )
}