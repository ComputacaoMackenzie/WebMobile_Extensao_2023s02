import './filter.css';
import Temp from './temp';

export default function Filter() {
    return (
        <div className='filter'>
            <Temp />
        </div>
    )
}