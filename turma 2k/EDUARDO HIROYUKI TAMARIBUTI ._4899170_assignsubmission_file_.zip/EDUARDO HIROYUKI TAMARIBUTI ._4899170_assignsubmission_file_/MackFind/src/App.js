import "./reset.css";
import "./styles.css";
import Index from "./Components/index";

export default function App() {
  return <Index />;
}
