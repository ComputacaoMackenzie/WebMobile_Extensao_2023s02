import React from "react";
import mapa from './assets/mapa.jpg';

export default function Mapa() {
   
   return (
      <>
         <main>
            <h1>Mapa</h1>
            <div className="mapa">
               <img src={mapa} alt="Mapa" />
            </div>
         </main>
      </>
   )
}