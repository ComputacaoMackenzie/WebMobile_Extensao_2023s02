import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
   return (
      <>
         <main>
            <h1>Home</h1>
            <div class="intro">
               <h2>Bem-vindo!</h2>
               <p>Conheça os restaurantes do Mackenzie Higienópolis e escolha a melhor opção para você!</p>
               <a class="btn"><Link to="/Rest">Conheça os restaurantes</Link></a>    
               <a class="btn"><Link to="/Mapa">Veja o mapa do Mackenzie</Link></a>
               <br /><br />
               <br /><br />
               <a href="https://www.youtube.com/embed/reJ5Z65rCYo?si=NzaKsc4LKuNh-gqu">
                  Assista o vídeo no youtube!
               </a>
            </div>
         </main>
      </>
   )
}