import React from "react";
import './Rest.css';

export default function Rest() {
   return (
      <>
      <main>
         <h1>Restaurantes</h1>
		<div className="R1">
			<h2>GRAZZI</h2>
		</div>
		<div className='lista1'>
			<ul>
				<li>10:00 - 21:30</li>
				<li>Sopa de mandioca , pastel , carne moida e salada ceasar</li>
				<li>Praça de alimentação prédio 19</li>
			</ul>
		</div>
		
		<div className="R2">
			<h2>BORGES</h2>
		</div>
		<div className="lista2">
			<ul>
				<li>8:00 - 22:00</li>
				<li>strogonoff , x salada , saladinha</li>
				<li>Praça de alimentação prédio 45</li>
			</ul>
		</div>

		<div className="R3">
			<h2>CHAPADO</h2>
		</div>
		<div className='lista3'>
			<ul>
				<li>11:00 - 22:00</li>
				<li>frango grelhado , feijuca , bife acebolado</li>
				<li> prédio 39, em frente a saída da consolação</li>
			</ul>
		</div>

		<div className="R4">
			<h2>BOBS</h2>
		</div>
		<div className='lista4'>
			<ul>
				<li>12:00 - 21:30</li>
				<li>x salada, big bobs , nuggets </li>
				<li> Praça de alimentação prédio 45</li>
			</ul>
		</div>

		<div className="R5">
			<h2>STARBUCKS</h2>
		</div>
		<div className='lista5'>
			<ul>
				<li>06:30 - 23:30</li>
				<li>café, doces, frapuccinos</li>
				<li>em frente ao prédio 45 (praça de alimentação)</li>
			</ul>
		</div>
	</main>
      </>
   )
}