import './App.css'
import Home from './Home';
import Rest from './Rest';
import Mapa from './Mapa';
import logo from './assets/download.png'
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

function App() {
  

  return (
    <>
      <BrowserRouter>
        <header className="header">
          <div className="Restaurantes">
              <h1>Restaurantes do Mack</h1>
          </div>
          <div>
              <img src={logo} className="logo" width={110} />
              <div className="logo">
                  <h2></h2>
              </div>
              <nav>
                  <Link to="/" className='a'>Home</Link>
                  <Link to="/Rest" className='a'>Restaurantes</Link>
                  <Link to="/Mapa" className='a'>Mapa</Link>
              </nav>
          </div>
        </header>
        <Routes>
          <Route path='/' element={<Home />}></Route>
          <Route path='/Rest' element={<Rest />}></Route>
          <Route path='/Mapa' element={<Mapa />}></Route>
        </Routes>
      </BrowserRouter>
      <footer className="footer">
        <img src={logo} className="logo" width={110} />
            <div class="logo">
                <h2></h2>
            </div>
        <div className="Nomes">
          <p> Antônio César 3248800</p>
          <p>Isabelle Ramos Miranda 42210836</p>
          <p> Pedro Augusto Rubacow Iotti 32026021</p>
          <p>Pedro Gabriel Marotta Silva 32338090</p>
        </div>
      </footer>
    </>
  )
}

export default App;
