import React from 'react'
import { EventBody, EventHeader } from '../components'
import { useLocation } from 'react-router-dom'

function EventPage() {
  const location = useLocation()
  const event = location.state as MackenzieEvent

  return (
    <>
      <EventHeader event={event} />

      <EventBody event={event} />
    </>
  )
}

export default EventPage
