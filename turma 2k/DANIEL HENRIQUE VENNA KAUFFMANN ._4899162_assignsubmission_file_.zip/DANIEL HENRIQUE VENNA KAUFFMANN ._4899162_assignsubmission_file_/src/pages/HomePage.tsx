import React, { useEffect, useState } from 'react'
import { EventGrid, Header, Loading, SearchBar } from '../components'
import { useLocation } from 'react-router-dom'
import { Filters } from '../components/Modal/Modal'
import axios from 'axios'

function HomePage() {
  const location = useLocation()

  const [events, setEvents] = useState<Array<MackenzieEvent>>([])
  const [filteredEvents, setFilteredEvents] = useState<Array<MackenzieEvent>>([])

  useEffect(() => {
    const filter = Number(location.search.split('=')[1]) as Filters
    let newEvents = Array<MackenzieEvent>()

    if (filter) {
      switch (filter) {
        case Filters.sp:
          newEvents = events.filter((event) => event.inSP)
          break

        case Filters.df:
          newEvents = events.filter((event) => !event.inSP)
          break

        case Filters.party:
          newEvents = events.filter((event) => event.isParty)
          break

        case Filters.congress:
          newEvents = events.filter((event) => !event.isParty)
          break

        case Filters.thisYear:
          newEvents = events.filter((event) => !event.nextYear)
          break

        case Filters.nextYear:
          newEvents = events.filter((event) => event.nextYear)
          break
      }
    } else {
      newEvents = events
    }

    setFilteredEvents(newEvents)
  }, [events, location])

  useEffect(() => {
    axios
      .get<Array<MackenzieEvent>>('https://get-events-3krst4qfka-uc.a.run.app/')
      .then((response) => {
        setEvents(response.data)
        setFilteredEvents(response.data)
      })
  }, [])

  return (
    <>
      <Header />

      <SearchBar />

      {events.length === 0 ? <Loading /> : <EventGrid events={filteredEvents} />}
    </>
  )
}

export default HomePage
