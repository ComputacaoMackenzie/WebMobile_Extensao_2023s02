import HomePage from './HomePage'
import EventPage from './EventPage'

export { HomePage, EventPage }
