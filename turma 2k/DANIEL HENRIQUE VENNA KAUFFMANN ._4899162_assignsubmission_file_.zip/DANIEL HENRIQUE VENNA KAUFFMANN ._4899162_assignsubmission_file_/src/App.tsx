/*
 * Daniel Henrique Venna Kauffmann - 32074956
 * Lucas Santiago Garcia - 32023006
 */

import React from 'react'
import './App.css'
import { Route, Routes, useLocation } from 'react-router-dom'
import { EventPage, HomePage } from './pages'
import { Modal } from './components'
import { ModalType } from './components/Modal/Modal'

function App() {
  const location = useLocation()
  const previousLocation = location.state?.previousLocation

  return (
    <>
      <Routes location={previousLocation || location}>
        <Route path="/" element={<HomePage />} />
        <Route path="/event/:id" element={<EventPage />} />
      </Routes>

      {previousLocation && (
        <Routes>
          <Route path="/what" element={<Modal type={ModalType.what} />} />
          <Route path="/where" element={<Modal type={ModalType.where} />} />
          <Route path="/when" element={<Modal type={ModalType.when} />} />
        </Routes>
      )}
    </>
  )
}

export default App
