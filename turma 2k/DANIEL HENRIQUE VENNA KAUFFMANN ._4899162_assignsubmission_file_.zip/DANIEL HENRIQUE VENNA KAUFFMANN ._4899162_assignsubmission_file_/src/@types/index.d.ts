declare module '*.png'

interface MackenzieEvent {
  id: string
  title: string
  date: string
  location: string
  description: string
  imageUrl: string
  mapUrl?: string
  isParty: boolean
  nextYear: boolean
  inSP: boolean
}
