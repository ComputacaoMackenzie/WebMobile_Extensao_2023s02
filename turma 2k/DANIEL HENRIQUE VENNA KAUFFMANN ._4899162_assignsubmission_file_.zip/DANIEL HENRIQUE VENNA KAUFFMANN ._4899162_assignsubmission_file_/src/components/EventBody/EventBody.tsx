import React from 'react'
import './style.css'

function EventBody({ event }: { event: MackenzieEvent }) {
  return (
    <div className="information">
      <div className="details">
        <p className="date">{event.date}</p>

        <p className="title">{event.title}</p>

        <p className="location">{event.location}</p>

        <p className="description">{event.description}</p>
      </div>

      {event.mapUrl && (
        <div className="map">
          <p>Mapa do Campus</p>

          <img src={event.mapUrl} alt="Campus map" />
        </div>
      )}
    </div>
  )
}

export default EventBody
