import React from 'react'
import './style.css'
import { EventCard } from '../index'

function EventGrid({ events }: { events: Array<MackenzieEvent> }) {
  return (
    <div className="events">
      {events.map((event) => {
        return <EventCard key={event.id} event={event} />
      })}
    </div>
  )
}

export default EventGrid
