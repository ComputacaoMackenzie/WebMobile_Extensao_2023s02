import React from 'react'
import './style.css'
import CrowBackground from '../../assets/crowd-background.png'

function Header() {
  return (
    <>
      <div className="header">
        <p className="name">itertain</p>

        <p className="subtitle">
          encontre <span>suas</span>
        </p>

        <p className="subtitle">
          melhores <span>experiências</span>
        </p>
      </div>

      <img className="crowd" src={CrowBackground} alt="Party crowd background" />
    </>
  )
}

export default Header
