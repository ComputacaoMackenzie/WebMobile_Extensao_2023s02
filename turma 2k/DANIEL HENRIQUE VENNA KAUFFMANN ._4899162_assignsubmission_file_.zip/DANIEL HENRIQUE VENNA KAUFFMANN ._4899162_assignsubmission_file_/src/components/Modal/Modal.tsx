import React, { ChangeEvent, useState } from 'react'
import './style.css'
import { useNavigate } from 'react-router-dom'
import { Button } from '../index'

export enum ModalType {
  what = 'what',
  where = 'where',
  when = 'when'
}

export enum Filters {
  party = 1,
  congress,
  sp,
  df,
  thisYear,
  nextYear
}

function Modal({ type }: { type?: ModalType }) {
  const navigate = useNavigate()

  const [filter, setFilter] = useState<Filters | null>(null)

  function onClose() {
    if (filter) {
      navigate(`/?filter=${filter}`)
    } else {
      navigate(-1)
    }
  }

  function onChangeFilter(event: ChangeEvent<HTMLInputElement>) {
    setFilter(Number(event.target.value) as Filters)
  }

  function renderModalType() {
    switch (type) {
      case ModalType.what:
        return (
          <div className="content">
            <p>filtrando</p>

            <h1>O que</h1>

            <div className="option">
              <input type="radio" value={Filters.party} onChange={onChangeFilter} />
              <label>Festa</label>
            </div>

            <div className="option" style={{ marginBottom: 56 }}>
              <input type="radio" value={Filters.congress} onChange={onChangeFilter} />
              <label>Congresso</label>
            </div>

            <Button label="OK" onClick={onClose} />
          </div>
        )
      case ModalType.where:
        return (
          <div className="content">
            <p>filtrando</p>

            <h1>Onde</h1>

            <div className="option">
              <input type="radio" value={Filters.sp} onChange={onChangeFilter} />
              <label>São Paulo</label>
            </div>

            <div className="option" style={{ marginBottom: 56 }}>
              <input type="radio" value={Filters.df} onChange={onChangeFilter} />
              <label>Brasília</label>
            </div>

            <Button label="OK" onClick={onClose} />
          </div>
        )
      case ModalType.when:
        return (
          <div className="content">
            <p>filtrando</p>

            <h1>Quando</h1>

            <div className="option">
              <input type="radio" value={Filters.thisYear} onChange={onChangeFilter} />
              <label>Este ano</label>
            </div>

            <div className="option" style={{ marginBottom: 56 }}>
              <input type="radio" value={Filters.nextYear} onChange={onChangeFilter} />
              <label>Ano que vem</label>
            </div>

            <Button label="OK" onClick={onClose} />
          </div>
        )
    }
  }

  return (
    <dialog className="modal-wrapper">
      <div className="modal">{renderModalType()}</div>
    </dialog>
  )
}

export default Modal
