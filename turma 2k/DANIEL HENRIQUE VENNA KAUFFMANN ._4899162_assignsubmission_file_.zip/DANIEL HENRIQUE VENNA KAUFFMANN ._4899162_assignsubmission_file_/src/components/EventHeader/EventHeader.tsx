import React from 'react'

function EventHeader({ event }: { event: MackenzieEvent }) {
  return (
    <>
      <div className="header">
        <p className="name">{event.title}</p>
      </div>

      <img className="crowd" src={event.imageUrl} alt="Event banner" />

      <button className="anchor-right">
        <p>Participar</p>
      </button>
    </>
  )
}

export default EventHeader
