import React from 'react'
import './style.css'

function Button({ label, onClick }: { label: string; onClick?: Function }) {
  return (
    <button onClick={() => (onClick ? onClick() : undefined)}>
      <p>{label}</p>
    </button>
  )
}

export default Button
