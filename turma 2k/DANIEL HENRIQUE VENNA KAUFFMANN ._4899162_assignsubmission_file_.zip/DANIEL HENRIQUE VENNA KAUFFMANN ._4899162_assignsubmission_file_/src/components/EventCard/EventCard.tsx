import React from 'react'
import './style.css'
import { useNavigate } from 'react-router-dom'

function EventCard({ event }: { event: MackenzieEvent }) {
  const navigate = useNavigate()

  function onEvent() {
    navigate(`/event/${event.id}`, { state: event })
  }

  return (
    <div className="card" onClick={onEvent}>
      <img className="banner" src={event.imageUrl} alt="Event banner" />

      <div className="content">
        <p className="date">{event.date}</p>

        <p className="title">{event.title}</p>

        <p className="location">{event.location}</p>
      </div>
    </div>
  )
}

export default EventCard
