import './style.css'
import { Button } from '../index'
import { ModalType } from '../Modal/Modal'
import { useLocation, useNavigate } from 'react-router-dom'

function SearchBar() {
  const location = useLocation()
  const navigate = useNavigate()

  function onClickFilter(modalType: ModalType) {
    navigate(`/${modalType}`, { state: { previousLocation: location } })
  }

  return (
    <>
      <div className="filters">
        <div className="filter" onClick={() => onClickFilter(ModalType.what)}>
          <p className="name">
            <i className="icon fas fa-search"></i>O que
          </p>

          <p className="description">Busque por palavras chaves</p>
        </div>

        <div className="separator"></div>

        <div className="filter" onClick={() => onClickFilter(ModalType.where)}>
          <p className="name">
            <i className="icon fas fa-map-pin"></i>
            Onde
          </p>

          <p className="description">Adicione regiões</p>
        </div>

        <div className="separator"></div>

        <div className="filter" onClick={() => onClickFilter(ModalType.when)}>
          <p className="name">
            <i className="icon fas fa-calendar"></i>
            Quando
          </p>

          <p className="description">Filtre por datas</p>
        </div>

        <Button label="Limpar filtros" onClick={() => navigate('/')} />
      </div>
    </>
  )
}

export default SearchBar
