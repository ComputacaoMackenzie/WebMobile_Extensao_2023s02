import Index from "./components/index/Index";

export default function Home() {
  return (
    <main>
      <Index />
    </main>
  )
}
