import React, { useEffect } from "react";

function Maps() {
  useEffect(() => {
    // Função initMap para criar o mapa e adicionar um marcador
    function initMap() {
      const myLatLng = {
        lat: -23.412562165143914,
        lng: -46.5556618210458
      };
      const map = new window.google.maps.Map(
        document.getElementById("googleMap"),
        {
          zoom: 15,
          center: myLatLng,
          fullscreenControl: false,
          zoomControl: true,
          streetViewControl: false
        }
      );
      const geocoder = new window.google.maps.Geocoder();
      const address = "Acampamento Cabuçu Mackenzie"; // Endereço específico

      geocoder.geocode({ address: address }, (results, status) => {
        if (status === "OK") {
          map.setCenter(results[0].geometry.location);
          new window.google.maps.Marker({
            map: map,
            position: results[0].geometry.location,
            title: "Acampamento Cabuçu Mackenzie"
          });
        }
      });
    }

    // Verifica se a API do Google Maps foi carregada antes de chamar a função initMap
    if (window.google) {
      initMap();
    } else {
      console.error("A API do Google Maps não foi carregada corretamente.");
    }
  }, []);

  return <div id="googleMap" style={{ width: "100%", height: "400px" }}></div>;
}

export default Maps;
