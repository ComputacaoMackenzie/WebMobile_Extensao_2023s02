// Acampamentos component
import React from "react";
import { Outlet, Link } from "react-router-dom";

const linkStyle = {
  margin: "1rem",
  textDecoration: "none",
  color: "blue"
};

const Acampamentos = ({ camps, state }) => {
  return (
    <>
      <div id="acampamentos">
        {camps.map((camp) => (
          <Link key={camp.name} to="/detalhes" style={linkStyle} state={state}>
            <div className="acampamento">{camp.name}</div>
          </Link>
        ))}
      </div>
      <Outlet />
    </>
  );
};

export default Acampamentos;
