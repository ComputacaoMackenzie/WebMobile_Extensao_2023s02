import "./confirmadaStyle.css";
import { useLocation } from "react-router-dom";
import Seta from "../../Seta";

export default function App() {
  redirect = "/detalhes";
  const { state } = useLocation();
  return (
    <section className="backgroundImg">
      <div id="images">
        <Seta redirect={redirect} state={state} />
      </div>
      <h1 id="textoObrigado">OBRIGADO POR CONFIRMAR SUA PRESENÇA!</h1>
      <h1 id="textoPrepare">
        SE PREPARE PARA A MAIOR EXPERIÊNCIA DE CONEXÃO DA SUA VIDA!
      </h1>
    </section>
  );
}
