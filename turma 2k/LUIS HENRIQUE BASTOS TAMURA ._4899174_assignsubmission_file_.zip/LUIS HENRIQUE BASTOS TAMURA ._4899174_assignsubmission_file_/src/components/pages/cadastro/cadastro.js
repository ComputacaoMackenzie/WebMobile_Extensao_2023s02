import "./cadastroStyle.css";
import crossImg from "../../../../public/img/cross.jpg";
import Seta from "../../Seta";
import { Link } from "react-router-dom";
import { useLocation } from "react-router-dom";

export default function App() {
  redirect = "/detalhes";
  const { state } = useLocation();
  let data;
  if (state && state.isConfirmed) {
    data = { isConfirmed: true };
  } else {
    data = { isConfirmed: false };
  }

  function setState() {
    data = { isConfirmed: true };
  }
  return (
    <section>
      <div className="mainSection">
        <Seta redirect={redirect} state={data} />
        <h1 id="textoTopoCadastro">FORMULÁRIO DE CONFIRMAÇÃO DE PRESENÇA</h1>
        {!data.isConfirmed ? (
          <section>
            <div id="formsImagem">
              <div className="listaForms">
                <div className="form">
                  <div className="tituloForm">Nome Completo</div>
                  <input type="text" placeholder="Digite seu nome completo" />
                </div>
                <div className="form">
                  <div className="tituloForm">CPF</div>
                  <input
                    type="number"
                    placeholder="Digite o número do seu CPF"
                  />
                </div>
                <div className="form">
                  <div className="tituloForm">RG</div>
                  <input
                    type="number"
                    placeholder="Digite o número do seu RG"
                  />
                </div>
                <div className="form">
                  <div className="tituloForm">TELEFONE</div>
                  <input
                    type="tel"
                    placeholder="Digite o número do seu Telefone"
                  />
                </div>
                <div className="form">
                  <div className="tituloForm">TIA</div>
                  <input
                    type="number"
                    placeholder="Digite o número do seu TIA"
                  />
                </div>
                <div className="form">
                  <div className="tituloForm">E-MAIL</div>
                  <input
                    type="email"
                    placeholder="Digite o seu melhor e-mail"
                  />
                </div>
              </div>
              <div id="cruz">
                <img src={crossImg} alt="cruz"></img>
              </div>
            </div>
            <div id="botaoConfirmar">
              <Link
                to="/confirmada"
                onClick={setState()}
                state={data}
                style={{ textDecoration: "none" }}
              >
                <button className="custom-button">Confirmar Presença</button>
              </Link>
            </div>
          </section>
        ) : (
          <h2 id="textoConfirmado">FORMULÁRIO PREENCHIDO!</h2>
        )}
      </div>
      <svg
        className="wavesCadastro"
        viewBox="0 24 150 28"
        preserveAspectRatio="none"
        shapeRendering="auto"
      >
        <defs>
          <path
            id="gentle-wave"
            d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z"
          />
        </defs>
        <g className="parallax">
          <use
            xlinkHref="#gentle-wave"
            x="48"
            y="0"
            fill="rgba(255,255,255,0.7"
          />
          <use
            xlinkHref="#gentle-wave"
            x="48"
            y="3"
            fill="rgba(255,255,255,0.5)"
          />
          <use
            xlinkHref="#gentle-wave"
            x="48"
            y="5"
            fill="rgba(255,255,255,0.3)"
          />
        </g>
      </svg>
    </section>
  );
}
