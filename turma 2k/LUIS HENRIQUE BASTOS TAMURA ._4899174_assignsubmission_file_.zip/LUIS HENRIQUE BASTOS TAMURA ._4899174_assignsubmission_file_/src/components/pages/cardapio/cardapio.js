import "./cardapioStyle.css";
import Seta from "../../Seta";
import { useLocation } from "react-router-dom";

export default function App() {
  redirect = "/detalhes";
  const { state } = useLocation();
  return (
    <section>
      <Seta redirect={redirect} state={state}/>
      <div className="mainCardapio">
        <div className="cardapioGroup">
          <div className="textCardapio">CARDÁPIO DO DIA 19 DE AGOSTO</div>
          <div id="cardapios">
            <div className="cardapio">
              <div className="tituloCardapio">Café da Manhã</div>
              <div className="listaCardapio">
                <ul>
                  <li>Pães Diversos</li>
                  <li>Frios</li>
                  <li>Suco de Laranja e Abacaxi</li>
                  <li>Café e Leite</li>
                  <li>Pão de Queijo</li>
                  <li>Ovos</li>
                  <li>Torta de Frango</li>
                </ul>
              </div>
            </div>
            <div className="cardapio">
              <div className="tituloCardapio">Almoço</div>
              <div className="listaCardapio">
                <ul>
                  <li>Arroz normal e integral</li>
                  <li>Feijão carioca e preto</li>
                  <li>Suco de Maracujá e Morango</li>
                  <li>Peito de Frango grelhado</li>
                  <li>Legumes grelhados</li>
                  <li>Ovo mexido</li>
                  <li>Estação de Saladas</li>
                  <li>Carne de Soja</li>
                </ul>
              </div>
            </div>
            <div className="cardapio">
              <div className="tituloCardapio">Lanche da Tarde</div>
              <div className="listaCardapio">
                <ul>
                  <li>Frutas diversas</li>
                  <li>Iogurte de Morango</li>
                  <li>Suco de Laranja com Acerola</li>
                  <li>Pães e Frios</li>
                  <li>Panqueca doce</li>
                  <li>Chá verde e preto</li>
                  <li>Café e Leite</li>
                </ul>
              </div>
            </div>
            <div className="cardapio">
              <div className="tituloCardapio">Jantar</div>
              <div className="listaCardapio">
                <ul>
                  <li>Macarrão com molho branco</li>
                  <li>Sobrecoxa de frango grelhada</li>
                  <li>Carne de Soja</li>
                  <li>Arroz normal e integral</li>
                  <li>Estação de Saladas</li>
                  <li>Suco de uva e melância</li>
                  <li>Frutas diversas</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="cardapioGroup">
          <div className="textCardapio">CARDÁPIO DO DIA 20 DE AGOSTO</div>
          <div id="cardapios">
            <div className="cardapio">
              <div className="tituloCardapio">Café da Manhã</div>
              <div className="listaCardapio">
                <ul>
                  <li>Pães diversos</li>
                  <li>Frios</li>
                  <li>Suco de laranja com cenoura</li>
                  <li>Café e leite quente</li>
                  <li>Pão de Queijo</li>
                  <li>Ovos</li>
                  <li>Torta de Palmito</li>
                  <li>Frutas diversas</li>
                </ul>
              </div>
            </div>
            <div className="cardapio">
              <div className="tituloCardapio">Almoço</div>
              <div className="listaCardapio">
                <ul>
                  <li>Arroz normal e integral</li>
                  <li>Feijoada Light</li>
                  <li>Suco de Abacaxi e Laranja</li>
                  <li>Couve refogada</li>
                  <li>Laranja</li>
                  <li>Estação de Saladas</li>
                  <li>Curry de Cogumelos</li>
                </ul>
              </div>
            </div>
            <div className="cardapio">
              <div className="tituloCardapio">Lanche da Tarde</div>
              <div className="listaCardapio">
                <ul>
                  <li>Frutas diversas</li>
                  <li>Iogurte de morango</li>
                  <li>Suco de manga</li>
                  <li>Pães e frios</li>
                  <li>Panqueca de frango</li>
                  <li>Chá de hibisco</li>
                  <li>Café e leite</li>
                </ul>
              </div>
            </div>
            <div className="cardapio">
              <div className="tituloCardapio">Jantar</div>
              <div className="listaCardapio">
                <ul>
                  <li>Escondidinho de calabresa</li>
                  <li>Ragu de carne de jaca</li>
                  <li>Arroz normal e integral</li>
                  <li>Estação de saladas</li>
                  <li>Suco de melão e limão</li>
                  <li>Frutas diversas</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <svg
        className="wavesCardapio"
        viewBox="0 24 150 28"
        preserveAspectRatio="none"
        shapeRendering="auto"
      >
        <defs>
          <path
            id="gentle-wave"
            d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z"
          />
        </defs>
        <g className="parallax">
          <use
            xlinkHref="#gentle-wave"
            x="48"
            y="0"
            fill="rgba(255,255,255,0.7"
          />
          <use
            xlinkHref="#gentle-wave"
            x="48"
            y="3"
            fill="rgba(255,255,255,0.5)"
          />
          <use
            xlinkHref="#gentle-wave"
            x="48"
            y="5"
            fill="rgba(255,255,255,0.3)"
          />
        </g>
      </svg>
    </section>
  );
}
