import "./detalhesStyle.css";
import Weather from "../../Weather";
import Seta from "../../Seta";
import Maps from "../../Maps";
import { Link } from "react-router-dom";
import { useLocation } from "react-router-dom";

export default function App() {
  redirect = "/";
  const { state } = useLocation();
  return (
    <section>
      <div className="sectionDiv">
        <Seta redirect={redirect} state={state} />
        <div id="titulo">Encontro de Jovens com Cristo</div>
        <div id="container1">
          <div id="containerMapa">
            <div id="textoLocal">Local de encontro dos Jovens com Cristo</div>
            <Maps />
          </div>
          <div id="containerTextoSpotify">
            <div id="textoDetalhes">
              Já anota aí na sua agenda para não perder: 19 e 20 de agosto! Se
              você não conhece, o Encontro de Jovens com Cristo (EJC) é um
              evento voltado para jovens solteiros, entre 18 e 35 anos, que tem
              o objetivo de anunciar o amor de Jesus Cristo. Contamos com um
              cardápio especial no acampamento e uma playlist do encontro no
              qual você pode contribuir com músicas que gostar.
            </div>

            <div id="containerSpotify">
              <div id="textoMusica">Playlist do Acampamento</div>
              <iframe
                title="spotify"
                style={{ borderRadius: "12px" }}
                src={
                  "https://open.spotify.com/embed/playlist/1Dju3srsyifFhVtPxxf6Gh?utm_source=generator&theme=0"
                }
                width={"200%"}
                height={"100"}
                frameBorder={"0"}
                allowFullScreen={""}
                allow={[
                  "autoplay",
                  "clipboard-write",
                  "encrypted-media",
                  "fullscreen",
                  "picture-in-picture",
                ]}
                loading={"lazy"}
                id="imagemSpotify"
              ></iframe>
            </div>
          </div>
        </div>

        <div>
          <div id="containerPrevisao">
            <div id="tituloPrevisao">Previsão do Tempo no Acampamento</div>
            <div className="previsaoTempo wrapper">
              <Weather />
            </div>
          </div>
          <div id="containerBotoes">
            <Link
              to="/cardapio"
              state={state}
              style={{ textDecoration: "none" }}
            >
              <div id="botao">Consultar Cardápio</div>
            </Link>
            <Link
              to="/cadastro"
              state={state}
              style={{ textDecoration: "none" }}
            >
              <div id="botao">Formulário de Presença</div>
            </Link>
          </div>
        </div>
      </div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" id="waves">
        <path
          fill="#000b76"
          fillOpacity="1"
          d="M0,288L34.3,293.3C68.6,299,137,309,206,309.3C274.3,309,343,299,411,261.3C480,224,549,160,617,160C685.7,160,754,224,823,208C891.4,192,960,96,1029,74.7C1097.1,53,1166,107,1234,112C1302.9,117,1371,75,1406,53.3L1440,32L1440,320L1405.7,320C1371.4,320,1303,320,1234,320C1165.7,320,1097,320,1029,320C960,320,891,320,823,320C754.3,320,686,320,617,320C548.6,320,480,320,411,320C342.9,320,274,320,206,320C137.1,320,69,320,34,320L0,320Z"
        ></path>
      </svg>
    </section>
  );
}
