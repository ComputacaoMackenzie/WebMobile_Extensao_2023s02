import "./pagInicialStyle.css";
import { useLocation } from "react-router-dom";
import React from "react";
import Acampamentos from "../../../components/Acampamentos";

function pagInicial() {
  const camps = [
    { name: "Acampamento Jovens Com Cristo" },
    { name: "Acampamento Lovers" },
    { name: "Acampamento Auuuuuuuuu" },
    { name: "Acampamento Crystal Lake" }
  ];
  const { state } = useLocation();
  return (
    <section id="sectionInicial">
      <div id="retTopo">
        <div id="textoTopo">SEJA BEM VINDO AO CAMP CRISTO!</div>
      </div>
      <div id="textoMeio">
        Aqui você encontrará todas as informações necessárias para se situar nos
        próximos eventos. Como local, datas, horários de saída e chegada.
      </div>
      <Acampamentos camps={camps} state={state} />
      <div id="fundoFoto">
        <img
          id="fundo"
          src={require("../../../../public/img/fundo.png")}
          alt="teste"
          srcSet=""
        />
      </div>
    </section>
  );
}

export default pagInicial;
