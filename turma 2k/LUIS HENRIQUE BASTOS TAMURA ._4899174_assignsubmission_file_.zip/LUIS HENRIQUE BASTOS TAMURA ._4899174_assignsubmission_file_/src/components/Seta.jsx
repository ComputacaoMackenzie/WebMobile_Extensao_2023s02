import React from "react";
import voltarImg from "../../public/img/voltar.png";
import setaImg from "../../public/img/seta.png";
import { Link } from "react-router-dom";

const linkStyle = {
  margin: "1rem",
  textDecoration: "none",
  color: "blue",
};

const Seta = (redirect) => {
  function log() {
    console.log(redirect.redirect);
    console.log(redirect.state);
  }
  return (
    <div id="images">
      <Link
        to={redirect.redirect}
        state={redirect.state}
        id="linkVoltar"
        onClick={log}
        style={linkStyle}
      >
        <img src={voltarImg} alt="texto voltar" id="textoVoltar" />
        <img src={setaImg} alt="setinha" />
      </Link>
    </div>
  );
};

export default Seta;
