import React from "react";
import "./App.css";
import PagInicial from "./components/pages/pagInicial/pagInicial";
import Detalhes from "./components/pages/detalhes/detalhes";
import Cadastro from "./components/pages/cadastro/cadastro";
import Confirmada from "./components/pages/confirmada/confirmada";
import Cardapio from "./components/pages/cardapio/cardapio";
import { BrowserRouter, Route, Routes } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<PagInicial />} />
        <Route exact path="/detalhes" element={<Detalhes />} />
        <Route exact path="/cadastro" element={<Cadastro />} />
        <Route exact path="/confirmada" element={<Confirmada />} />
        <Route exact path="/cardapio" element={<Cardapio />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
