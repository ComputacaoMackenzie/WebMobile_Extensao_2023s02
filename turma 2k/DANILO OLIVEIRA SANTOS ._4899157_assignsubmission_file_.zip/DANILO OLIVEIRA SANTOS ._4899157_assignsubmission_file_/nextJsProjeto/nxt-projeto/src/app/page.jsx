import styles from './page.module.css'
export default function Home() {
  return (
    <div>
       <section className={styles.section}>
        <div className={styles.secao}>
            <h2>Bem-Vindo à Equipe de Basquete da Faculdade Mackenzie</h2>
            <p>Nossa equipe de basquete da Faculdade Mackenzie é uma família dedicada ao esporte e à excelência
                acadêmica. Com um histórico de sucesso e uma paixão compartilhada
                pelo jogo, estamos comprometidos em alcançar novas alturas dentro e fora da quadra.</p>
            <h2>Nossa História</h2>
            <p>Nossa jornada é permeada por conquistas notáveis e momentos memoráveis. Desde o nosso início, temos
                trabalhado incansavelmente para representar nossa faculdade com
                dignidade e espírito esportivo. Cada temporada é uma oportunidade de crescimento, aprendizado e
                superação de desafios.</p>
            <h2>Nossos Valores</h2>
            <p>Na equipe de basquete da Faculdade Mackenzie, acreditamos na importância de valores como trabalho em
                equipe, resiliência e dedicação. Esses valores nos guiam não
                apenas em nossa busca por vitórias, mas também em nossa busca por desenvolvimento pessoal e acadêmico.
            </p>
            <h2>Missão e Visão</h2>
            <p>Nossa missão é inspirar e capacitar nossos jogadores a se tornarem não apenas atletas talentosos, mas
                também líderes em suas vidas futuras. Visamos promover a ética
                de trabalho, o comprometimento e a excelência em todos os aspectos de nossas vidas acadêmicas e
                esportivas.</p>
            <h2>Junte-se a Nós</h2>
            <p>Se você compartilha nossa paixão pelo basquete e deseja fazer parte de uma equipe que valoriza o
                crescimento e o espírito esportivo, estamos ansiosos
                para recebê-lo em nosso time. Venha fazer parte da emocionante jornada da equipe de basquete da
                Faculdade Mackenzie!</p>
            <table className={styles.conquistas}>
                <h2>Conquistas da Equipe de Basquete</h2>
                <tr>
                    <th>Ano</th>
                    <th>Campeonato</th>
                    <th>Conquista</th>
                </tr>
                <tr>
                    <td>2019</td>
                    <td>Campeonato Universitário Estadual</td>
                    <td>Campeões</td>
                </tr>
                <tr>
                    <td>2020</td>
                    <td>Torneio Nacional de Basquete Universitário</td>
                    <td>Campeões</td>
                </tr>
                <tr>
                    <td>2018</td>
                    <td>Campeonato Internacional Universitário</td>
                    <td>Medalha de Bronze</td>
                </tr>
                <tr>
                    <td>2021</td>
                    <td>Campeonato Universitário Estadual</td>
                    <td>Vice-Campeões</td>
                </tr>
            </table>
        </div>

    </section>

    <footer className={styles.footer}>
        <h2>Contato</h2>
        <p>Entre em contato conosco para mais informações sobre o time de basquete da Faculdade Mackenzie:</p>
        <p>Email: basquete@mackenzie.edu.br</p>
        <p>Telefone: (11) 1234-5678</p>
    </footer>
    </div>
  )
}
