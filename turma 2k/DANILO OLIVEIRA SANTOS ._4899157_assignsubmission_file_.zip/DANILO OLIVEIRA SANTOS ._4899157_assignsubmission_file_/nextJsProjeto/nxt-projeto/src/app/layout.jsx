import Link from 'next/link'
import styles from './page.module.css'
export const metadata = {
  title: 'Mackenzie - Basquete',
  charset: 'UTF-8',
}
export default function RootLayout({ children }) {
  return (
    <html lang="pt-br">
      <link rel="icon" type="./image/jpg" href="iconMack.png" />
      <body className={styles.body}>
      <header className={styles.header}>
        <h1 className={styles.h1}>Time de Basquete da Faculdade Mackenzie</h1>
        <img src="./public/logo_mack.png" alt="Logo da Faculdade Mackenzie"></img>
        <nav className={styles.nav}>
            <ul>
                <li><Link href="/">Página Principal</Link></li>
                <li><Link href="/jogadores">Jogadores</Link></li>
                <li><Link href="/calendario">Calendário</Link></li>
                <li><Link href="/dieta">Dieta e Treino</Link></li>
            </ul>
        </nav>
      </header>
      {children}
      </body>
    </html>
  )
}