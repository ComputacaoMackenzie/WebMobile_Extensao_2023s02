import styles from './page.module.css'
import { getAllJogadores } from '../services/getAllJogadores';
export default async function jogadores(){
    const jogadores = await getAllJogadores();
    return(
        <div>
            <section className={styles.jogadores}>
                <div className={styles.jogadores_one}>
                    <h2>Jogadores famosos de nossa universidade!</h2>
                    <ul>
                        <h1>Nome e posição</h1>
                        {jogadores.map(jogador => (
                        <li>
                            {jogador.first_name} {jogador.last_name} - {jogador.position} 
                        </li>
                        ))}          
                    </ul>
                </div>
            </section>
            <footer className={styles.footer}>
                <h2>Contato</h2>
                <p>Entre em contato conosco para mais informações sobre o time de basquete da Faculdade Mackenzie:</p>
                <p>Email: basquete@mackenzie.edu.br</p>
                <p>Telefone: (11) 1234-5678</p>
            </footer>
        </div>
    )
}