export async function getAllJogadores(){
    const response = await fetch('https://www.balldontlie.io/api/v1/players');
    const jogadores = await response.json();
    return jogadores?.data || [];
}