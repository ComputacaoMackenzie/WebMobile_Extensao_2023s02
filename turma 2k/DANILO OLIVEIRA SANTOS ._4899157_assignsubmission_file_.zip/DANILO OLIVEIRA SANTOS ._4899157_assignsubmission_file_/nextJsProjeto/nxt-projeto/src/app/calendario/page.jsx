import styles from './page.module.css';
export default function calendario(){
    return(
        <div>
            <section className={styles.calendario}>
                <h2 className={styles.font}>Calendário</h2>
                <div className={styles.treinos}>
                    <h3 className={styles.font}>Treinos</h3>
                    <table>
                        <tr>
                            <th>Dia da Semana</th>
                            <th>Horário</th>
                        </tr>
                        <tr>
                            <td>Segunda-feira</td>
                            <td>18:00 - 20:00</td>
                        </tr>
                        <tr>
                            <td>Quarta-feira</td>
                            <td>18:00 - 20:00</td>
                        </tr>
                        <tr>
                            <td>Sexta-feira</td>
                            <td>18:00 - 20:00</td>
                        </tr>
                    </table>
                </div>
                <div className={styles.campeonatos}>
                    <h3 className={styles.font}>Próximos Campeonatos</h3>
                    <ul>
                        <li>
                            <strong>Campeonato Regional</strong>
                            <p>Data: 15 de outubro de 2023</p>
                        </li>
                        <li>
                            <strong>Torneio Universitário</strong>
                            <p>Data: 28 de novembro de 2023</p>
                        </li>
                    </ul>
                </div>
            </section>
            <footer className={styles.footer}>
                <h2>Contato</h2>
                <p>Entre em contato conosco para mais informações sobre o time de basquete da Faculdade Mackenzie:</p>
                <p>Email: basquete@mackenzie.edu.br</p>
                <p>Telefone: (11) 1234-5678</p>
            </footer>
        </div>
    )
}