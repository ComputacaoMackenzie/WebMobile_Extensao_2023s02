import Image from "next/image";
import Index from "./index/Index";
import Basquete from "./pages/basquete/Basquete";
import NBA from "./pages/nba/NBA";
import NbaCard from "./components/NbaCard";

export default function Home() {
  // return <NBA />;
  return <Index />;
  // return <Basquete />;
  //return (
  //  <>
  //    <NbaCard id={145} />
  //    <NbaCard id={137} />
  //    <NbaCard id={133} />
  //  </>
  //);
}
