import Image from "next/image";
import NBA from "./NBA";

export default function Home() {
  return <NBA />;
}
