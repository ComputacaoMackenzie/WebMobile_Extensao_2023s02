"use client";
import "./NBA.css";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import NbaCard from "../../components/NbaCard";

export default function NBA() {
  return (
    <div>
      <Header index={false} />
      <div style={{ width: "100%" }}>
        <NbaCard id={133} backgroud="green" />
        <NbaCard id={137} backgroud="red" />
        <NbaCard id={145} backgroud="purple" />
        <NbaCard id={141} backgroud="yellow" />
        <NbaCard id={154} backgroud="blue" />
      </div>
      <Footer />
    </div>
  );
}
