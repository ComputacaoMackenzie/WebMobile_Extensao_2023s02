import Link from "next/link";
import "./Basquete.css";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import Games from "../../components/Games";
import Carrosel from "../../components/Carrosel";

export default function Basquete() {
  return (
    <div>
      <Header index={false} />

      <div className="time">
        <div></div>
      </div>
      <div className="textoTime">
        <h1 style={{ "font-family": "Anton" }}>Basquete</h1>
        <p>
          No Tecnologia Mackenzie Basquete, celebramos nossa paixão pelo esporte
          e formamos uma comunidade unida. Estamos ansiosos para receber atletas
          que compartilham nosso entusiasmo por conversas animadas, diversão,
          camaradagem e, claro, a prática do basquete. Em nosso time, você
          encontrará uma variedade de indivíduos com diferentes origens e
          interesses, desde estudantes de tecnologia até entusiastas da prática
          esportiva. Seja você um amante do basquete ou alguém em busca de uma
          nova experiência esportiva, temos um lugar reservado para você.
          Estamos ansiosos para que se junte a nós, treine intensamente,
          desfrute de momentos divertidos e participe de partidas de basquete
          com espírito esportivo e leal.
        </p>
      </div>

      <div className="jogos">
        <div className="proximasPartidas">
          <h1>Próximas partidas</h1>
          <Games
            opponent="IME USP"
            local="R. Vinte e Oito de Outubro, 61 - Centro, São Bernardo do Campo - SP, 09721-250"
            data="12/08/2023 - 19:30"
          />
          <Games
            opponent="Engenharia Anhembi"
            local="R. Vinte e Oito de Outubro, 61 - Centro, São Bernardo do Campo - SP, 09721-250"
            data="26/08/2023 - 21:00"
          />
          <Games
            opponent="Medicina Bragança"
            local="R. Vinte e Oito de Outubro, 61 - Centro, São Bernardo do Campo - SP, 09721-250"
            data="17/09/2023 - 19:30"
          />
          <Games
            opponent="Arquitetura Mackenzie"
            local="R. Vinte e Oito de Outubro, 61 - Centro, São Bernardo do Campo - SP, 09721-250"
            data="23/09/2023 - 19:30"
          />
        </div>

        <Carrosel
          url="https://img.olympics.com/images/image/private/t_s_w960/t_s_16_9_g_auto/f_auto/primary/io4r4jrfxulmbhqiicon"
          class="fotosJogos"
        />
      </div>

      <div class="convite">
        <img src="/parte2.png" />
        <div className="informacoes">
          <span
            style={{
              "font-size": "26px",
              "font-weight": "900",
              color: "#FF3131",
              "font-style": "italic",
            }}
          >
            TREINO
          </span>
          <span>Sábados as 8:30</span>
          <span>Local: Prédio 20 - Mackenzie Higienópolis</span>
          <span
            style={{
              padding: "20px 0px 0px 0px",
              "font-size": "26px",
              "font-weight": "900",
              color: "#FF3131",
              "font-style": "italic",
            }}
          >
            CONTATO
          </span>
          <a
            href="https://chat.whatsapp.com/CHdbwRLOKqH62C4d2qyiv0"
            style={{
              color: "#75C7FB",
              "text-decoration": "underline",
              "font-style": "italic",
              "font-weight": "900",
            }}
          >
            Grupo do Whatsapp
          </a>
          <span>Técnica: Sarith</span>
          <span>Diretor de modalidade: Luiz Tavolaro</span>
        </div>
      </div>

      <Footer />
    </div>
  );
}
