import Image from "next/image";
import Basquete from "./Basquete";

export default function Home() {
  return <Basquete />;
}
