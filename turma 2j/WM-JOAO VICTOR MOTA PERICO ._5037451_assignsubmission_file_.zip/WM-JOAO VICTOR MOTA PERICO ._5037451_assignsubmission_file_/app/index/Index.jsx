import "./Index.css";
import Link from "next/link";
import Header from "../components/Header";
import Footer from "../components/Footer";
import Carrosel from "../components/Carrosel";

function Index(props) {
  return (
    <div>
      <Header index={true} />
      <div className="intro">
        <span>
          A Associação Atlética Acadêmica Aurora Albanese foi fundada em, 20 de
          Novembro de 1977, por João Batista de Carvalho, a fim de representar
          os alunos da Faculdade de Computação e Informática (F.C.I).
          <br />
          <br />
          Seu nome foi assim escolhido, em homenagem à Aurora Catharina Giora
          Albanese, primeira Diretora da Faculdade de Computação e Informática
          (F.C.I), fundada em 1970. Em Junho 1985, Doutora Aurora Catharina
          Giora Albanese, tornou-se Reitora da Universidade Presbiteriana
          Mackenzie, onde permaneceu até Julho de 1997.
          <br />
          <br />
          Como na lei da vida, nascemos “pequenos” e evoluímos ao longo do
          tempo. Com muita garra, luta, amor a camisa e principalmente com o
          espírito “Mackenzista” no coração, hoje atingimos nossa “maturidade”,
          nos tornamos uma Atlética temida por muitos, e extremamente respeitada
          por todos. Com muito amor ao esporte e a esta Associação, almejamos
          muito mais, nossa meta é sempre crescer, representar da melhor maneira
          nossos alunos, e levar o nome do Mackenzie sempre ao lugar mais alto,
          que é onde ele merece estar.
        </span>
        <img src="logo_sem_fundo.png" />
      </div>
      <Carrosel
        url="https://duoticket.com.br/portal/imagem/eventos/capa/161629.png"
        class="anuncios"
      />

      <div className="modalidades">
        <div className="fotos">
          <img src="https://imagens.ebc.com.br/-GTLxT9UtLs_ZT0RIwpKAm179u8=/1170x700/smart/https://agenciabrasil.ebc.com.br/sites/default/files/thumbnails/image/53093717375_a2827e3826_o.jpg?itok=jKs07_cT" />
          <img src="https://x1futsal.com.br/wp-content/uploads/2022/07/2022_07_25-Brasil-Campeao-Universitario.jpg" />
          <img src="https://s2.static.brasilescola.uol.com.br/be/2022/08/pessoas-jogando-handebol.jpg" />
          <img src="https://imagens.ebc.com.br/TuvgvsrfGiLiSmGUaJvbPiJe3Uc=/1170x700/smart/https://agenciabrasil.ebc.com.br/sites/default/files/thumbnails/image/2021-07-28t135942z_2117530002_sp1eh7s116686_rtrmadp_3_olympics-2020-vvo-m-team6-gpb-000900.jpg?itok=MIFRvjm6" />
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default Index;
