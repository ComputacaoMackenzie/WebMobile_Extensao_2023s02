import Link from "next/link";
import "./Footer.css";

export default function Footer() {
  return (
    <footer>
      <img src="/preto_branco.png" />
      <Link href="https://www.instagram.com/basqtecmack/">
        <img src="/icone_insta.png" />
      </Link>
    </footer>
  );
}
