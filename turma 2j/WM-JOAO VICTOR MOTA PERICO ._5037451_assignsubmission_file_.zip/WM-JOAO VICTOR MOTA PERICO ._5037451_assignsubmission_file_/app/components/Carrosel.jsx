import "./Carrosel.css";
export default function Carrosel(props) {
  return (
    <div className={props.class}>
      <img src={props.url} />
      <div className="bolinhas">
        <span style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}></span>
        <span></span>
        <span></span>
      </div>
    </div>
  );
}
