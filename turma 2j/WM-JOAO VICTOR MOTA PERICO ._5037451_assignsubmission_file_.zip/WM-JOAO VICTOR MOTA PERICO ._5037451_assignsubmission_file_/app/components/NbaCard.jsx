"use client";
import { useEffect, useState } from "react";
import StatsBar from "./StatsBar";
import "./NbaCard.css";

function TeamStats(props) {
  var totalGames = props.homeGames + props.onRoadGames;

  return (
    <div className="nbaResults" style={{ backgroundColor: props.backgroud }}>
      <div className="logo">
        <img src={props.teamLogo} />
      </div>
      <div className="stats">
        <p>Team: {props.teamName}</p>
        <p>Season: {props.season}</p>
        <StatsBar
          kind="Games Played"
          type="Home"
          reverse="On Road"
          typeValue={props.homeGames}
          reverseValue={props.onRoadGames}
          greenPercentage={(props.homeGames / totalGames) * 100}
          redPercentage={(props.onRoadGames / totalGames) * 100}
        />

        <StatsBar
          kind="Home Record"
          type="Wins"
          reverse="Loss"
          typeValue={props.homeWins}
          reverseValue={props.homeLoss}
          greenPercentage={(props.homeWins / props.homeGames) * 100}
          redPercentage={(props.homeLoss / props.homeGames) * 100}
        />

        <StatsBar
          kind="On Road Record"
          type="Wins"
          reverse="Loss"
          typeValue={props.onRoadWins}
          reverseValue={props.onRoadLoss}
          greenPercentage={(props.onRoadWins / props.onRoadGames) * 100}
          redPercentage={(props.onRoadLoss / props.onRoadGames) * 100}
        />

        <StatsBar
          kind="Season"
          type="Wins"
          reverse="Loss"
          typeValue={props.seasonWins}
          reverseValue={props.seasonLoss}
          greenPercentage={(props.seasonWins / totalGames) * 100}
          redPercentage={(props.seasonLoss / totalGames) * 100}
        />
      </div>
    </div>
  );
}

export default function NbaCard(props) {
  const [team, setTeam] = useState();

  const teamsFetch = () => {
    const league = 12;
    const season = "2022-2023";
    const id = props.id; //145//137//133

    const headers = new Headers({
      "X-RapidAPI-Key": "f1cd865500msh13db90aff14e6ecp138027jsn5a456d9d09fc",
      "X-RapidAPI-Host": "api-basketball.p.rapidapi.com",
    });
    const leagueStatsUrl = `https://api-basketball.p.rapidapi.com/statistics?league=${league}&season=${season}&team=${id}`;

    fetch(leagueStatsUrl, { headers })
      .then((response) => response.json())
      .then((j) => {
        setTeam(j);
      });
  };

  useEffect(teamsFetch, []);

  return (
    <>
      {team && team.response ? (
        <div>
          <TeamStats
            backgroud={props.backgroud}
            teamLogo={team.response.team.logo}
            teamName={team.response.team.name}
            season={team.response.league.season}
            homeGames={team.response.games.played.home}
            onRoadGames={team.response.games.played.away}
            homeWins={team.response.games.wins.home.total}
            homeLoss={team.response.games.loses.home.total}
            onRoadWins={team.response.games.wins.away.total}
            onRoadLoss={team.response.games.loses.away.total}
            seasonWins={team.response.games.wins.all.total}
            seasonLoss={team.response.games.loses.all.total}
          />
        </div>
      ) : (
        <div>loading</div>
      )}
    </>
  );
}
