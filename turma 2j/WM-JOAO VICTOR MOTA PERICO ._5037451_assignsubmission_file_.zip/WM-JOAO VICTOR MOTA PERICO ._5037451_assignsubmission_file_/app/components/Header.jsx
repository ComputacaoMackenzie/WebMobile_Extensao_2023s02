import Link from "next/link";
import "./Header.css";

export default function Header(props) {
  return (
    <header>
      <img src="/logo_tec.jpeg" />
      <div className="menuIcon">
        <div></div>
        <div></div>
        <div></div>
        <nav>
          <Link href="/">Home</Link>
          <Link href={props.index ? "pages/basquete" : "./basquete"}>
            Basquete
          </Link>
          <Link href={props.index ? "pages/nba" : "./nba"}>Nba</Link>
        </nav>
      </div>
    </header>
  );
}
