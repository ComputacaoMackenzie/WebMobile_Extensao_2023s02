export default function Games(props) {
  return (
    <div>
      <span style={{ "font-family": "Anton" }}>TECMACK x {props.opponent}</span>
      <br />
      <span>Local: {props.local}</span>
      <br />
      <span>Data: {props.data}</span>
    </div>
  );
}
