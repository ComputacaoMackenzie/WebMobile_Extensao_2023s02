export default function StatsBar(props) {
  return (
    <>
      <div className="statsBar">
        <div
          style={{
            backgroundColor: "lightgreen",
            width: props.greenPercentage + "%",
            borderRadius: "20px 0px 0px 20px",
          }}
        ></div>

        <div
          style={{
            backgroundColor: "red",
            width: props.redPercentage + "%",
            borderRadius: "0px 20px 20px 0px",
          }}
        ></div>
      </div>
      <span>
        {props.kind}: {props.type} ({props.typeValue}) / {props.reverse} (
        {props.reverseValue})
      </span>
    </>
  );
}
