import "./chegar.css";
import "./mapquest.css";
import "./mapquest.js";
import { Map, ImageOverlay } from "react-leaflet";

const MapQuest = () => {
  const mapQuestKey = "HQIFoidr4dCo2bwUIeJNdRt7MyNDlIrR";
  const latitude = -23.547203;
  const longitude = -46.651631;
  return (
    <Map
      center={[latitude, longitude]}
      zoom={14}
      minZoom={14}
      maxZoom={14}
      zoomControl={false}
      style={{ width: "1100px", height: "700px", margin: "50px", zIndex: 0 }}
    >
      <ImageOverlay
        url={`https://www.mapquestapi.com/staticmap/v5/map?key=${mapQuestKey}&locations=${latitude},${longitude}|marker-sm-red|&center=${latitude},${longitude}&zoom=14&size=800,700@2x`}
        bounds={[
          [latitude - 0.05, longitude - 0.05],
          [latitude + 0.05, longitude + 0.05],
        ]}
      />
    </Map>
  );
};

export default MapQuest;
