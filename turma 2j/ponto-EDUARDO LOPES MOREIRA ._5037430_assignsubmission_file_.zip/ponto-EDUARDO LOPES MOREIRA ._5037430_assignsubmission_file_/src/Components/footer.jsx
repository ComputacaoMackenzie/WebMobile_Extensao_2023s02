import "./footer.css";
import logo from "./mackenzie_logo.svg";

export default function Footer() {
  return (
    <div className="footer">
      <div className="ft-logo">
        <img src={logo} alt="footer-logo" className="logo" />
        <p style={{ marginLeft: "30px" }}>#Mackenzie1870</p>
        <p style={{ marginLeft: "30px" }}>support@mackenzie.br</p>
      </div>
      <div className="ft-2">
        <h1 style={{ width: "100%" }}>Institucional</h1>
        <div className="inst-content">
          <p>O Instituto</p>
          <p>Universidade</p>
          <p>Colégios</p>
        </div>
        <div className="inst-content">
          <p>Chancelaria</p>
          <p>Andrew Jumper(CPAJ)</p>
          <p>Lift Media</p>
        </div>
      </div>
      <div>
        <h1>Newsletter</h1>
        <div className="input-container">
          <input type={Text} />
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            fill="currentColor"
            class="bi bi-arrow-right-short"
            viewBox="0 0 16 16"
            className="arrow"
          >
            <path
              fill-rule="evenodd"
              d="M4 8a.5.5 0 0 1 .5-.5h5.793L8.146 5.354a.5.5 0 1 1 .708-.708l3 3a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708-.708L10.293 8.5H4.5A.5.5 0 0 1 4 8"
            />
          </svg>
        </div>
      </div>
    </div>
  );
}
