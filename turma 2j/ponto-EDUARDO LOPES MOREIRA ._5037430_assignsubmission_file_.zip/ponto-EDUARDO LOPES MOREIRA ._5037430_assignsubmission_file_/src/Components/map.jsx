import map from "./MapaMack_ProjetoWebrec.png";

export default function Map() {
  return (
    <div>
      <img src={map} style={{ height: "800px" }} />
    </div>
  );
}
