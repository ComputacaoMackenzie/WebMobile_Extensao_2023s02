import "./copyright.css"

export default function Copyright() {
    return (
        <div className="copyright">
            &#169; 2023 all rights reserved
        </div>
    )
}