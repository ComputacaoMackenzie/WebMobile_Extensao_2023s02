import "./predios.css";

export default function Predios() {
  return (
    <div className="predios">
      <p class="texto-predios">
        1 Centro Histórico – Ed. John Theron Mackenzie <br />
        2 Biblioteca Central – Ed. George Alexander
        <br />
        3 Direito – Ed. Horace Manley Lane
        <br />
        4 Engenharia – Ed. Alfred Cownley Slater
        <br />
        5 Engenharia – Ed. William Alfred Waddel
        <br />
        6 Engenharia – Ed. Henrique Pegado
        <br />
        7 Diretórios / Gráfica Central
        <br />
        9 Arquitetura & Design – Ed. Cristiano Stockler das Neves
        <br />
        10 Laboratórios de Informática – Ed. Rev. George Whitehill Chamberlain
        <br />
        11 Capela – Ed. José Manuel da Conceição
        <br />
        12 Central de Atendimento / Informações / Ouvidoria
        <br />
        13 Matrícula - Trancamentos e Cancelamentos
        <br />
        14 Secretaria Geral
        <br />
        15 AFA - Atendimento Financeiro ao Aluno
        <br />
        16 Acerto Financeiro – Ed. Márcia P. Brown
        <br />
        17 Colégio Presbiteriano Mackenzie - Direção Educação Básica
        <br />
        18 Colégio Presbiteriano Mackenzie - Ensino Fundamental II
        <br />
        Ed. Erasmo Carvalho Braga
        <br />
        19 Auditório Ruy Barbosa / Praça de Convivência / Ensino Médio / CLEM
        <br />
        Ed. Ashbel Green Simonton
        <br />
        20 Ginásio de Esportes – Ed. Edward Horatio Weedenv
        <br />
        23 Enfermaria / Manutenção
        <br />
        24 Escola de Engenharia / Faculdade de Direito
        <br />
        Ed. Benjamin Harris Hunnicutt
        <br />
        25 CEFT - Centro de Educação, Filosofia e Teologia
        <br />
        Ed. Esther de Figueiredo Ferraz
        <br />
        28 Laboratórios CCBS, CCL e Escola de Engenharia
        <br />
        29 Quadras Cobertas
        <br />
        30 Laboratórios Escola de Engenharia – Ed. Paulo Costa Lenz César
        <br />
        31 Faculdade de Computação e Informática – Ed. Paulo Breda Filho
        <br />
        33 Laboratórios de Informática / Laboratórios Escola de Engenharia
        <br />
        Ed. Rev. Mattathias Gomes dos Santos
        <br />
        34 Biotério Animal
        <br />
        35 Almoxarifado / Serviço de Apoio / Manutenção
        <br />
        37 Laboratório Escola de Engenharia
        <br />
        38 Laboratórios CCBS / Cozinha Experimental
        <br />
        Ed. Rev. Amantino Adorno Vassão
        <br />
        39 Graduação / Pós-Graduação – Ed. Baronesa Maria Antônia da Silva Ramos
        <br />
        40 Salas de Aula / Laboratório de Gravura – Ed. Antônio Bandeira Trajano
        <br />
        41 Pós-Graduação e Administração Geral – Ed. João Calvino
        <br />
        43 Marcenaria
        <br />
        44 Colégio Presbiteriano Mackenzie - Educação Infantil / Ensino
        Fundamental I<br />
        Ed. Mary Annesley Chamberlain
        <br />
        45 Centro de Ciências Sociais e Aplicadas – Ed. Rev. Modesto Carvalhosa
        <br />
        46 Colégio Presbiteriano Mackenzie - Educação Infantil / Ensino
        Fundamental I<br />
        Ed. Mary Annesley Chamberlain
        <br />
        48 CCL / Colégio P. Mackenzie - Ed. Básica / Coord. de Arte e Cultura
        <br />
        Ed. Clara Schurig e Ed. José Carlos Rodrigues
        <br />
        49 CCL - Centro de Comunicação e Letras
        <br />
        50 CCBS - Centro de Ciências Biológicas e da Saúde
        <br />
        52 Quadras
        <br />
      </p>
    </div>
  );
}
