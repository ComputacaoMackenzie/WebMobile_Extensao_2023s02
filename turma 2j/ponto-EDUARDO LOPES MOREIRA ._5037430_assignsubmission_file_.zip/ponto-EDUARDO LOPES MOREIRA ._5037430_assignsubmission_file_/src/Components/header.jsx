import "./header.css";
import menuBar from "./menu_white_36dp.svg";
import close from "./close_white_36dp.svg";
import logo from "./mackenzie_logo.svg";
import help from "./helpicon.png";
import { useState } from "react";

export default function Header(props) {
  const [menu, setMenu] = useState(true);
  const [menuImg, setMenuImg] = useState(menuBar);

  const handleMenu = () => {
    setMenu(!menu);
    if (menu) {
      setMenuImg(menuBar);
    } else {
      setMenuImg(close);
    }
    console.log("aaaaaaaaaa");
  };

  return (
    <div className="header">
      <nav role="navigation" style={{ marginTop: "-90px" }}>
        <div id="menuToggle">
          <input type="checkbox" />
          <span></span>
          <span></span>
          <span></span>
          <ul id="menu">
            <a onClick={props.predios}>
              <li>Prédios</li>
            </a>
            <a onClick={props.portarias}>
              <li>Portarias</li>
            </a>
            <a onClick={props.chegar}>
              <li>Como Chegar?</li>
            </a>
          </ul>
        </div>
      </nav>
      <img src={logo} alt="logo" className="logo" onClick={props.mapa} />
      <a href="https://www.google.com.br/maps/place/Instituto+Presbiteriano+Mackenzie/@-23.547309,-46.6552162,17z/data=!4m6!3m5!1s0x94ce58496d81ffdb:0x79a780a24440ffc1!8m2!3d-23.5470757!4d-46.6481226!16s%2Fg%2F1pp2wx028?entry=ttu">
        Como chegar
        <img src={help} alt="help icon" className="help-icon" />
      </a>
    </div>
  );
}
