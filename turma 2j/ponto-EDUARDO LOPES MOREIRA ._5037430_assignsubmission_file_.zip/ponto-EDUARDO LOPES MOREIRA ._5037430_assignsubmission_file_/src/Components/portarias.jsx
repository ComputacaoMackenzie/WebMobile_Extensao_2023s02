import "./portarias.css";

export default function Portarias() {
  return (
    <div className="portarias">
      <p>
        Portaria 01 - Rua Itambé <br />
        Portaria 02 - Rua Itambé <br />
        Portaria 03 - Rua Maria Antônia <br />
        Portaria 04 - Rua Itambé <br />
        Portaria 05 - Rua Piauí <br />
        Portaria 06 - Rua Piauí <br />
        Portaria 07 - Rua da Consolação <br />
      </p>
    </div>
  );
}
