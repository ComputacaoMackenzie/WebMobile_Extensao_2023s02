import "./styles.css";
import "./reset.css";
import Header from "./Components/header.jsx";
import Map from "./Components/map.jsx";
import Footer from "./Components/footer.jsx";
import Copyright from "./Components/cpyright.jsx";
import Predios from "./Components/predios.jsx";
import Portarias from "./Components/portarias.jsx";
import Chegar from "./Components/chegar.jsx";
import { useState } from "react";

export default function App() {
  const [content, setContent] = useState(1);

  const mapa = () => {
    setContent(1);
    console.log("Mapa");
  };

  const predios = () => {
    setContent(2);
    console.log("Predios");
  };
  const portarias = () => {
    setContent(3);
    console.log("Portaria");
  };
  const chegar = () => {
    setContent(4);
    console.log("quest");
  };

  if (content == 1) {
    return (
      <div className="App">
        <Header
          mapa={mapa}
          predios={predios}
          portarias={portarias}
          chegar={chegar}
        />
        <Map />
        <Footer />
        <Copyright />
      </div>
    );
  } else if (content == 2) {
    return (
      <div className="App">
        <Header
          mapa={mapa}
          predios={predios}
          portarias={portarias}
          chegar={chegar}
        />
        <Predios />
        <Footer />
        <Copyright />
      </div>
    );
  } else if (content == 3) {
    return (
      <div className="App">
        <Header
          mapa={mapa}
          predios={predios}
          portarias={portarias}
          chegar={chegar}
        />
        <Portarias />
        <Footer />
        <Copyright />
      </div>
    );
  } else {
    return (
      <div className="App">
        <Header
          mapa={mapa}
          predios={predios}
          portarias={portarias}
          chegar={chegar}
        />
        <Chegar />
        <Footer />
        <Copyright />
      </div>
    );
  }
}
