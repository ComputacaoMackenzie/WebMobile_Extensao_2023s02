import { createMiddlewareClient } from '@supabase/auth-helpers-nextjs';
import { NextRequest, NextResponse } from 'next/server';

export async function middleware(
  request: NextRequest
): Promise<NextResponse<unknown>> {
  const response = NextResponse.next();

  const supabase = createMiddlewareClient({ req: request, res: response });

  const session = await supabase.auth.getSession();

  if (!session.data.session) {
    return NextResponse.redirect(new URL('/', request.url));
  }

  return response;
}

export const config = {
  matcher: ['/student/:path*'],
};
