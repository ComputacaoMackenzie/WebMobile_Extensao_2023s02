import { getSupabaseServerClient } from '@/app/clients/get-supabase-server-client';
import { StudyGroupCard } from '@/app/components/study-group-card';
import { formatClassnames } from '@/app/helpers/format-classnames';
import { getUserSession } from '@/app/helpers/get-server-user';
import { NewGroupForm } from '@/app/student/groups/components/form';
import { JoinedGroups } from '@/app/student/groups/components/joined-groups';
import styles from './groups.module.css';

export default async function Groups(): Promise<JSX.Element> {
  const supabaseClient = getSupabaseServerClient();
  const user = await getUserSession();

  const userGroupsData = await supabaseClient
    .from('user_study_group')
    .select('user_id, study_group(*)')
    .eq('user_id', user.userSession?.id);

  const userGroups = userGroupsData.data ?? [];

  const joinedGroupsData = await supabaseClient
    .from('study_group_user')
    .select('user_id, study_group(*)')
    .eq('user_id', user.userSession.id);

  return (
    <main className={styles.mainContainer}>
      <div className={styles.sectionWrapper}>
        <section className={styles.groupSection}>
          <h1>Crie seu grupo</h1>
          <NewGroupForm />
        </section>
        <section className={styles.groupSection}>
          <h1>Grupos ingressados</h1>
          <ul className={styles.joinedGroupList}>
            <JoinedGroups groups={joinedGroupsData.data} />
          </ul>
        </section>
      </div>

      <section
        className={formatClassnames(
          styles.groupSection,
          styles.userGroupsSection
        )}
      >
        <h1>Seus grupos</h1>
        <ul className={styles.userStudyGroups}>
          {userGroups.length === 0 && (
            <li>Você ainda não criou nenhum grupo.</li>
          )}
          {userGroups.map(({ study_group: studyGroup }) => (
            <StudyGroupCard
              id={studyGroup.id}
              image={studyGroup?.image}
              className={styles.userStudyGroup}
              name={studyGroup.name}
              weekdays={studyGroup.weekdays as string[]}
              key={studyGroup.id}
              mode="editing"
              isAlreadyJoined={false}
            />
          ))}
        </ul>
      </section>
    </main>
  );
}
