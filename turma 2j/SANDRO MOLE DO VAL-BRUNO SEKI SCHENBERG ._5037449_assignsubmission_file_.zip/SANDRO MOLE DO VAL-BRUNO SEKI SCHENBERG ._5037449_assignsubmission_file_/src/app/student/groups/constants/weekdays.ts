export const Weekdays = [
  {
    label: 'seg',
  },
  {
    label: 'ter',
  },
  {
    label: 'qua',
  },
  {
    label: 'qui',
  },
  {
    label: 'sex',
  },
];
