'use client';

import { leaveStudyGroup } from '@/app/actions/leave-study-group';
import { ActionButton } from '@/app/components/action-button';
import { FaSignOutAlt } from 'react-icons/fa';
import { FaFaceFrownOpen } from 'react-icons/fa6';
import styles from './joined-groups.module.css';

export function JoinedGroups(props: JoinedGroupsProps): JSX.Element {
  return (
    <ul className={styles.joinedGroupList}>
      {props.groups.map((joinedGroup) => (
        <li key={joinedGroup.study_group.id} className={styles.joinedGroupItem}>
          <p>{joinedGroup.study_group.name}</p>
          <ActionButton
            onClick={() => leaveStudyGroup(joinedGroup.study_group.id)}
            Icon={FaSignOutAlt}
          />
        </li>
      ))}

      {props.groups.length === 0 && (
        <li className={styles.emptyItem}>
          <FaFaceFrownOpen />
          <p>Você não se juntou há nenhum grupo</p>
        </li>
      )}
    </ul>
  );
}

export type JoinedGroupsProps = {
  groups: Array<{ study_group: { id: string; name: string } }>;
};
