'use client';

import styles from './weekday-checkbox.module.css';

interface WeekdayCheckboxProps {
  id: string;
  name: string;
  label: string;
  color: string;
  value: string;
}

export function WeekdayCheckbox(props: WeekdayCheckboxProps): JSX.Element {
  return (
    <div className={styles.weekdayCheckboxContainer}>
      <input
        type="checkbox"
        className={styles.weekdayCheckboxInput}
        value={props.value}
        id={props.id}
        name={props.name}
      />
      <label
        htmlFor={props.id}
        className={styles.weekdayCheckboxLabel}
        style={{ backgroundColor: props.color }}
      >
        {props.label}
      </label>
    </div>
  );
}
