import { createStudyGroup } from '@/app/actions/create-study-group';
import { blendPrimaryColors } from '@/app/helpers/blend-primary-colors';
import { WeekdayCheckbox } from '@/app/student/groups/components/weekday-checkbox';
import { Weekdays } from '@/app/student/groups/constants/weekdays';
import styles from './form.module.css';

export function NewGroupForm(): JSX.Element {
  return (
    <form className={styles.newGroupForm} action={createStudyGroup}>
      <input
        placeholder="Nome do grupo"
        type="text"
        name="groupName"
        className={styles.studeeInput}
      />
      <input
        placeholder="Link da imagem"
        type="text"
        name="groupImage"
        className={styles.studeeInput}
      />

      <div className={styles.weekdaysContainer}>
        {Weekdays.map((weekday, index) => {
          const color = blendPrimaryColors(index / 4);

          return (
            <WeekdayCheckbox
              id={weekday.label}
              label={weekday.label}
              value={weekday.label}
              key={weekday.label}
              color={color}
              name="groupWeekdays"
            />
          );
        })}
      </div>

      <button type="submit" className={styles.studeeButton}>
        Criar
      </button>
    </form>
  );
}
