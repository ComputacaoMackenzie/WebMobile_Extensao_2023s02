import { getSupabaseServerClient } from '@/app/clients/get-supabase-server-client';
import { StudyGroupCard } from '@/app/components/study-group-card';
import { getUserSession } from '@/app/helpers/get-server-user';
import style from './home.module.css';

export default async function Home(): Promise<JSX.Element> {
  const supabase = getSupabaseServerClient();

  const { userSession } = await getUserSession();
  const { data: studyGroups } = await supabase
    .from('study_group')
    .select('*, study_group_user!left(user_id)')
    .eq('study_group_user.user_id', userSession.id);

  return (
    <main className={style.mainContainer}>
      <ul className={style.studyGroupList}>
        {studyGroups?.map((studyGroup, index) => (
          <StudyGroupCard
            key={studyGroup.id}
            id={studyGroup.id}
            name={studyGroup.name}
            image={`${studyGroup.image}?random=${index}`}
            weekdays={studyGroup.weekdays as string[]}
            isAlreadyJoined={studyGroup.study_group_user.length > 0}
            className={style.homeStudyGroup}
          />
        ))}
      </ul>
    </main>
  );
}
