export function formatClassnames(...classNames: string[]): string {
  return classNames.join(' ');
}
