import { getSupabaseClient } from '@/app/clients/get-supabase-client';
import { UserSession } from '@/app/protocols/user-data';

export async function getClientUser(): Promise<UserSession> {
  const { auth } = getSupabaseClient();

  const { data } = await auth.getUser();

  if (data.user === null) {
    return {
      isLogged: false,
      userSession: null,
    };
  }

  const {
    user: { id, user_metadata },
  } = data;

  return {
    isLogged: true,
    userSession: {
      id,
      email: user_metadata.email,
      image: user_metadata.picture,
      name: user_metadata.name,
    },
  };
}
