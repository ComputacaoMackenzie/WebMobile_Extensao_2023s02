export function blendColor(
  colorA: number[],
  colorB: number[],
  factor: number
): string {
  const [redA, greenA, blueA] = colorA;
  const [redB, greenB, blueB] = colorB;

  const redLerp = lerp(redA, redB, factor);
  const greenLerp = lerp(greenA, greenB, factor);
  const blueLerp = lerp(blueA, blueB, factor);

  return `rgb(${redLerp}, ${greenLerp}, ${blueLerp})`;
}

function lerp(valueA: number, valueB: number, factor: number) {
  return valueA + (valueB - valueA) * factor;
}
