import { getSupabaseServerClient } from '@/app/clients/get-supabase-server-client';
import { UserSession } from '@/app/protocols/user-data';

export async function getUserSession(): Promise<UserSession> {
  const supabaseClient = getSupabaseServerClient();

  const { data } = await supabaseClient.auth.getUser();
  const { user } = data;
  const isLogged = user !== null;

  if (!isLogged) {
    return {
      userSession: null,
      isLogged: false,
    };
  }

  const { id, user_metadata: userMetadata } = user;

  const userSession = {
    id,
    name: userMetadata.name,
    email: userMetadata.email,
    image: userMetadata.picture,
  };

  return {
    userSession: userSession,
    isLogged: isLogged,
  };
}
