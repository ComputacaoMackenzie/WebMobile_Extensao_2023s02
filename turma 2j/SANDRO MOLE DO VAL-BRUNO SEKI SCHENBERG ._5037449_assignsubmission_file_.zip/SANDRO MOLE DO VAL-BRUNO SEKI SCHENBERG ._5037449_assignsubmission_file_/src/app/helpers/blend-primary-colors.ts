import { blendColor } from '@/app/helpers/blend-colors';

export function blendPrimaryColors(factor: number): string {
  const primaryColorRgb = [231, 29, 54];
  const secondaryColorRgb = [26, 29, 116];

  return blendColor(primaryColorRgb, secondaryColorRgb, factor);
}
