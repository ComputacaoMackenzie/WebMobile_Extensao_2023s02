export type UserSession = {
  userSession: UserPayload | null;
  isLogged: boolean;
};

export type UserPayload = {
  id: string;
  name: string;
  email: string;
  image: string;
};
