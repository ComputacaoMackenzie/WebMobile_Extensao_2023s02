import { Database } from '@/app/protocols/database.types';
import {
  SupabaseClient,
  createServerComponentClient,
} from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

export function getSupabaseServerClient(): SupabaseClient<Database> {
  return createServerComponentClient({ cookies });
}
