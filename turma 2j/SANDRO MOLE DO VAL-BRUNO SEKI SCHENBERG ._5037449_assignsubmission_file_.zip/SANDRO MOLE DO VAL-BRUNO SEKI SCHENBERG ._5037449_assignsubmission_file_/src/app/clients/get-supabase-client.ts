import { Database } from '@/app/protocols/database.types';
import {
  SupabaseClient,
  createClientComponentClient,
} from '@supabase/auth-helpers-nextjs';

export function getSupabaseClient(): SupabaseClient<Database> {
  const supabaseClient = createClientComponentClient();
  return supabaseClient;
}
