'use server';

import { getSupabaseServerClient } from '@/app/clients/get-supabase-server-client';
import { getUserSession } from '@/app/helpers/get-server-user';
import { revalidatePath } from 'next/cache';

export async function removeStudyGroup(id: string): Promise<void> {
  const supabaseClient = getSupabaseServerClient();
  const { userSession } = await getUserSession();

  const userStudyGroup = await supabaseClient
    .from('user_study_group')
    .select()
    .eq('user_id', userSession.id)
    .eq('study_group_id', id);

  await supabaseClient
    .from('study_group')
    .delete()
    .eq('id', userStudyGroup.data[0].study_group_id);

  revalidatePath('/student/groups');
}
