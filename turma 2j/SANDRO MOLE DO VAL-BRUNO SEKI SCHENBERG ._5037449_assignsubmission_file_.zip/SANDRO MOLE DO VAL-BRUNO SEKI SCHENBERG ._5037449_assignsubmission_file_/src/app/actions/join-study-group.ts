'use server';

import { getSupabaseServerClient } from '@/app/clients/get-supabase-server-client';
import { getUserSession } from '@/app/helpers/get-server-user';
import { revalidatePath } from 'next/cache';

export async function joinStudyGroup(studyGroupId: string): Promise<void> {
  const { userSession } = await getUserSession();
  const supabaseClient = getSupabaseServerClient();

  await supabaseClient
    .from('study_group_user')
    .insert({ user_id: userSession.id, study_group_id: studyGroupId });

  revalidatePath('/student/home');
}
