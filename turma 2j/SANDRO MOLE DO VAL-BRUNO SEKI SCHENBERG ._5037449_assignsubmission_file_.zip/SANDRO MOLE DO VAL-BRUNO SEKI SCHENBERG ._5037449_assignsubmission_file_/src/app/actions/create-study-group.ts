'use server';

import { getSupabaseServerClient } from '@/app/clients/get-supabase-server-client';
import { User } from '@supabase/supabase-js';
import { revalidatePath } from 'next/cache';

export async function createStudyGroup(
  formData: FormData
): Promise<ActionResponse> {
  const groupPayload = {
    name: formData.get('groupName')?.toString() as string,
    image: formData.get('groupImage')?.toString() as string,
    weekdays: formData.getAll('groupWeekdays') as string[],
  };
  const supabaseClient = getSupabaseServerClient();

  const { data: userData } = await supabaseClient.auth.getUser();

  const user = userData.user as User;

  const insertedGroup = await supabaseClient
    .from('study_group')
    .insert(groupPayload)
    .select();

  if (!insertedGroup.data) return { message: 'Could not insert data' };

  await supabaseClient.from('user_study_group').insert({
    study_group_id: insertedGroup.data[0].id,
    user_id: user.id,
  });

  revalidatePath('/student/groups');
  return { message: 'Created' };
}

type ActionResponse = {
  message: string;
};
