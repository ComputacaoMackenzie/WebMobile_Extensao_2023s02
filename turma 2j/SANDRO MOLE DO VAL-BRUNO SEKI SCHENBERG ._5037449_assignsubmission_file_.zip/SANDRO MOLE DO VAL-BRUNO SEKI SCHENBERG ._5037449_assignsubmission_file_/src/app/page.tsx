import Image from 'next/image';
import style from './welcome.module.css';
import { formatClassnames } from '@/app/helpers/format-classnames';
import { getUserSession } from '@/app/helpers/get-server-user';
import { redirect } from 'next/navigation';

export default async function Welcome(): Promise<JSX.Element> {
  const { isLogged } = await getUserSession();

  if (isLogged) {
    redirect('/student/home');
  }

  return (
    <main className={style.mainContainer}>
      <div className={style.waveBackground} />

      <section
        className={formatClassnames(
          style.mackStudeeInfoSection,
          style.textSection
        )}
      >
        <h2 className={style.mackStudeeSectionHeader}>
          Encontre, estude e aprenda.
        </h2>
        <p className={style.mackStudeeSectionText}>
          Busque por grupos de estudos de seu interesse e aprenda com que ama
          estudar! A plataforma oferece inúmeras formas dos alunos se conectarem
          para garantia da união e aprendizagem de todos.
        </p>
      </section>

      <section
        className={formatClassnames(
          style.mackStudeeInfoSection,
          style.thumbnailSection
        )}
      >
        <Image
          src="/students.svg"
          alt="Estudantes conversando"
          className={style.mackStudeeThumbnail}
          width={900}
          height={700}
          priority
        />
      </section>
    </main>
  );
}
