'use client';

import { joinStudyGroup } from '@/app/actions/join-study-group';
import { removeStudyGroup } from '@/app/actions/remove-study-group';
import { ActionButton } from '@/app/components/action-button';
import { blendPrimaryColors } from '@/app/helpers/blend-primary-colors';
import { formatClassnames } from '@/app/helpers/format-classnames';
import { FaSignInAlt, FaStar, FaTimes } from 'react-icons/fa';
import style from './study-group-card.module.css';

export async function StudyGroupCard({
  mode = 'view',
  ...props
}: StudyGroupCardProps): Promise<JSX.Element> {
  return (
    <li className={formatClassnames(style.studyGroupCard, props.className)}>
      <div
        style={{ backgroundImage: `url(${props.image})` }}
        className={style.studyGroupCardImage}
      />
      <div className={style.studyGroupCardContent}>
        <div className={style.studyGroupCardInfo}>
          <p className={style.studyGroupCardName}>{props.name}</p>

          {mode === 'view' && (
            <div className={style.studyGroupUserActions}>
              <ActionButton Icon={FaStar} />
            </div>
          )}
        </div>
        <section className={style.studyGroupInfoWrapper}>
          <div className={style.studyGroupCardWeekdays}>
            {props.weekdays.map((weekday, index) => {
              const currentFactor = index / 4;
              const backgroundColor = blendPrimaryColors(currentFactor);
              return (
                <span
                  key={weekday}
                  className={style.studyGroupCardWeekday}
                  style={{
                    backgroundColor,
                  }}
                >
                  {weekday}
                </span>
              );
            })}
          </div>
          {!props.isAlreadyJoined && mode !== 'editing' && (
            <ActionButton
              className={style.studyGroupActionButton}
              onClick={() => joinStudyGroup(props.id)}
              Icon={FaSignInAlt}
            />
          )}
        </section>
      </div>
      {mode === 'editing' && (
        <div className={style.actionContainer}>
          <button
            className={style.excludeGroupBtn}
            onClick={() => {
              removeStudyGroup(props.id);
            }}
          >
            <FaTimes />
          </button>
        </div>
      )}
    </li>
  );
}

type StudyGroupCardProps = {
  id: string;
  name: string;
  image: string;
  weekdays: string[];
  className: string;
  isAlreadyJoined: boolean;
  mode?: 'editing' | 'view';
  onRemoveClick?: () => Promise<void>;
};
