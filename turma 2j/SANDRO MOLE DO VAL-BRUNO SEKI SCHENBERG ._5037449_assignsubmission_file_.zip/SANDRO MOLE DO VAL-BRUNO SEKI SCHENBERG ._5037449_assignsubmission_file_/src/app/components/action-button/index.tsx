'use client';

import { ButtonHTMLAttributes, DetailedHTMLProps } from 'react';
import styles from './action-button.module.css';

export function ActionButton({
  Icon,
  ...props
}: ActionButtonProps): JSX.Element {
  return (
    <button className={styles.actionButton} {...props}>
      <Icon />
    </button>
  );
}

type ActionButtonProps = DetailedHTMLProps<
  ButtonHTMLAttributes<HTMLButtonElement>,
  HTMLButtonElement
> & {
  Icon: () => JSX.Element;
};
