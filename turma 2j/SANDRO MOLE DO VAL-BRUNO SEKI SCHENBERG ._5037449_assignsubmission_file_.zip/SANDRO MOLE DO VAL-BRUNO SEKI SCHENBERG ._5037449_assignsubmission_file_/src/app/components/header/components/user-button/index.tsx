'use client';

import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { BiExit } from 'react-icons/bi';

import { getSupabaseClient } from '@/app/clients/get-supabase-client';
import { formatClassnames } from '@/app/helpers/format-classnames';
import { UserPayload } from '@/app/protocols/user-data';

import styles from './user-button.module.css';

export function UserButton(props: UserButtonProps): JSX.Element {
  const { isLogged, userSession } = props;
  const { auth } = getSupabaseClient();
  const router = useRouter();

  async function handleSignIn(): Promise<void> {
    await auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${location.origin}/auth/callback` },
    });
  }

  async function handleSignOut(): Promise<void> {
    await auth.signOut({ scope: 'global' });
    router.push('/');
    router.refresh();
  }

  return (
    <div className={styles.userButtonContainer}>
      {!isLogged ? (
        <button
          className={formatClassnames(
            'button',
            'primaryButton',
            styles.userSigninButton
          )}
          onClick={() => handleSignIn()}
        >
          Login
        </button>
      ) : (
        <section className={styles.userContainer}>
          <div className={styles.userContainerWrapper}>
            <Image
              src={userSession?.image as string}
              alt={userSession?.name as string}
              className={styles.userImage}
              width={50}
              height={50}
            />
            <p className={styles.userMessage}>Olá, {userSession?.name}!</p>
          </div>
          <button
            className={styles.userLogoutButton}
            onClick={() => handleSignOut()}
          >
            <BiExit />
          </button>
        </section>
      )}
    </div>
  );
}

type UserButtonProps = {
  userSession: UserPayload;
  isLogged: boolean;
};
