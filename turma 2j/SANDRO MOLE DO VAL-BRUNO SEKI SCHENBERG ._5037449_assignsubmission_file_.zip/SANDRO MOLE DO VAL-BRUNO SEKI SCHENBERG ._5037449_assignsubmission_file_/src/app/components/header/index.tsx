import Link from 'next/link';
import { HiAcademicCap } from 'react-icons/hi';
import { FiBookOpen, FiHome } from 'react-icons/fi';
import { UserButton } from '@/app/components/header/components/user-button';
import style from './header.module.css';
import { getUserSession } from '@/app/helpers/get-server-user';
import { UserPayload } from '@/app/protocols/user-data';

const navItems = [
  {
    Icon: FiHome,
    description: 'Home',
    href: '/student/home',
  },
  {
    Icon: FiBookOpen,
    description: 'Meus grupos',
    href: '/student/groups',
  },
];

export async function Header(): Promise<JSX.Element> {
  const { isLogged, userSession } = await getUserSession();

  return (
    <header className={style.mackStudeeHeader}>
      <section className={style.mackStudeeLogoContainer}>
        <div className={style.mackStudeeLogo}>
          <HiAcademicCap className={style.mackStudeeLogoIcon} />
        </div>
        <h1 className={style.mackStudeeTitle}>Mack Studee</h1>
      </section>
      {isLogged && (
        <section>
          <nav className={style.mackStudeeNav}>
            <ul>
              {navItems.map((navItem) => (
                <li key={navItem.href} className={style.mackStudeeNavItem}>
                  <Link href={navItem.href}>
                    <navItem.Icon />
                  </Link>
                  <span>{navItem.description}</span>
                </li>
              ))}
            </ul>
          </nav>
        </section>
      )}
      <UserButton
        isLogged={isLogged}
        userSession={userSession as UserPayload}
      />
    </header>
  );
}

export type UserGoogleMetadata = {
  name: string;
  image: string;
  email: string;
};
