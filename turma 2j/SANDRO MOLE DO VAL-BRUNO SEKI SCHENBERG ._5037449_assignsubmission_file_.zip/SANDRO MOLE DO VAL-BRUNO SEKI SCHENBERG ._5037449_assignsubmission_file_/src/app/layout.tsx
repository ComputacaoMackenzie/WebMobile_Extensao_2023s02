import './styles/globals.css';
import './styles/button.css';

import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { Nunito } from 'next/font/google';
import { Header } from '@/app/components/header';

export const inter = Inter({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-inter',
});
export const nunito = Nunito({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-nunito',
});

export const metadata: Metadata = {
  title: 'Mack Studee',
  description: 'Forme grupos de estudo e encontre pessoas!',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ptBR">
      <body className={`${nunito.variable} ${inter.variable}`}>
        <Header />
        {children}
      </body>
    </html>
  );
}
