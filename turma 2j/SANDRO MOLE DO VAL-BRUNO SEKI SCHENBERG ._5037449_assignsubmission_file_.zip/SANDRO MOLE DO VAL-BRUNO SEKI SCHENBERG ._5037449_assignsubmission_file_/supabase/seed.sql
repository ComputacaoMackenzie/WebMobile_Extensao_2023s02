INSERT INTO study_group (name, image, weekdays) VALUES ('Web Mobile', 'https://picsum.photos/500/300', '["seg"]');
INSERT INTO study_group (name, image, weekdays) VALUES ('Banco de dados', 'https://picsum.photos/500/300', '["seg", "ter"]');
INSERT INTO study_group (name, image, weekdays) VALUES ('Compiladores', 'https://picsum.photos/500/300', '["seg", "ter", "qua"]');
INSERT INTO study_group (name, image, weekdays) VALUES ('Teoria da computação', 'https://picsum.photos/500/300', '["seg", "ter", "qua", "qui"]');
INSERT INTO study_group (name, image, weekdays) VALUES ('Computação visual', 'https://picsum.photos/500/300', '["seg", "ter", "qua", "qui", "sex"]');