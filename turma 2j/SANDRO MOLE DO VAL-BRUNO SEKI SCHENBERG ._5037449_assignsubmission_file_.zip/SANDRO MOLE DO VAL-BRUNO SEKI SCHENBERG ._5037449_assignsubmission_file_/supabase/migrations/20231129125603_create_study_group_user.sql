CREATE TABLE study_group_user (
    user_id UUID not null,
    study_group_id UUID not null,
    constraint fk_user foreign key (user_id) references auth.users(id),
    constraint fk_study_group foreign key (study_group_id) references study_group(id)
)