CREATE TABLE user_study_group (
  user_id uuid not null,
  study_group_id uuid not null,
  CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES auth.users(id),
  CONSTRAINT fk_study_group FOREIGN KEY (study_group_id) REFERENCES study_group(id) ON DELETE CASCADE
)