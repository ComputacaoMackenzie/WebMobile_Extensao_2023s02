"use client";

/*
Carlos Manoel Pedrosa de Oliveira 
TIA: 32068549

Caio Eduardo Todesco Gomes
TIA: 31966527

Gabriel Kazuiti Aiura
TIA: 32047231
*/

import CardEvento from "./components/CardEvento/CardEvento";
import Header from "./components/Header/Header";
import { useState } from "react";
import listaEventos from "./mock/listaEventos";

export default function Home() {
  const [filtro, setFiltro] = useState("Todos");
  const [searchValue, setSearchValue] = useState("");

  const filtrarEventos = (tag) => {
    setFiltro(tag);
  };

  const eventosFiltradosByTag =
    filtro === "Todos"
      ? listaEventos
      : listaEventos.filter((evento) => evento.tag === filtro);

  const eventosFiltrados =
    searchValue === ""
      ? eventosFiltradosByTag
      : eventosFiltradosByTag.filter((evento) =>
          evento.name.toLowerCase().includes(searchValue.toLowerCase()),
        );
  return (
    <body>
      <Header
        filtro={filtro}
        onFiltroClick={filtrarEventos}
        search={(value) => {
          setSearchValue(value);
        }}
      />
      <main className="lista-eventos">
        {eventosFiltrados.map((evento, index) => {
          return <>{evento.tag && <CardEvento key={index} {...evento} />}</>;
        })}
      </main>
    </body>
  );
}
