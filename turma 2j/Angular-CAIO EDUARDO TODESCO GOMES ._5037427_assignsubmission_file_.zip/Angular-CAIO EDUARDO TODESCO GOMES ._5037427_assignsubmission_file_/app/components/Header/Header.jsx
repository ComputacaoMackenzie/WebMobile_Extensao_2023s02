import "./Header.css";
import ButtonTags from "../ButtonTags/ButtonTags";
import { useState } from "react";

export default function Header({ filtro, onFiltroClick, search }) {
  const [searchValue, setSearchValue] = useState("");
  const buttonList = [
    "Atleticas",
    "Eventos Presenciais",
    "Formaturas",
    "Palestras",
  ];

  const handleSearchBar = (event) => {
    const searchItem = event.target.value;
    setSearchValue(searchItem);
    search(searchItem);
  };

  return (
    <>
      <header>
        <img src="logo-mack-eventos.png" alt="MackEventos" />
      </header>
      <section className="aba-filtros">
        {buttonList.map((button) => {
          return (
            <ButtonTags
              label={button}
              onFiltroClick={onFiltroClick}
              currentFilter={filtro}
            />
          );
        })}
        <input
          className="area-pesquisa"
          type="text"
          placeholder="Pesquise aqui"
          onChange={handleSearchBar}
        />
      </section>
    </>
  );
}
