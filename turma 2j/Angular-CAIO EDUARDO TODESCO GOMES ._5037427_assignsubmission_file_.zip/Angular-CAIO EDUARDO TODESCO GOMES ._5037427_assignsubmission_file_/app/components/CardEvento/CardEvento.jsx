import Link from "next/link";
import "./CardEvento.css";

export default function CardEvento({ image, name, tag, date, location, id }) {
  return (
    <div className="card-evento">
      <img src={image} />
      <div className="info-evento">
        <h2>{name}</h2>
        <span>{tag}</span>
        <p className="description-event">{date}</p>
        <p className="description-event">{location}</p>
        <Link href={`/evento?id=${id}`}>
          <button id="more-info-button">mais informações</button>
        </Link>
      </div>
    </div>
  );
}
