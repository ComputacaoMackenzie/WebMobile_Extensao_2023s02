import "./ButtonTags.css";
import { useState } from "react";

export default function ButtonTags({ label, onFiltroClick, currentFilter }) {
  const [isButtonSelect, setIsButtonSelected] = useState("Todos");

  const handleClickButton = (tag) => {
    const filter =
      tag == isButtonSelect && isButtonSelect == currentFilter ? "Todos" : tag;
    onFiltroClick(filter);
    setIsButtonSelected(filter);
  };
  return (
    <button
      className={
        isButtonSelect == label && isButtonSelect == currentFilter
          ? "button-selected"
          : "filtros"
      }
      onClick={() => handleClickButton(label)}
    >
      {label}
    </button>
  );
}
