const listaEventos = [
  {
    id: 0,
    name: "Pancadão do Mack",
    tag: "Atleticas",
    date: "06/09/2023",
    location: "Rosas de Ouro",
    image: "/eventos/pancadao-mack.png",
    organizers: "Atléticas do Mackenzie",
    contact: {
      instagram: "https://www.instagram.com/pancadaodomack/",
      whatsapp: "5511949060876",
      blacktag:
        "https://blacktag.com.br/eventos/15212/pancadao-do-mack?aff=Bio",
    },
  },
  {
    id: 1,
    name: "Mackejada",
    tag: "Atleticas",
    date: "24/11/2023",
    location: "Império de Casa Verde",
    image: "/eventos/mackejada.PNG",
    organizers: "Atléticas do Mackenzie",
    contact: {
      instagram: "https://www.instagram.com/mackejada/",
      whatsapp: "5511949060876",
      blacktag: "https://blacktag.com.br/eventos/17051/mackejada-saideira",
    },
  },
  {
    id: 2,
    name: "Semana da Tecnologia e Informação",
    tag: "Palestras",
    date: "02/10/2023 - 04/10/2023",
    location: "Mackenzie - Higienópolis",
    image: "/eventos/semana-tecnologia-informacao.png",
    organizers: "Faculdade de Computação e Informática - FCI",
    contact: {
      website:
        "https://www.mackenzie.br/universidade/unidades-academicas/fci/semana-da-tecnologia-e-inovacao-2023",
    },
  },
  {
    id: 3,
    name: "Macknismo",
    tag: "Formaturas",
    date: "04/05/2024",
    location: "Expo Barra Funda",
    image: "/eventos/macknismo.png",
    organizers: "Comissão Macknismo",
    contact: {
      blacktag: "https://blacktag.com.br/eventos/17899/baile-de-gala-macknismo",
      instagram: "https://www.instagram.com/macknismo/",
      website: "https://linkbio.co/macknismobio",
    },
  },
  {
    id: 4,
    name: "Culto de Ação de Graças",
    tag: "Eventos Presenciais",
    date: "23/11/2023",
    location: "Auditório Ruy Barbora (Mackenzie - Higienópolis)",
    image: "/eventos/culto-acao-gracas.png",
    organizers: "Chancelaria Mackenzie",
    contact: {
      instagram: "https://www.instagram.com/mackenzie1870/",
      website: "https://www.youtube.com/watch?v=_wQ331ct2Lk",
    },
  },
  {
    id: 5,
    name: "Melhores do Ano - Atlética Arquitetura",
    tag: "Atleticas",
    date: "08/12/2023",
    location: "Rua Augusta, 591 (antigo SP club)",
    image: "/eventos/melhores-do-ano.png",
    organizers: "Atlética de Arquitetura",
    contact: {
      instagram: "https://www.instagram.com/atleticaarqmack/",
    },
  },
  {
    id: 6,
    name: "36º Semana de Recrutamento",
    tag: "Eventos Presenciais",
    date: "18/09/2023 - 20/09/2023",
    location: "Mackenzie Higienópolis",
    image: "eventos/semana-recrutamento.png",
    organizers: "Empresa Júnior Mackenzie Consultoria",
    contact: {
      whatsapp: "5511949060876",
      website:
        "https://www.mackenzie.br/noticias/artigo/n/a/i/mackenzie-abre-as-inscricoes-para-a-36a-semana-de-recrutamento",
    },
  },
  {
    id: 7,
    name: "Day Camp Connection 2023.2",
    tag: "Eventos Presenciais",
    date: "16/08/2023",
    location: "Mackenzie Higienópolis - Rua Itambé, 143",
    image: "eventos/day-camp.png",
    organizers: "Comunicação - Marketing Mackenzie",
    contact: {
      instagram: "https://www.instagram.com/mackenzie1870/",
      whatsapp: "5511949060876",
    },
  },
  {
    id: 8,
    name: "Baile de Gala Mack Comunica 320",
    tag: "Formaturas",
    date: "30/03/2024",
    location: "R. Tagipuru, 1001 - Expo Barra Funda",
    image: "eventos/comunica-mack.png",
    organizers: "Comissão 320.rw  & Kap Formaturas",
    contact: {
      instagram: "https://www.instagram.com/320.rw/",
      whatsapp: "5511949060876",
      blacktag:
        "https://blacktag.com.br/eventos/14999/baile-de-gala-mack-comunica-320",
    },
  },
  {
    id: 9,
    name: "Formatura Direito Mack In Terminis 319",
    tag: "Formaturas",
    date: "02/03/2024",
    location: "Expo Center Norte - Pavilhão Azul",
    image: "eventos/interminis.png",
    organizers: "Comissão In Terminis 319 & Kaz Formaturas ",
    contact: {
      instagram: "https://www.instagram.com/interminis319/",
      whatsapp: "5511949060876",
      blacktag:
        "https://blacktag.com.br/eventos/16298/baile-de-gala-direito-mack-in-terminis-319",
    },
  },
  {
    id: 10,
    name: "Leadership with Soul",
    tag: "Palestras",
    date: "16/08/2023",
    location: "Auditório Ruy Barbosa - Mackenzie Higienópolis",
    image: "eventos/leadership-with-soul.png",
    organizers: "Comunicação - Marketing Mackenzie",
    contact: {
      instagram: "https://www.instagram.com/mackenzie1870/",
      whatsapp: "5511949060876",
      website: "https://www.linkedin.com/in/andré-lacroix-lws/",
    },
  },
  {
    id: 11,
    name: "Energy Transition in the US: Policy Regulations & Stakeholders",
    tag: "Palestras",
    date: "18/08/2023",
    location: "MackGraphe – Mackenzie Higienópolis ",
    image: "eventos/energy-transition.png",
    organizers: "Comunicação - Marketing Mackenzie",
    contact: {
      instagram: "https://www.instagram.com/mackenzie1870/",
      whatsapp: "5511949060876",
    },
  },
];

export default listaEventos;
