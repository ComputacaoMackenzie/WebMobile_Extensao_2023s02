"use client";

import "./evento.css";
import Link from "next/link";
import listaEventos from "../mock/listaEventos";
import { useState, useEffect } from "react";
import Loading from "../components/Loading/Loading";

export default function Evento(props) {
  const { searchParams } = props;
  const { id } = searchParams;
  const evento = listaEventos[id];
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);
  const [weatherIcon, setWeatherIcon] = useState();
  const apiKey = "2X6D9KMU2P7UC8S3QQ8ULFJMQ";

  const formatDate = () => {
    if (evento.date.includes("-")) {
      const period = evento.date.split("-");
      period[0] = period[0].replace(/\s/g, "");
      period[1] = period[1].replace(/\s/g, "");

      const firstPeriod = period[0].split("/");
      const secondPeriod = period[1].split("/");

      return `${firstPeriod[2]}-${firstPeriod[1]}-${firstPeriod[0]}/${secondPeriod[2]}-${secondPeriod[1]}-${secondPeriod[0]}`;
    } else {
      const date = evento.date.split("/");
      return `${date[2]}-${date[1]}-${date[0]}`;
    }
  };

  const getWeatherIcon = () => {
    return weatherIcon;
  };

  useEffect(() => {
    fetch(
      `https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/SaoPaulo/${formatDate()}?key=${apiKey}`,
    )
      .then((response) => response.json())
      .then((response) => {
        console.log(response.days[0].icon);
        setIsLoading(false);
        setWeatherIcon(response.days[0].icon);
      })
      .catch((error) => {
        console.log(error);
        setIsLoading(false);
        setIsError(true);
      });
  }, []);
  return (
    <>
      <header>
        <Link href="/">
          <img id="back-button" src="back-button.svg" />
        </Link>
        <img src="logo-mack-eventos.png" />
      </header>
      <main class="pagina-evento">
        {isLoading && <Loading />}
        {!isLoading && (
          <>
            <h1>{evento.name}</h1>
            <img src={evento.image} />
            <section class="detalhes-evento">
              <div class="info-block">
                <h3>Data:</h3>
                <div class="background-detalhes data-clima">
                  {!isError && <img src={`weather/${getWeatherIcon()}.png`} />}
                  <p>{evento.date}</p>
                </div>
              </div>

              <div class="info-block">
                <h3>Local:</h3>
                <div class="background-detalhes local-evento">
                  <p>{evento.location}</p>
                </div>
              </div>

              <div class="info-block">
                <h3>Organizadores:</h3>
                <div class=" background-detalhes tipo-evento">
                  <p>{evento.organizers}</p>
                </div>
              </div>
            </section>

            {evento.contact && (
              <section class="section-mais-informacoes">
                <h2>Mais informações</h2>
                <section class="mais-informacoes-content">
                  {evento.contact.instagram && (
                    <div class="mais-content-text">
                      <img class="icon" src="icons/instagram-icon.png" />
                      <a href={evento.contact.instagram} target="_blank">
                        Instagram
                      </a>
                    </div>
                  )}

                  {evento.contact.blacktag && (
                    <div class="mais-content-text">
                      <img class="icon" src="icons/blacktag-icon.png" />
                      <a href={evento.contact.blacktag} target="_blank">
                        Blacktag
                      </a>
                    </div>
                  )}

                  {evento.contact.whatsapp && (
                    <div class="mais-content-text">
                      <img class="icon" src="icons/whatsapp-icon.png" />
                      <a
                        href={`https://api.whatsapp.com/send?phone=${evento.contact.whatsapp}`}
                        target="_blank"
                      >
                        Whatsapp
                      </a>
                    </div>
                  )}

                  {evento.contact.website && (
                    <div class="mais-content-text">
                      <img class="icon" src="icons/web-icon.webp" />
                      <a href={evento.contact.website} target="_blank">
                        Website
                      </a>
                    </div>
                  )}
                </section>
              </section>
            )}
          </>
        )}
      </main>
    </>
  );
}
