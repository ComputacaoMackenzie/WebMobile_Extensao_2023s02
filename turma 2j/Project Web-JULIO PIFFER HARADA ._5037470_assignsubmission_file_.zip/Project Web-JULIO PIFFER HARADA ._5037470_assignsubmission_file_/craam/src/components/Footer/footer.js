import React from 'react';
import "./footer.css";

const Footer = () => {
    return (
        <footer className="footer">
            © Copyright - 2023 - Centro de Rádio Astronomia e Astrofísica Mackenzie. Todos direitos reservados

        </footer>
    )
}

export default Footer