import React, { useState, useEffect } from "react";
import Navbar from "./components/NavBar/navbar";
import Intro from "./components/Intro/intro";
import Skills from "./components/Skills/skills";
import Projects from "./components/Projects/projects";
import Footer from "./components/Footer/footer";

const apiKey = 'CFfJ6Hi0TcVVgTNQO5PCe4NB7YDRuyEYhqxVz72x';

function App() {
  const [apodData, setApodData] = useState(null);
  const [showFullExplanation, setShowFullExplanation] = useState(false);

  useEffect(() => {
    const fetchApodData = async () => {
      try {
        const response = await fetch(`https://api.nasa.gov/planetary/apod?api_key=${apiKey}`);
        const data = await response.json();
        setApodData(data);
      } catch (error) {
        console.error('falha ao buscar erro:', error);
      }
    };

    fetchApodData();
  }, [apiKey]);

  const toggleExplanation = () => {
    setShowFullExplanation(!showFullExplanation);
  };

  return (
    <div className="App">
      <Navbar />
      <Intro />
      <Skills />
      <Projects />
      {apodData && (
        <div className="apod-titulo">
          <h3>Nasa - Imagem do Dia</h3>
          <img className="apod-titulo img" src={apodData.url} alt={apodData.title} />
          <p>
            {showFullExplanation
              ? apodData.explanation
              : `${apodData.explanation.slice(0, 50)}...`}
            {!showFullExplanation && (
              <button onClick={toggleExplanation}>Ver Mais</button>
            )}
          </p>
        </div>
      )}
      <Footer />
    </div>
  );
}

export default App;
