export default function Prof() {
    return (
        <div className="prof">
            <Header />
            <main>
                <div class="professores">
                    <div class="professores__texto">
                        <p>Conheça</p>
                        <h1>Nossos professores!</h1>
                    </div>
                    <div class="professores__imagens">
                        <img src="./midia/professorUm.png" alt="Diretora Daniela Vieira Cunha" />
                        <img src="./midia/professorDois.png" alt="Professor Joaquim Pessoa Filho" />
                        <img src="./midia/professorTres.png" alt="Professor Ismar Frango Silveira" />

                    </div>
                    <div class="professores--botao">
                        <button><i class="fa-solid fa-arrow-left"></i></button>
                        <button><i class="fa-solid fa-arrow-right"></i></button>
                    </div>
                </div>
            </main>
            <Footer />
            {/* <WeatherComponent /> */}
        </div>
    )
}