import { Inter } from 'next/font/google'
import Link from 'next/link';

export default function Home() {
  return (
    <>
      <h1>Ola Mundo!</h1>
    </>
  )
}
