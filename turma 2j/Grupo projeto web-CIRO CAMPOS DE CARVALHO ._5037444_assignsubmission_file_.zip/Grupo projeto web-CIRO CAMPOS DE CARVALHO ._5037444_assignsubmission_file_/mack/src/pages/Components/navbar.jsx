import Link from 'next/link';
// import profs from '../NossosProfs'

export default function Header() {
    return (
        <div className="header">
            <header>
                <div class="logo">
                    <img src="/midia/logo.png" alt="Logo" />
                </div>
                <div class="header__links">
                    <Link href='../NossosProfs'>Colaboradores</Link>
                    <a href="#">Artigos</a>
                    <a href="#">Atendimento</a>
                    <a href="#">Aluno e antigo aluno</a>
                </div>
            </header>
        </div>
    )
}