export default function NossaHistoria() {
    return (
        <div class="nossa_historia">
            <img src="./midia/image 2.png" alt="" />
            <div class="nossa_historia_txt">
                <h2>Conheça</h2>
                <h1>Nossa História</h1>
                <p>
                    A FCI foi fundada em 1970, buscando formar profissionais altamente qualificados para o mercado de
                    trabalho
                    em Computação e Matemática. Desde então, tem mantido cursos de excelência nessas áreas, com um quadro
                    docente de doutores e mestres, atualizando constantemente seus projetos pedagógicos de curso e seus
                    laboratórios e equipamentos. Os alunos participam de laboratórios de pesquisa com acesso às tecnologias
                    mais
                    modernas (conheça os laboratórios aqui). A infraestrutura da FCI também inclui uma biblioteca setorial
                    especializada e digital com referências bibliográficas sempre atualizadas. Além
                    disso, oferece a oportunidade de realizar mobilidade acadêmica em mais de 150 universidades localizadas
                    em
                    34 países.
                </p>
            </div>
        </div>
    )
}