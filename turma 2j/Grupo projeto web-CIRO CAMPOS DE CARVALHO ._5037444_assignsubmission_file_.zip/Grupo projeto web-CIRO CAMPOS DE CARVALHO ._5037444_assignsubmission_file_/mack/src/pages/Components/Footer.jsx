export default function Footer() {
    return (
        <div className="footer">
            <footer>
                <div class="footer__cima">
                    <div class="redes">
                        <a href="#"><img src='/midia/instagram.png' alt="Instagram" /></a>
                        <a href="#"><img src='/midia/facebook.png' alt="Facebook" /></a>
                        <a href="#"><img src='/midia/twitter.png' alt="Twitter" /></a>
                    </div>
                    <div class="footer__base footer__links">
                        <h2>Links</h2>
                        <a href="#">Sobre nós</a>
                        <a href="#">Nossa história</a>
                        <a href="#">Confessional</a>
                        <a href="#">Voluntário</a>
                    </div>
                    <div class="footer__base footer__explore">
                        <h2>Explore</h2>
                        <a href="#">Blog</a>
                        <a href="#">Artigos</a>
                        <a href="#">Eventos</a>
                        <a href="#">Mídias</a>
                    </div>
                    <div class="footer__base footer__contatos">
                        <h2>Contatos</h2>
                        <a href="tel:+55-11-3555-2048">(11) 3555-2048/2022</a>
                        <a href="tel:+55-19-3211-4100">(19) 3211-4100</a>
                        <a href="tel:+55-11-2114-8000">(11) 2114-8000</a>
                        <a href="mailto:fempar@fempar.edu.par">fempar@fempar.edu.par</a>
                    </div>
                </div>
                <div class="footer__baixo">
                    <p>© Copyright - 2023</p>
                </div>
            </footer>
        </div>
    )
}