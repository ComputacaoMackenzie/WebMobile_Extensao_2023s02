export default function Cards() {
    return (
        <div class="tres_cards">

            <div class="card">
                <div class="top-card-sistemas"></div>
                <div class="bottom-card">
                    <div class="bottom-1">
                        <div class="bottom1-infos">
                            <img src="./midia/icons8-capelo-20.png" alt="" />
                            <p>4 anos</p>
                        </div>
                        <div class="bottom1-infos">
                            <img src="./midia/icons8-livro-20.png" alt="" />
                            <p>Diploma - bacharelado</p>
                        </div>
                    </div>
                    <div class="bottom-curso">
                        <h1>Sistemas de<br />Informação</h1>
                    </div>
                    <div class="bottom-footer">
                        <div class="star">
                            <img src="./midia/icons8-estrela-20.png" alt="Star" />
                            <img src="./midia/icons8-estrela-20.png" alt="" />
                            <img src="./midia/icons8-estrela-20.png" alt="" />
                            <img src="./midia/icons8-estrela-20.png" alt="" />
                        </div>
                        <p>Certificado pelo MAC</p>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="top-card-cc"></div>
                <div class="bottom-card">
                    <div class="bottom-1">
                        <div class="bottom1-infos">
                            <img src="./midia/icons8-capelo-20.png" alt="" />
                            <p>4 anos</p>
                        </div>
                        <div class="bottom1-infos">
                            <img src="./midia/icons8-livro-20.png" alt="" />
                            <p>Diploma - bacharelado</p>
                        </div>
                    </div>
                    <div class="bottom-curso">
                        <h1>Ciência da<br />Computação</h1>
                    </div>
                    <div class="bottom-footer">
                        <div class="star">
                            <img src="./midia/icons8-estrela-20.png" alt="Star" />
                            <img src="./midia/icons8-estrela-20.png" alt="" />
                            <img src="./midia/icons8-estrela-20.png" alt="" />
                            <img src="./midia/icons8-estrela-20.png" alt="" />
                            <img src="./midia/icons8-estrela-20.png" alt="" />
                        </div>
                        <p>Certificado pelo MAC</p>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="top-card-ec"></div>
                <div class="bottom-card">
                    <div class="bottom-1">
                        <div class="bottom1-infos">
                            <img src="./midia/icons8-capelo-20.png" alt="" />
                            <p>4 anos</p>
                        </div>
                        <div class="bottom1-infos">
                            <img src="./midia/icons8-livro-20.png" alt="" />
                            <p>Diploma - bacharelado</p>
                        </div>
                    </div>
                    <div class="bottom-curso">
                        <h1>Engenharia da<br />Computação</h1>
                    </div>
                    <div class="bottom-footer">
                        <div class="star">
                            <img src="./midia/icons8-estrela-20.png" alt="Star" />
                            <img src="./midia/icons8-estrela-20.png" alt="" />
                            <img src="./midia/icons8-estrela-20.png" alt="" />
                            <img src="./midia/icons8-estrela-20.png" alt="" />
                        </div>
                        <p>Certificado pelo MAC</p>
                    </div>
                </div>
            </div>

        </div>
    )
}