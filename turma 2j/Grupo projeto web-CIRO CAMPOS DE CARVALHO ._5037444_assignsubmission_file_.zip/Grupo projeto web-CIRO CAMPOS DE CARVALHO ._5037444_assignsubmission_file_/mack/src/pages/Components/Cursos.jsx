import Cards from "./CursosCards"

export default function Cursos() {
    return (
        <div class="cursos_disponiveis">
            <div class="cursos_disponiveis_cabecalho">
                <div class="cursos_disponiveis_txt">
                    <h2>Conheça</h2>
                    <h1>Todos os Cursos Disponíveis dentro da FCI</h1>
                </div>
                <button><i class="fa-solid fa-arrow-left"></i></button>
                <button><i class="fa-solid fa-arrow-right"></i></button>
            </div>
            <Cards />
            <div class="barra">
                <h1>+5000</h1>
                <p>Alunos já passaram pela FCI</p>
                <button>Faça parte</button>
            </div>
        </div>
    )
}