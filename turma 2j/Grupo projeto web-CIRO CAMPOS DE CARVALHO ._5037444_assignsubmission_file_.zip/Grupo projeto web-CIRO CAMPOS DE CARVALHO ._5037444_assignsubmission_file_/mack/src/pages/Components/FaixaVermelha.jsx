// Import de fotos
export default function Faixa() {
    return (
        <div class="faixa_vermelha">
            <div class="faixa_vermelha_img">
                <img src="./midia/image 6.png" alt="" />
                <img src="./midia/image 7.png" alt="" />
                <img src="./midia/image 8.png" alt="" />
            </div>
        </div>
    )
}