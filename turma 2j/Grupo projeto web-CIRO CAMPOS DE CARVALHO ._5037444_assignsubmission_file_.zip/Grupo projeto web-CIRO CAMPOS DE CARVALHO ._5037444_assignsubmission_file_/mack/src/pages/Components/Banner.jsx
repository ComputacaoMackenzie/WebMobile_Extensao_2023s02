// import Apresenta from 

export default function Banner() {
    return (
        <div className="Banner">
            <article>
                <div id="presentation">
                    <h1 class="a1" id="titulo">Inovação & Educação</h1>
                    <div class="a2" id="paragrafo">
                        <p>A FCI foi fundada em 1970, buscando formar profissionais altamente qualificados para o mercado de
                            trabalho em Computação e Matemática.</p>
                    </div>
                    <button class="a3" id="meet">Conheça o curso</button>
                    <img class="a4" src="./midia/img_apresent.PNG" alt="img_apresent" />
                </div>
            </article>
        </div>
    )
}