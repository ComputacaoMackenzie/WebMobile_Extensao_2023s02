import './Components/globals.css'
import Home from './index'
import Header from './Components/navbar';
import Banner from './Components/Banner';
import Cursos from './Components/Cursos';
import NossaHistoria from './Components/NossaHistoria';
import Faixa from './Components/FaixaVermelha';
import Footer from './Components/Footer';
import WeatherComponent from './api/WeatherComponent';
import Link from 'next/link';

export default function App() {
  return (
    <div className='app'>
      <Header />
      <Banner />
      <Cursos />
      <NossaHistoria/>
      <Faixa/>
      <Footer/>
      <WeatherComponent/>
    </div>
  )
}
