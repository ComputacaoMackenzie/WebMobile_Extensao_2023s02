import React, { useState, useEffect } from 'react';

const WeatherComponent = () => {
  const [weatherData, setWeatherData] = useState(null);
  const latitude = -23.5481237;
  const longitude = -46.6504377;
  const apiKey = '03b552df747a20ac77ff07bb64fc10d0';

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          `http://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${apiKey}`
        );
        const data = await response.json();
        setWeatherData(data);
      } catch (error) {
        console.error('Erro ao buscar dados do clima:', error);
      }
    };

    fetchData();
  }, [latitude, longitude, apiKey]);

  return (
    <div>
      {weatherData && (
        <p id='temperatura'>
          Temperatura no Mack ☁️
           {Math.round(weatherData.main.temp - 273.15)}°C
        </p>
      )}
    </div>
  );
};

export default WeatherComponent;
