import React from "react";
import './Cadastro.css'

export default function Cadastro(){
   
   return(
      <>
         <div className="main-container cadastro">
            <form>
               <label for="nome">Nome:</label>
               <input type="text" name="nome" id="nome" required />
     
               <label for="email">E-mail:</label>
               <input type="email" name="email" id="email" required />

               <label for="TIA">TIA:</label>
               <input type="text" name="TIA" id="TIA" required />
     
               <label for="senha">Senha:</label>
               <input type="password" name="senha" id="senha" required />
     
               <input type="submit" value="Enviar"/>
            </form>
         </div>
      </>
   )
}