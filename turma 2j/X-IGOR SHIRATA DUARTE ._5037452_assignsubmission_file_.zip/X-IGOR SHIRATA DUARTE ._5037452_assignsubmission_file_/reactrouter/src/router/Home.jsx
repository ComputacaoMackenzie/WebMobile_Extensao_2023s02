import React from "react";
import './Home.css'

export default function Home(){
   return (
      <>
         <div class="main-container">
            <h1>Bem-vindo ao Guia do Calouro Mackenzista: Seu Passaporte para o Mundo Universitário!</h1>
            <div class="text-right">
               <p>E aí, calouro mackenzista! Se você está aqui, é porque deu um passo corajoso em direção a uma das fases mais empolgantes da sua vida acadêmica. Nós, do Guia ao Calouro, estamos aqui para ser o seu GPS nessa jornada cheia de desafios e descobertas que é a vida universitária.<br/><br/>

               Somos um grupo de quatro alunos (Lucas Lucinio, Igor Shirata, Lucas Bittencourt e João Pereira) que já passaram por altos e baixos durante nossa estadia pelo campus e agora, estamos aqui para compartilhar algumas informações contigo, para te ajudar neste início de jornada.<br/><br/>
            
               Seja qual for a sua faculdade, curso, ou objetivo, saiba que você não está sozinho. Estamos aqui para descomplicar e tornar a sua transição para a vida universitária a mais suave possível. Então, pegue seu café, ajeite sua mochila, e vamos embarcar nessa jornada juntos!
               </p>
            </div>
         </div>
      </>
   );
};