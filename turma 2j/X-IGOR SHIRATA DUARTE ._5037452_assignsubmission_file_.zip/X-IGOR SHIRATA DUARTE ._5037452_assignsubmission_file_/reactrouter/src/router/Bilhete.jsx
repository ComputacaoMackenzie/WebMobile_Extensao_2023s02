import React from "react";
import './Bilhete.css'

export default function Bilhete(){
   return (
      <>
         <div class="main-container bilhete">
            <p>O Bilhete Único do Estudante é um aliado fundamental na sua jornada academica. Com descontos especiais nas tarifas de metrô, ônibus e CPTM, ele vai te ajudar no seu transporte de ida e volta da faculdade, alem de ajudar com as atividades extracurriculares. Sabemos que muitos calouros podem ficar um pouco perdidos quando se trata de solicitar o seu Bilhete Único de Estudante. Mas não se preocupe, nós criamos um guia passo a passo para facilitar esse processo. Vamos te mostrar exatamente como garantir o seu benefício e aproveitar ao máximo essa vantagem que a vida universitária tem a oferecer. Acesse o tutorial disponibilizado pelo próprio mackenzie clicando no botão abaixo.
            O Bilhete Único do Estudante é um aliado fundamental na sua jornada academica. Com descontos especiais nas tarifas de metrô, ônibus e CPTM, ele vai te ajudar no seu transporte de ida e volta da faculdade, alem de ajudar com as atividades extracurriculares. Sabemos que muitos calouros podem ficar um pouco perdidos quando se trata de solicitar o seu Bilhete Único de Estudante. Mas não se preocupe, nós criamos um guia passo a passo para facilitar esse processo. Vamos te mostrar exatamente como garantir o seu benefício e aproveitar ao máximo essa vantagem que a vida universitária tem a oferecer. Acesse o tutorial disponibilizado pelo próprio mackenzie clicando no botão abaixo.
            </p>
            <button>
               <a href="https://www3.mackenzie.br/tia/arquivos/pdf/4341d0af7590a76b352d8fc4bb11bd03_0.pdf?" target="_blank">
                  Acessar PDF
               </a>
            </button>
         </div>
      </>
   );
};