import React from "react";
import './Atleticas.css'

export default function Atleticas() {
   return(
      <>
         <div class="main-container atletica">
            <div class="texts-atletica">
               <p>
               Calouro mackenzista, se você está pronto para mergulhar de cabeça na vida universitária, temos um segredinho valioso para compartilhar: as Atléticas dos cursos são uma parte essencial dessa jornada emocionante! Aqui, você encontrará uma lista das principais Atléticas, cada uma representando um curso distinto do Mackenzie. Estamos falando de grupos que vão muito além das competições esportivas. Essas Atléticas são verdadeiras famílias, unidas pela paixão pelo esporte, pela camaradagem e pela busca incessante pela vitória. Se você é um esportista nato ou simplesmente quer fazer parte de uma comunidade vibrante e unida, as Atléticas são o lugar certo para estar.
               </p>
            </div>

            <div class="tabela-nomes-atletica">
               <table width="100%">
                  <tr>
                     <th>Curso</th>
                     <th>Atlética</th>
                  </tr>
                  <tr>
                     <td>Administração</td>
                     <td>@adm_mackenziesp</td>
                  </tr>
                  <tr>
                     <td>Direito</td>
                     <td>@raposaodireitomack</td>
                  </tr>
                  <tr>
                     <td>Tecnologia</td>
                     <td>@raposaodireitomack</td>
                  </tr>
                  <tr>
                     <td>Ciências Econômicas</td>
                     <td>@aaaegoficial</td>
                  </tr>
                  <tr>
                     <td>Publicidade e Propaganda</td>
                     <td>@publicidademack</td>
                  </tr>
               </table>
            </div>
         </div>
      </>
   )
}