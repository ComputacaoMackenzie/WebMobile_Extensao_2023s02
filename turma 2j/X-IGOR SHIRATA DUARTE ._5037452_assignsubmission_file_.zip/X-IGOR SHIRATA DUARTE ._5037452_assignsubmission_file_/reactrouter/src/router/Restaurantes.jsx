import React from "react";
import './Restaurantes.css';
import mapa from './mapa/mapaMack.jpeg';

export default function Restaurantes(){
   return (
      <>
         <div class="main-container restaurantes">
         <div class="texts">
            <p>
               Não há nada pior do que tentar estudar com o estômago roncando, ou ficar perdido tentando encontrar um lugar para recarregar as energias entre as aulas. É por isso que, como seus guias acadêmicos, decidimos reunir todas as informações sobre as melhores opções de comida no campus. Afinal, uma boa refeição é essencial para manter a mente afiada e o corpo funcionando. Neste espaço, você encontrará um mapeamento detalhado das cantinas e refeitórios.
            </p>
         </div>
     
         <img src={mapa} alt="Mapa do Mackenzie" class="imagem-mapa"/>
      </div>
      </>
   )
}