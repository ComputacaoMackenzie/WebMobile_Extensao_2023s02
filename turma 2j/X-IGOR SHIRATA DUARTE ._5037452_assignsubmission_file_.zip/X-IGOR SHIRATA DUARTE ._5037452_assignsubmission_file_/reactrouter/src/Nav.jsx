import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Home from './router/Home';
import Bilhete from './router/Bilhete';
import Cadastro from "./router/Cadastro";
import Restaurantes from "./router/Restaurantes";
import Atleticas from "./router/Atleticas";
import Api from './router/api.jsx'

import logo from './assets/logo.png';
import './Nav.css'

export default function Nav() {

  const toggleMenu = () => {
    const ul = document.getElementById("ul");
    if (ul.style.display === "none") {
      ul.style.display = "flex";
    } else {
      ul.style.display = "none";
   }
  }
  
  return (
    <>
      <div className="api">
        <Api className='api'></Api>
      </div>
      <header className="header-container">
        <img src={logo} width={300} alt="Logo do Site"/>
      </header>
      <BrowserRouter>
      <div className="nav-container">
        <button onClick={toggleMenu}>
          <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAZ0lEQVR4nO3WwQmAQAwF0SlPt/+zC4t9RGxAZRH84DzIPTkEBiRJek8DOlDh04H16pARsGQ9nP0Xh6zAFrBk3cy54zL7P5IkSR9pZjxZ9TsCyrbMeEmSpGzNjCerfkdAnpcZL0kScw7zFAKxsVXx1wAAAABJRU5ErkJggg=="/>
        </button>
        <ul id="ul">
          <li><Link to="/" className="a">Home</Link></li>
          <li><Link to="/Bilhete" className="a">Bilhete Único</Link></li>
          <li><Link to="/Atleticas" className="a">Atleticas</Link></li>
          <li><Link to="/Restaurantes" className="a">Restaurantes</Link></li>
          <li><Link to="/Cadastro" className="a">Cadastro</Link></li>
        </ul>
      </div>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Bilhete" element={<Bilhete />} />
        <Route path="/Cadastro" element={<Cadastro/>} />
        <Route path="/Restaurantes" element={<Restaurantes/>} />
        <Route path="/Atleticas" element={<Atleticas/>} />
      </Routes>
      </BrowserRouter>
    </>
  )
}