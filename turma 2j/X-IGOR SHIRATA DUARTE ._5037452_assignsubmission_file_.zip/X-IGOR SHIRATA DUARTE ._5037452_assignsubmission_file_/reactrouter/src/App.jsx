import './App.css';
import Nav from './Nav';

function App() {
  
  return (
    <>
      <Nav />
    </>
  )
}

export default App
