import React from "react";

import './AreaComponents.css';
import mapa from './mapa-do-campus.jpeg';

export default function AreaComponents1() {
   return (
      <>
         <h1 className="title">Áreas do Campus</h1>
         <h1> Conheça o campus!</h1>

		   <p>Bem-vindo ao nosso site para calouros! Estamos animados em tê-lo(a) aqui e ansiosos para ajudá-lo(a) a se familiarizar com o campus da nossa faculdade. Aqui, apresentamos um mapa detalhado para garantir que você possa navegar facilmente por todas as áreas e instalações importantes.</p>

         <p>Nosso campus é um lugar vibrante e cheio de oportunidades educacionais e sociais. Com uma ampla gama de prédios e espaços, queremos garantir que você se sinta confiante ao explorar e aproveitar tudo o que a nossa instituição tem a oferecer. O mapa a seguir fornecerá uma visão geral de todos os principais locais e pontos de interesse no campus.

         </p>
         <div class="mapa">
            <img src={mapa} width={1000}/>
         </div>
      </>
   )
}