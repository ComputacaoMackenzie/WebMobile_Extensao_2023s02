import React from "react";

import './AreaComponents.css';
import  bosque from './bosquemack.jpeg';
import biblioteca from  './bibliotecamack.jpeg';

export default function AreaComponents2() {
   return(
      <div className="area2">
        <h1>Lugares Imperdiveis: </h1>
        <br />
        <ul>
            <li>
               <h3>Prédio Administrativo: </h3>
               <p> 
                  Este é o coração do campus, onde você encontrará os escritórios administrativos, incluindo a reitoria, a secretaria acadêmica e outros departamentos importantes. Se você tiver alguma dúvida ou precisar de assistência, este é o lugar para ir. 
               </p>
            </li>

            <li>
               <h3>Biblioteca: </h3>
               <p>
                  Conhecida pelo alunos como “Biblioteca do Harry Potter”, na verdade o prédio 2, inaugurado em 1926, foi batizado de George Alexander, conselheiro do Mackenzie College por 30 anos.

                  Assim como toda a parte histórica do nosso campus, os tijolinhos chamam atenção de todos os visitantes e futuros alunos da Instituição. A biblioteca abriga uma infinidade de livros e tem uma iluminação incrível para os amantes da fotografia.
               </p>
            </li>

            <li>
               <h3>Laboratórios: </h3>
               <p>
                  Como estudante de ciências ou áreas relacionadas, você passará muito tempo nos laboratórios. Nossas instalações de última geração são projetadas para fornecer um ambiente seguro e propício à experimentação e descoberta científica.
               </p>
            </li>

            <li>
               <h3>Auditório: </h3>
               <p>
                  O auditório é o local onde ocorrem palestras, seminários, apresentações e eventos especiais. Esteja atento(a) aos eventos anunciados e não perca a oportunidade de expandir seus conhecimentos e interagir com palestrantes renomados.
               </p>
            </li>

            <li>
               <h3>Centro esportivo:</h3>
               <p>
                  Nosso centro esportivo é um lugar onde você pode manter-se ativo, participar de atividades físicas e desfrutar de uma vida saudável no campus. Aqui você encontrará uma variedade de instalações, como quadras esportivas, academia e espaço para atividades ao ar livre.
               </p>
            </li>

            <li>
               <h3>Praça de alimentação: </h3>
               <p>
                  Às vezes, uma pausa para comer é exatamente o que você precisa para recarregar as energias. Nossas cantinas e cafeterias oferecem uma variedade de opções de refeições e lanches para atender a todos os gostos. Aproveite para relaxar e socializar com seus colegas de classe.
               </p>
            </li>

            <li>
               <h3>Áreas Verdes:</h3>
               <p>
                  Muitos mackenzistas escolhem o “Bosque das Fadas” (sim, esse é o nome oficial) para descansar, ler um livro ou conversar com os amigos. O lugar é tranquilo e serve como um refúgio para quem não se acostumou ainda com o ritmo da cidade grande.

                  Você deve imaginar que apenas prédios são tombados, mas não. O espaço ao ar livre é reconhecido como Patrimônio pelo CONDEPHAAT (Conselho de Defesa do Patrimônio Histórico, Arqueológico, Artístico e Turístico do Estado de São Paulo).
                
                  Historicamente, o bosque abriga o busto de Horace Lane (intacto desde 1914!), que no ano de 1884 foi convidado pelo Rev. Chamberlain para dirigir a Escola Americana.
                
                  A novidade por ali é que durante as férias, refizeram a jardinagem. Que tal você dar uma passada por lá para conferir?
               </p>
            </li>
         </ul>
         <div className="fotos">
            <img src={bosque} width={700}/>
            <img src={biblioteca} width={700}/>
         </div>
      </div>
   )
}