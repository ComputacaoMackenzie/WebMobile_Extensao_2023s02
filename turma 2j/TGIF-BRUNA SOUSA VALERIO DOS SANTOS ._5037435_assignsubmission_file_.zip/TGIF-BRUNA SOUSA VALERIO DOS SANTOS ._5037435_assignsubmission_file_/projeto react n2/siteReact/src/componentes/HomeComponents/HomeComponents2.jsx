import React from "react";

import imagesmack from './imagesmack.png';
import './HomeComponents.css';

export default function HomeComponents2() {
   return (
      <>
         <section id="sobre">    
            <h1>Isto é MACKENZIE!!</h1>
            <p>
                A faculdade é muito mais do que apenas estudar e frequentar aulas. Existem muitas atividades extracurriculares, como clubes, organizações estudantis e eventos, que podem ajudá-lo a se envolver na comunidade da faculdade e fazer novas amizades. Participar dessas atividades pode ser uma ótima maneira de sair da sua zona de conforto e descobrir novos interesses.
            </p>
            <p>
                A faculdade pode ser um ótimo lugar para encontrar pessoas com interesses e objetivos semelhantes aos seus. Tente se conectar com colegas de classe que estão estudando a mesma área que você ou que compartilham interesses semelhantes. Ter amigos com quem você possa estudar, discutir ideias e se apoiar mutuamente pode tornar a faculdade muito mais agradável e recompensadora.
            </p>
         </section>

         <br />

         <div id="imgmeio">
            <img src={imagesmack} width={600}/>
         </div>

         <br />
         <section id="sobre">
            <p>
                Às vezes, pode parecer difícil. Haverá desafios e momentos de dúvida. Mas, quando enfrentarem esses momentos, lembrem-se do motivo pelo qual escolheram o Mackenzie. Lembrem-se do seu desejo de aprender, crescer e se destacar. Lembrem-se de que vocês estão aqui para se tornarem os líderes, os inovadores e os agentes de mudança do futuro.
            </p>
            <p>
                Então, caros calouros, mergulhem de cabeça nesta experiência. Se interessem por tudo o que o Mackenzie tem a oferecer. Conheçam seus professores, façam perguntas, participem das aulas e busquem conhecimento além do currículo. Este é o momento de explorar, experimentar e crescer.
            </p>
            <p>
                Aproveitem cada momento e lembrem-se de que o Mackenzie está aqui para ajudar vocês a alcançarem seus sonhos. Juntos, podemos construir um futuro brilhante.
            </p>
            <h4> Bom semestre e boa sorte em sua jornada universitária!!</h4>
         </section>
      </>
   )
}