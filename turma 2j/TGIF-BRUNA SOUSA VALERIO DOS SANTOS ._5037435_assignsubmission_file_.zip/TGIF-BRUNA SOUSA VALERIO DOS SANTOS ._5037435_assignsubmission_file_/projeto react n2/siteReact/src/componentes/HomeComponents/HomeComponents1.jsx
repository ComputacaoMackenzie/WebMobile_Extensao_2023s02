import React from "react";

import mackenzieFoto2 from './mackenziefoto2.png';
import cursosmackenzie from './cursosmackenzie.png'
import './HomeComponents.css';

export default function HomeComponents1() {
   return (
      <>
         <h1 className="title">Guia para calouros-MACKENZIE</h1>
         <section id="sobre">
			   <h1>Olá Mackenzista!</h1>
			   <p>
                Seja bem vindo ao MACKENZIE, nosso obejtivo com esse site é te guiar como calouro. Te apresentando um mapa da nossa universidade, grupos para que possa conhecer sua nova turma, atléticas para os amantes do esporte e muito mais. 
                Seja bem vindo a nova etapa da sua vida. 
            </p>
            <p>
                Universidade Presbiteriana Mackenzie, carinhosamente conhecida como Mackenzie, é uma instituição de ensino superior reconhecida nacionalmente e localizada na cidade de São Paulo, Brasil. Com mais de 150 anos de história, a faculdade Mackenzie é conhecida por sua excelência acadêmica e sua contribuição para a formação de profissionais apoiados em diversas áreas do conhecimento.
            </p>
            <p> 
               Se você é um calouro em sua primeira semana de aulas na faculdade, pode estar se sentindo um pouco sobrecarregado com as mudanças que está  enfrentando. A transição do ensino médio, ou qualquer que seja para a faculdade pode ser desafiadora, mas nós estamos aqui para ajudá-lo a se ajustar melhor e aproveitar ao máximo a sua experiência na faculdade!!
            </p>
		   </section>
         <div class="fotos">
            <img src={mackenzieFoto2} width={500}/>
            <img src={cursosmackenzie} width={500}/>
        </div>
      </>
   )
}