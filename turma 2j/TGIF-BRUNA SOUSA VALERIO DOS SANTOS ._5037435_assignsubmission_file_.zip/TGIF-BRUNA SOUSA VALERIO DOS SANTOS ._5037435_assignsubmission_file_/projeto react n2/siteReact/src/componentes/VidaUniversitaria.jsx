import React from "react";
import './Global.css';

import VUComponents1 from "./VidaUniversitaria/VUComponents1";
import VUComponents2 from "./VidaUniversitaria/VUComponents2";

export default function VidaUniversitaria() {
   return (
      <>
         <div className="article">
            <VUComponents1 />
            <br />
            <br />
            <VUComponents2 />
         </div>
      </>
   )
}