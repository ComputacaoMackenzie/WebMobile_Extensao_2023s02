import React from "react";
import './Global.css';

import AreaComponents1 from './AreaComponents/AreaComponents1';
import AreaComponents2 from "./AreaComponents/AreaComponents2";

export default function Area() {
   return (
      <>
         <div className="article">
            <AreaComponents1 />
            <br />
            <br />

            <AreaComponents2 />
            <br />
            <br />

         </div>
      </>
   )
}