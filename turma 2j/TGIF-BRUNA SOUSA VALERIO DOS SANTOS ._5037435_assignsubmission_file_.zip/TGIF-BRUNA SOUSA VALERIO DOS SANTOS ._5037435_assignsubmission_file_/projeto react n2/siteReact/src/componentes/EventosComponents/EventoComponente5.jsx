import React from "react";
import './EventosComponents.css';

import BotaFora from './botafora.png';
import FestaMack from './festamack.png';

export default function EventoComponente5() {

   return (
      <>
         <h2>Festas</h2>
         <p>
            A vida universitária é repleta de desafios acadêmicos, descobertas e, é claro, momentos inesquecíveis de diversão. E o Mackenzie sabe como transformar suas festas em experiências memoráveis.
         </p>
         <p>
            Nossas festas universitárias são mais do que apenas eventos sociais; são celebrações das amizades e da liberdade que a universidade proporciona. É o momento em que os alunos se unem para criar lembranças que durarão a vida toda.
         </p>
         <p>
            Da festa de boas-vindas ao baile de formatura, passando por festas temáticas e eventos culturais, oferecemos uma variedade de oportunidades para você relaxar, socializar e deixar seu lado festivo brilhar. DJs talentosos, música e uma atmosfera incrivel fazem parte de cada evento.
         </p>
         <p>
            No entanto, lembre-se, enquanto celebramos, também promovemos a responsabilidade. Divirta-se com segurança, respeite os outros e mantenha o espírito do Mackenzie em alta. As festas são momentos para criar memórias incríveis, mas também para construir relacionamentos sólidos e duradouros.
         </p>
         <p>
            Então, prepare-se para dançar, rir e celebrar a vida universitária da melhor maneira possível. Junte-se às nossas festas e faça parte desta incrível comunidade de estudantes que sabe como equilibrar o trabalho árduo com momentos de alegria e descontração.
         </p>
         <br />
         <br />
         <div className="fotos">
            <img src={BotaFora}  width={500} alt="Imagem 1"/>
            <img src={FestaMack} width={500} alt="Imagem 2"/>
         </div>
      </>
   );
};