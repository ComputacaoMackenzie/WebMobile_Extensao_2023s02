import React from "react";
import './EventosComponents.css';

import AtleticasFoto from './atleticas.png';
import PalestraFoto from './palestra.png';

export default function EventoComponente4(){
    return (
      <>
         <h2>Atividades Esportivas</h2>
         <br />
         <p>
            A faculdade Mackenzie também é conhecida por suas atividades esportivas. O Jogos Mackenzistas é um evento esportivo que reúne estudantes de diferentes cursos em competições saudáveis. Essa estimula a competição do espírito esportivo, promove a integração entre os alunos e fortalece o senso de comunidade dentro da universidade.
         </p>

         <p>
            A vida cultural também é valorizada na faculdade Mackenzie, com eventos como festivais de música, teatro e exposições de arte. Essas atividades culturais enriquecem o ambiente acadêmico, estimulam a criatividade dos alunos e promovem o intercâmbio cultural dentro da comunidade estudantil.
         </p>

         <p>
            É importante ressaltar que, devido às circunstâncias globais, como a pandemia de COVID-19, muitos eventos presenciais podem ter sofrido alterações ou sido adaptados para formatos online, garantindo a segurança e o bem-estar de todos os envolvidos.
         </p>
         <br />
         <br />
         <div class="fotos">
            <img src={AtleticasFoto} width={500} alt="Atleticas" />  
            <img src={PalestraFoto} width={500} alt="Palestra Mackenzie" />  
         </div>
      </>     
   );
};