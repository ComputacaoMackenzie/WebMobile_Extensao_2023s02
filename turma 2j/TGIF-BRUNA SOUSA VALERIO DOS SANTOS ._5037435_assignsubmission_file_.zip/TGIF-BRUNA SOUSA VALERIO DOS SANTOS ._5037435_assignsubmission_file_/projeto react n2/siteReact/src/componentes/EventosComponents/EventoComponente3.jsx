import React from "react";
import './EventosComponents.css';

import mackVoluntario1 from './mackvoluntari.jpg';
import mackVoluntario2 from './mackvoluntarios.png';

export default function EventoComponente3() {
   return (
      <>
         <h2>Mackenzie Voluntário</h2>
         <p>  
            Entre os eventos de destaque na faculdade Mackenzie é o Mackenzie Voluntário. Trata-se de uma ação social em que os alunos têm a chance de se engajar em projetos de voluntariado, ajudando comunidades carentes e confiantes para o desenvolvimento social. Essa iniciativa demonstra o compromisso da instituição com a responsabilidade social e a formação de cidadãos conscientes.
         </p>
         <br />
         <br />
         <div class="fotos">
            <img src={mackVoluntario1} width={500}  alt="Mackenzie voluntário" /> 
            <img src={mackVoluntario2} width={500}  alt="Mackenzie Voluntário" />
         </div>
         <br />
         <br />
      </>
   );
}