import React from "react";
import './EventosComponents.css';

export default function EventoComponente2(){
    return (
      <>
         <div className="videoMackDay">
            <h2>Vídeo <span>Mackenzie Day 2022</span></h2>
            <a href="https://www.youtube.com/embed/ilXeQMW2JXI" target="_blank">Acesse o vídeo</a>
         </div>
      </>
   );
};