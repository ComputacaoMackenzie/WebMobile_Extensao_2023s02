import React from "react";
import './EventosComponents.css';

export default function EventoComponente1(){
   return (
      <>
         <h1 className="title">Eventos</h1>
         <p>Calouros, vocês estão prestes a embarcar em uma emocionante jornada no mundo universitário e o Mackenzie está pronto para recebê-los com braços abertos. Os eventos de boas-vindas da nossa instituição são muito mais do que uma simples formalidade; eles são uma oportunidade de mergulhar em um mundo de possibilidades, de conhecer novas pessoas e de explorar um campus vibrante.            
         </p>
         <p>
            Imagine um lugar onde vocês podem descobrir as maravilhas da aprendizagem, a beleza da diversidade e o poder da comunidade. Os eventos de boas-vindas são projetados para proporcionar exatamente isso.
         </p>
         <p>
            Durante esse período, vocês terão a chance de conhecer seus colegas de classe, professores e funcionários, construindo conexões que irão acompanhá-los durante toda a sua jornada acadêmica. Os eventos sociais, sessões de orientação e encontros informais são oportunidades perfeitas para fazer novas amizades e compartilhar expectativas.
         </p>
         <p>
            Além disso, os eventos de boas-vindas oferecem uma visão completa do que a vida universitária tem a oferecer. Vocês terão acesso a palestras inspiradoras, workshops interativos e atividades esportivas e culturais empolgantes. É uma chance de explorar seus interesses, descobrir novos talentos e se envolver em tudo o que faz o Mackenzie ser um lugar único.

         </p>
         <p>
            Então, preparem-se para a mágica dos eventos de boas-vindas do Mackenzie. Este é o momento de sonhar alto, de abraçar desafios e de abraçar a incrível comunidade universitária que está pronta para recebê-los.
         </p>
         <br /> <br />
      </>
   );
};