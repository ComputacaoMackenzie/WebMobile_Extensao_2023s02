import React from "react";
import './Global.css';

import EventoComponent1 from "./EventosComponents/EventoComponent1";
import EventoComponent2 from "./EventosComponents/EventoComponent2";
import EventoComponente3 from "./EventosComponents/EventoComponente3";
import EventoComponente4 from "./EventosComponents/EventoComponente4";
import EventoComponente5 from "./EventosComponents/EventoComponente5";


export default function Eventos() {
   return (
      <>
         <div className="article">
            <EventoComponent1 />
            <br />
            <br />
            <EventoComponent2 />
            <br />
            <br />
            <EventoComponente3 />
            <br />
            <br />
            <EventoComponente4 />
            <br />
            <br />
            <EventoComponente5 />
         </div>
      </>
   )
}