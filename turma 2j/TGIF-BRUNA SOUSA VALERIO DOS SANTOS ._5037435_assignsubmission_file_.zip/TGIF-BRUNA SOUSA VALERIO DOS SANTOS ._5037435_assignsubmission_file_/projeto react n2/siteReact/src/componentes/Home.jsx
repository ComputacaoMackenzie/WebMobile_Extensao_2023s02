import React from "react";
import './Global.css';

import HomeComponents1 from "./HomeComponents/HomeComponents1";
import HomeComponents2 from "./HomeComponents/HomeComponents2";

export default function Home() {
   return (
      <>
         <div className="article">
            <HomeComponents1 />
            <br />
            <br />
            <HomeComponents2 />
         </div> 
         
      </>
   );
};