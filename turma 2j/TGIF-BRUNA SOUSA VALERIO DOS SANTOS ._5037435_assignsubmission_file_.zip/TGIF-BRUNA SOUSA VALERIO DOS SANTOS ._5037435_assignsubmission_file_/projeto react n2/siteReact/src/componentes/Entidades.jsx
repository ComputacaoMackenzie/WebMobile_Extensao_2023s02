import React from "react";
import './Global.css';

import EntidadesComponents1 from './EntidadesComponents/EntidadesComponents1'
import EntidadesComponents2 from './EntidadesComponents/EntidadesComponents2';
import EntidadesComponents3 from "./EntidadesComponents/EntidadesComponents3";

export default function Entidades() {
   return (
      <>
         <div className="article">
            <EntidadesComponents1 />
            <br />
            <br />
            <EntidadesComponents2 />
            <br />
            <br />
            <EntidadesComponents3 />
         </div>
      </>
   )
}