import { useEffect, useState } from "react"
import './Api.css';

const Api = () => {
   const [endereco, setEndereco] = useState(null);
 
   useEffect(() => {
     fetch("https://viacep.com.br/ws/01302-907/json/")
       .then((response) => response.json())
       .then((data) => {
         setEndereco(data);
       });
   }, []);

   return (
      <div>
         {endereco && (
            <div className="api-mack">
               <h1>Mackenzie Infos</h1>
               <p>Rua: {endereco.logradouro}</p>
               <p>Bairro: {endereco.bairro}</p>
               <p>CEP: {endereco.cep}</p>
               <p>Localidade: {endereco.localidade}</p>
               <p>UF: {endereco.uf}</p>
            </div>
         )}
     </div>
   )
};

export default Api;