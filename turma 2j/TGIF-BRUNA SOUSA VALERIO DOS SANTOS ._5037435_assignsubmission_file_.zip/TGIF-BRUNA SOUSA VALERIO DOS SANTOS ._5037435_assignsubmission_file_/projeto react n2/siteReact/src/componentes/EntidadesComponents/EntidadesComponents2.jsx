import React from "react";

import joaomendes from './joaomendesjunior.jpg';
import cahl from './cahl.png';
import dacam from './dacam.png';
import './EntidadesComponents.css';

export default function EntidadesComponents2() {
   return (
      <>
         <h2>Centros Acadêmicos</h2>
	      <p>
		      Para cada curso oferecido na faculdade, temos um centro acadêmico. Essas entidades são responsáveis por promover atividades relacionadas à área de estudo específica. Workshops, congressos e projetos acadêmicos são algumas das iniciativas que você pode se envolver, aprimorando seus conhecimentos e conectando-se com profissionais da área.
	      </p>
	      <p>
		      Descubra novas perspectivas! Conheça os Centros Acadêmicos do Mackenzie e mergulhe em sua área de estudo. Explore oportunidades, faça conexões e enriqueça sua jornada acadêmica. Os Centros Acadêmicos estão esperando por você para desvendar o mundo do conhecimento! #MackenzieAcadêmico 📚🌟
	      </p>
	      <h4>Alguns de Nossos Centros Acadêmicos:</h4>
	      <br />
         <br />
	      <div className="fotos">
	         <img src={joaomendes} width={500} alt="Foto Ca" />
	         <img src={cahl} width={500} alt="Foto CAHL" />
	         <img src={dacam} width={500} alt="Foto DACAM" />
	      </div>
      </>
   )
}