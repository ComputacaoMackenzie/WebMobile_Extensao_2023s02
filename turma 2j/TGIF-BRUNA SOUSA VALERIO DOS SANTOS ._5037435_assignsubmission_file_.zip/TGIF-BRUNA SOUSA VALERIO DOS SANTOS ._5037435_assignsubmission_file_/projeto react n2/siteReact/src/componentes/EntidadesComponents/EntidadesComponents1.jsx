import React from "react";

import foto from './fotodce.png';
import grupodce from './grupodce.png';
import './EntidadesComponents.css';

export default function EntidadesComponents1() {
   return (
      <>
         <h1 className="title">Entidades da Faculdade</h1>
         <h2>Conheça nossas Entidades!</h2>
	      <p>
            Bem-vindo (a) calouros! Na nossa faculdade, acreditamos que a experiência acadêmica vai além das salas de aula. É por isso que oferecemos uma variedade de entidades estudantis para enriquecer sua jornada universitária. Conheça as diversas oportunidades disponíveis para você se envolver, criar laços e explorar seus interesses além dos estudos.O papel de uma entidade estudantil é promover debates sobre a realidade dentro e fora da Universidade, no âmbito acadêmico, cultural e político, e de estar em constante contato com o corpo estudantil para se mobilizar por pautas de importância do momento atual.
         </p>
	      <br /> <br />
	      <h3>DCE</h3>
	      <p>
            DCE (diretório central dos estudantes) é a entidade que representa todos os estudantes da Universidade. É através do DCE que o estudante pode garantir com mais força seus direitos, primar pela qualidade do ensino, por mensalidades justas e pelo respeito à classe estudantil.
	      </p>
	      <h4>Foto da Cerimônia de Posse da Gestão DCE 2023/2024</h4>
	      <br />
	      <div className="foto">
            <img src={foto} width={500} alt="Foto DCE" />
            <img src={grupodce} width={500} alt="Grupo DCE" />
	      </div>
      </>
   );
};