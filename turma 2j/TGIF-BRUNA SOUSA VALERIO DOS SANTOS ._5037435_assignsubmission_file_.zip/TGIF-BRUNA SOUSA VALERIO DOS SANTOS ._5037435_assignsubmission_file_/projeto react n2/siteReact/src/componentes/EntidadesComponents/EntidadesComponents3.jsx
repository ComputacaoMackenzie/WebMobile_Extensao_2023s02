import React from "react";

import logo1 from './logo1.png';
import logo2 from './logo2.png';
import logo3 from './logo3.png';
import logo4 from './logo4.png';
import logo5 from './logo5.png';
import './EntidadesComponents.css';

export default function EntidadesComponents3() {
   return (
      <>
         <h2>Atléticas</h2>
	      <p>
            Uma atlética é uma associação formada por alunos de um ou mais cursos de uma faculdade, executada de forma voluntária pelos estudantes, não é um setor oficial com profissionais da instituição trabalhando nele. 
		      A atlética tem como finalidade a integração dos calouros, a socialização dos alunos de diferentes cursos, aumentar a qualidade de vida do estudante por meio da promoção de jogos e campeonatos. Além disso, exerce outras funções também, tais como recepcionar alunos e organizar festas e eventos.
		   </p>
	      <p>
		      Explore seu espírito esportivo! Junte-se às atléticas do Mackenzie e faça parte de uma equipe unida, cheia de energia e diversão. Seja você um atleta experiente ou apenas alguém em busca de novos desafios, as atléticas são o lugar ideal para construir amizades, manter-se saudável e viver experiências incríveis.
	      </p>
	      <p>
		      Venha fazer história nas quadras e campos do Mackenzie! #IstoéMackenzie #EspíritoEsportivo 🏆🏀🏐🏈🏅
	      </p>
	      <br /> 
         <br />
	      <h4>Algumas de nossas atléticas:</h4>
	      <div className="fotos-atleticas">
            <img src={logo1} width={500} alt="Logo Atlética1" />
            <img src={logo2} width={500} alt="Logo Atlética2" />
            <img src={logo3} width={500} alt="Logo Atlética3" />
            <img src={logo4} width={500} alt="Logo Atlética4" />
            <img src={logo5} width={500} alt="Logo Atlética5" />
	      </div>
      </>
   )
}