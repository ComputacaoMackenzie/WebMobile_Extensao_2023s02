import './Main.css';
import mackLogo from './imgs/mackenzielogo.png'

import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

import Eventos from './Eventos';
import Home from './Home';
import Area from './Area';
import Entidades from './Entidades';
import VidaUniversitaria from './VidaUniversitaria';
import Api from './API';

export default function Main() {
   return (
      <>
         <BrowserRouter>
            <header>
               <Link to="/">
                  <img src={mackLogo} alt="Logo da Universidade Mackenzie" width={100} />
               </Link>
               <nav className='menu-header'>
                  <Link to="/Eventos" className='links'>Eventos</Link>
                  <Link to="/Area" className='links'>Áreas</Link>
                  <Link to="/Entidades" className='links'>Entidades</Link>
                  <Link to="/VidaUniversitaria" className='links'>Vida universitária</Link>
               </nav>
            </header>
            <Routes>
               <Route path="/" element={<Home />}/>
               <Route path="/Eventos" element={<Eventos />}/>
               <Route path="/Area" element={<Area />}/>
               <Route path="/Entidades" element={<Entidades />}/>
               <Route path="/VidaUniversitaria" element={<VidaUniversitaria />}/>
            </Routes>
         </BrowserRouter>
         <Api />
         <footer>
            <p>
               Guia para Calouros &copy; 2023 Desenvolvedores: Bruna Sousa Valerio dos Santos & Fernanda de Moraes Brazolin  & Danilo Ferreira Rocha & Yasmin Reis Toledo.
            </p>
         </footer>
      </>
   )
};