import React from "react";

import frat from './frat.png';
import kenzie from './kenzie.png';
import star from './starbucks-mackenzie.png';
import joy from './thejoy.jpeg';
import './VUComponents.css';

export default function VUComponents2() {
   return(
      <>
         <h2>Além dos estudos...</h2>
         <p>
            A vida universitária também se estende além dos limites do campus. Nossa faculdade está
            localizada em uma comunidade dinâmica e empolgante, repleta de oportunidades para explorar. Desde restaurantes e cafés acolhedores até locais de entretenimennto,
            parques e espaços culturais, há sempre algo para fazer fora do campus. Encorajamos você a sair e explorar a rica vida da cidade ao seu redor.
         </p>
         <p>
            Como esses locais a seguir, que ficam em frente a portaria 03 Maria Antonia do mackenzie, estando aqui você não precisa ir longe para achar algum lugar
            que possa se divertir, conhecer novas pessoas e tudo mais que a universidade entrega para seus alunos.
         </p>
         <div id="fotos">
            <img src={star} width={500} alt="Imagem 4" />
            <img src={frat} width={500} alt="Imagem 2" />
            <img src={kenzie} width={500} alt="Imagem 3" />
            <img src={joy}  width={500} alt="Imagem 1" />
        </div>
      </>
   )
}