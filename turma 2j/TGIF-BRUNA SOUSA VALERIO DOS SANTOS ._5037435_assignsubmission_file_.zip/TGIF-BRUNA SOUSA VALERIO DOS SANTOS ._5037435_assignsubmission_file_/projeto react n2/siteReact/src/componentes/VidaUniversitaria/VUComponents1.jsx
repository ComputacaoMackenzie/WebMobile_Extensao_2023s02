import React from "react";

import juca from './juca.png';
import festamack from './festamackenzie.png';
import './VUComponents.css';

export default function VUComponents1() {
   return (
      <>
         <h1 className="title">Vida Universitária</h1>
         <h2>
            Bem-vindo à aba de Vida Universitária! 
            Aqui, você encontrará uma visão abrangente de tudo o que torna a vida na nossa faculdade uma experiência única e emocionante.
         </h2>
         <p>
            Acreditamos que a vida universitária vai além dos estudos acadêmicos. É um período de descoberta pessoal, crescimento intelectual e conexão com uma comunidade diversa. 
            Nesta seção, queremos mostrar a você todas as oportunidades e recursos que tornam a vida universitária tão especial.
         </p>
         <p>
            Ao ingressar na nossa faculdade, você se torna parte de uma vibrante comunidade estudantil, 
            onde há espaço para todos os interesses, paixões e talentos. 
            Quer você seja apaixonado por esportes, arte, música, ciência, empreendedorismo, voluntariado ou qualquer outra área, há atividades e grupos para você se envolver.
         </p>

         <p>
            Na nossa faculdade, a vida universitária é enriquecida por uma ampla gama de clubes e organizações estudantis. Essas entidades oferecem um ponto de encontro para estudantes com interesses comuns, permitindo que você conheça pessoas novas, desenvolva amizades duradouras e se envolva em projetos empolgantes.
            Desde grupos acadêmicos até clubes de hobbies, você encontrará um lugar para chamar de seu e criar memórias inesquecíveis.
         </p>
         <p>
            Além disso, a vida universitária é repleta de eventos e atividades emocionantes. Desde festas e festivais até palestras, workshops e competições, sempre há algo acontecendo no campus. 
            Esses eventos proporcionam uma oportunidade para você se divertir, ampliar seus horizontes, aprender com especialistas em suas áreas e participar da animada atmosfera da vida estudantil.
         </p>
         <br />
         <br />
         <div id="fotos">
            <img src={juca} width={500} alt="festakenzie" />
            <img src={festamack} width={500} alt="festa2" />  
         </div>
      </>
   );
};