import './App.css';

import Main from './componentes/Main';

//importando o react router para usar as rotas
function App() {

  return (
    <>
      <Main />
    </>
  );
};

export default App;
