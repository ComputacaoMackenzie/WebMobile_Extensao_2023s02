import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

// 1-config router
import { createBrowserRouter,RouterProvider } from 'react-router-dom';

import Pagina_princ from './Pagina_princ';
import Formulario from './Formulario';
import Curiosidade from './Curiosidade';
import ErrorPage from './ErrorPage';
import Locais_comer from './Locais_comer';
import Pontos_turisticos from './Pontos_turisticos';
import Mapa from './Mapa';


const router = createBrowserRouter([{
    path: "/",
    element:<App/>,
    
    children:[
    {
      path: "/",
      element:<Pagina_princ/>,
    },
    {
      path: "Formulario",
      element:<Formulario/>,
    },
    {
      path: "Curiosidade",
      element:<Curiosidade/>,
    },
    {
      path: '*',
      element: <ErrorPage />,
    },
    {
      path: "Locais_comer",
      element:<Locais_comer/>,
    },
    {
      path: "Pontos_turisticos",
      element:<Pontos_turisticos/>,
    },
    {
      path: "Mapa",
      element:<Mapa/>,
    },
    
    ]
}
])

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RouterProvider router={router}/>
  </React.StrictMode>,
)
