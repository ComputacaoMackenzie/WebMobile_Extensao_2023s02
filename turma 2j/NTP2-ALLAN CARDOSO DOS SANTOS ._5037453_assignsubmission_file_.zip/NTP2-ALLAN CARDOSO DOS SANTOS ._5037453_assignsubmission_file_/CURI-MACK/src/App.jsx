import React from 'react';
import './App.css';
// 2-apriveitamento de estrutura 
import { Outlet } from 'react-router-dom';
import Navbar from './components/Navbar';

// navegando entre as paginas

function App() {
  return (
    <div className="app">
      <Outlet/>
      <Navbar/>
      
    </div>
  );
}

export default App;
