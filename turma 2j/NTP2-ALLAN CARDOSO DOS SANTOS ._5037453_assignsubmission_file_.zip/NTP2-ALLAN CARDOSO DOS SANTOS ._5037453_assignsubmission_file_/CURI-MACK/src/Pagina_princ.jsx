import React, { useState } from "react";
import './Pagina_princ.css';
import Api from "./api";



export default function Pagina_princ(){
    const [verso1, setVerso1] = useState(true);
    const [verso2, setVerso2] = useState(true);
    const [verso3, setVerso3] = useState(true);
  
    const virarVerso1 = () => {
      setVerso1(!verso1);
    };
  
    const virarVerso2 = () => {
      setVerso2(!verso2);
    };
  
    const virarVerso3 = () => {
      setVerso3(!verso3);
    };
    
    

    return(
        
        <div>
             {/* Este é o início do header */}

            <div className="header">
                <h1 className="cabeca"><span className="span">CU</span>RI <span className="span"> MA</span>CK</h1>
                <ul className="topic">
                    <li> <a href="#curi0">HOME</a></li>
                    <li> <a href="#curi1"> SERVICES</a></li>
                    <li> <a href="#curi2">ABOUT</a></li>
                    <li className="conta"> <a href="#curi3">CONTACT</a></li>
                </ul>
            </div>

             {/* Este é o início do section com o fundo do macck */}
            <div id="curi0" className="section">
                <div className="div_mud">
                    <h1>As melhores<br/>CURIOSIDADES <br/><span className="span">do mackenzie</span></h1>
                    <a href="/curiosidade" type="button">  Confira</a>
                </div>
            </div>
            
             {/* começo das curiosidades*/}
            <div id="curi1" className="section_curi">
                <h1 className="curiosidades">CURIO<span className="span">SI</span>DADES</h1>
                <p className="p">Neste site, você descobrirá locais, áreas que provavelmente você<br/>
                não conhecia dentro da universidade! Visitamos todos os locais<br/>
                que informamos em nosso site, locais testados e aporvados por<br/>
                nós 😁<br/>
                <br/>
                Não perca essas informaeções valiosas que estamos passando<br/>
                para vocês, isso pode te ajudar MUITO na hora de explorar  <br/> a universidade.</p>
                
                <div className="gif">
                    <img src="imagem_teste.jpg" alt="" />
                </div>
            </div>
            

             {/* começo sobre nos */}

            <div id="curi2"  className="section_sobre">
                <h1  className="curiosidades">SOBRE <span className="span">NÓS</span></h1>
                <p className="text_sobre">Olá, somos um quarteto de amigos universitários Allan Cardoso, Paola Polito, Lucas Delsoci e Guilherme Machado, temos de 18 a 19 anos, e atualmente cursamos Sistema de Informação no Campus Higienópolis Mackenzie. Gostamos muito do Campus, e viemos aqui para apresentar alguma das curiosidades de nossa universidade!.</p>
            </div>
            {/* começo contato*/}

            <div id="curi3" className="section_contato">
                <h1 >CONTATO <span className="span">INFO</span></h1>
                <div className="div_contact">
                {verso1 ? (
                    <div className="contact" onClick={() => setVerso1(virarVerso1)}> 
                        <h5>Instagram</h5>
                        <img className="imagem" src="instagram.jpeg" alt="Instagram"/>
                    </div>
                ) : (
                
                    <div className="contact_verso" onClick={() => setVerso1(virarVerso1)}>
                        <a href="https://www.instagram.com/_lucascd/">Instagram: Lucas Cardoso</a>
                        <a href="https://www.instagram.com/paola.polito/">Instagram: Paola Polito</a>
                    </div>
                )}  
            

                {verso2 ? (
                    <div className="contact" onClick={() => setVerso2(virarVerso2)}> 
                        <h5>E-mail</h5>
                        <img className="imagem" src="emai.jpeg" alt="Instagram"/>
                    </div>
                ) : (
                
                    <div className="contact_verso" onClick={() => setVerso2(virarVerso2)}>
                        <a href="/">curimack@hotmail.com</a>
                       
                    </div>
                )}  

                {verso3 ? (
                    <div className="contact" onClick={() => setVerso3(virarVerso3)}> 
                        <h5>Instagram</h5>
                        <img className="imagem" src="instagram.jpeg" alt="Instagram"/> 
                    </div>
                ) : (
                
                    <div className="contact_verso" onClick={() => setVerso3(virarVerso3)}>
                        <a href="https://www.instagram.com/allan.cardosozs/">Instagram: Allan Cardoso</a>
                        <a href="https://www.instagram.com/guigo.machado/">Instagram: Guilherme Machado</a>
                    </div>
                )}  
                </div>
            </div>
            {/* end contato*/}

            {/* começo botao*/} 

            <div className="form">
                
                    <a classnName="botao_FORM" href="/Formulario" type="button"> FORM</a>
                    <a classnName="botao_FORM" href="https://www.youtube.com/watch?v=UBk0SWcF2GM" type="button"> VIDEO</a>
                
            </div>   

            <div className="footer">
                <div className="logo">
                <h5 className="curi_footer">CU<span>RI</span> <span>MA</span>CK</h5>
                <h2 className="h2">Isso é MACKENZIE!</h2>            
                <Api />
                </div>

                <p className="despedida">Copyright © 2023 Allan Cardoso dos Santos, Paola Polito, Lucas Delsoci e Guilherme Machado. All rights reserved</p>          
            </div>     

        </div>
    )
}