import React from "react";
import './Curiosidade.css';
import { Link } from "react-router-dom";
import Api from "./api";

export default function Locais_comer(){
    return(
        <div>
            <header className="cabecalho">
                <h1>As Melhores Curiosidades Sobre O Mackenzie</h1>
                <ul className="topicos">
                    <li><Link className="links" to="/">Home</Link></li>              
                    <li><Link className="links" to="/Locais_comer">Locais Para Comer</Link></li>
                    <li><Link className="links" to="/Pontos_turisticos">Pontos Turisticos</Link></li>
                    <li><Link className="links" to="/Mapa">Mapa Campus</Link></li>
                </ul>
            </header>
            
            <div className='conteudo'>
                <h3>Locais para comer no mackenzie </h3>
                <img src="curiosidades.jpeg" alt="" />
                <div className="info">
                <ul>
                    <li className="lista">Localizado na praça de alimentação do prédio 19 temos o Grazzi, uma ótima opção para algo fit. </li>
                    <li className="lista"> Localizado na praça de alimentação do prédio 45 e ao lado do prédio 25 temos o Borges, querido pelos alunos com diversos salgados e lanches.
</li>
                    <li className="lista">Em frente a saida da consolação no prédio 39 temos o Chapado, uma ótima opção para quem quer almoçar ou até mesmo jantar.</li>
                    <li className="lista">praça de alimentação do prédio 45 temos o famoso Bobs, servindo diversos lanches, sorvetes e milkshake' </li>
                    <li className="lista">Localizado em frente a praça de alimentação do prédio 45 temos o famoso Starbucks, com diversas opções de café, salgados e até bolo. </li>
                    <li className="lista">Localizado na praça de alimentação do prédio 45 temos a famosa Casa do Pão de Queijo, uma ótima opção para quem quer comer aquele pãozinho de queijo. </li>
                   
                </ul>
                </div>

                
            </div>
            <div className="footer">
                <h5 className="curi_footer">CU<span>RI</span> <span>MA</span>CK</h5>
                <h2 className="h2">Isso é MACKENZIE!</h2>            
                
                <Api/>

                <p className="p">Copyright © 2023 Allan Cardoso dos Santos, Paola Polito, Lucas Delsoci e Guilherme Machado. All rights reserved</p>          
            </div>
        </div>
    );

}