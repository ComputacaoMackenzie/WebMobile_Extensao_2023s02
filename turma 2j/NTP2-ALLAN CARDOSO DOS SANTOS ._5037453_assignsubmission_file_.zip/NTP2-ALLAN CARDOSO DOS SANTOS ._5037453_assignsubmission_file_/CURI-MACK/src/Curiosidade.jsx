import React from "react";
import './Curiosidade.css';
import { Routes, Route, Link } from "react-router-dom";
import Mapa from './Mapa';
import Pontos_turisticos from './Pontos_turisticos';
import Locais_comer from './Locais_comer';
import Api from "./api";

export default function Curiosidade(){
    return(
        <div>
            <header className="cabecalho">
                <h1>As Melhores Curiosidades Sobre O Mackenzie</h1>
                <ul className="topicos">
                    <li className="links" to="/">Home</li>              
                    <li><Link className="links" to="/Locais_comer">Locais Para Comer</Link></li>
                    <li><Link className="links" to="/Pontos_turisticos">Pontos Turisticos </Link></li>
                    <li> <Link className="links" to="/Mapa">Mapa Campus </Link></li>
                </ul>
            </header>
            <div className='conteudo'>
                <h3>Curiosidades que você precisa saber do mackenzie !!!</h3>
                <img src="curiosidades.jpeg" alt="" />
                <div className="info">
                <ul>
                    <li className="lista">O campos higienopolis mackenzie fornece internet wifi de graça</li>
                    <li className="lista"> Internet do Campus, espaços para descanso como os Diretorios Academicos (DACAM,
DAFAM, DAEG, DCE, CAHL entre muitos outros)

</li>
                    <li className="lista">Uma rua inteira de barzinhos sensacionais para conhecer novas pessoas...</li>
                    <li className="lista">Temos parceria com a microsoft,na qual usamos o e-mail institucional, acessamos um
armazenamento gigante em nuvem, podemos baixar o Pacote Office e muito mais. </li>
                    <li className="lista">Também podemos usar o LinkedIn Premium. </li>
                    <li className="lista">Além da localização, com acesso fácil a ônibus, metrô e estacionamentos diversos,
o Mackenzie dispõe de um bicicletário que fica na entrada da Rua Itambé, 143. </li>
                    <li className="lista">A existencia de um laboratorio da apple mais conhecido como Lab Apple Developer Academy</li>
                    <li className="lista">O Mackenzie realiza diversas feiras de estágio para os estudantes de todos os cursos com diversas oportuinidades.</li>
                   
                </ul>
                </div>

                
            </div>
            <div className="footer">
                <h5 className="curi_footer">CU<span>RI</span> <span>MA</span>CK</h5>
                <h2 className="h2">Isso é MACKENZIE!</h2>            
                
                <Api/>

                <p className="p">Copyright © 2023 Allan Cardoso dos Santos, Paola Polito, Lucas Delsoci e Guilherme Machado. All rights reserved</p>          
            </div>
            <Routes>
                <Route path="/Locais_comer" element={<Locais_comer />} />
                <Route path="/Pontos_turisticos" element={<Pontos_turisticos />} />
                <Route path="/Mapa" element={<Mapa />} />
            </Routes>
            
        </div>
    );
}
