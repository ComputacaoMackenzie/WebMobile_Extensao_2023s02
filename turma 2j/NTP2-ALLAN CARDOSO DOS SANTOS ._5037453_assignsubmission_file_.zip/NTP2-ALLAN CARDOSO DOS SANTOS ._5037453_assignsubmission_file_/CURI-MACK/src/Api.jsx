import { useEffect, useState } from "react"
import './Api.css';


const Api = () => {
   const [fac, setFac] = useState();
 
   useEffect(() => {
     fetch("https://viacep.com.br/ws/01302-907/json/")
       .then((response) => response.json())
       .then((data) => {
         setFac(data);
       });
   }, []);

   return (
      <div className="div-api">
         {fac && (
            <div className="Api-curi">
               <h1>Curi Mack</h1>
               <p>Rua: {fac.logradouro}</p>
               <p>Bairro: {fac.bairro}</p>
               <p>CEP: {fac.cep}</p>
               <p>Localidade: {fac.localidade}</p>
             
            </div>
         )}
     </div>
   )
};

export default Api;