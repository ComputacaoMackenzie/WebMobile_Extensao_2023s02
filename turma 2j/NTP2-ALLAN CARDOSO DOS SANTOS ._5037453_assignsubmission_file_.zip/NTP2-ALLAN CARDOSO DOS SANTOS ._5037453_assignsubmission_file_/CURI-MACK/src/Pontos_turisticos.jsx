import React from "react";
import './Curiosidade.css';
import { Link } from "react-router-dom";
import Api from "./api";

export default function Pontos_turisticos(){
    return(
        <div>
             <header className="cabecalho">
                <h1>As Melhores Curiosidades Sobre O Mackenzie</h1>
                <ul className="topicos">
                    <li><Link className="links" to="/">Home</Link></li>              
                    <li><Link className="links" to="/Locais_comer">Locais Para Comer</Link></li>
                    <li className="links">Pontos Turisticos</li>
                    {/* Corrigindo o link para o Mapa */}
                    <li> <Link className="links" to="/Mapa">Mapa Campus</Link></li>
                </ul>
            </header>
            

            <div className='conteudo'>
                <h3>Pontos Turisticos que você precisa conhecer: </h3>
                <img src="curiosidades.jpeg" alt="" />
                <div className="info">
                <ul>
                    <li className="lista">O bosque, que fica em um lugar mais reservado do campus é um refúgio para muitos alunos que querem estudar em um ambiente diferente, se distrair, ficar com os amigos ou respirar um ar mais puro. É um lugar repleto de árvores, plantas e flores, que te traz a sensação de ter saído de São Paulo por um momento. </li>
                    <li className="lista"> Tombado como patrimônio histórico do Mackenzie, o centro histórico foi o primeiro prédio construído do campus Higienópolis e sua arquitetura nunca foi alterada. O prédio funciona como um museu e entrar nele te proporciona uma viagem no tempo.</li>
                    <li className="lista"> Biblioteca George Alexander,Também é conhecida como biblioteca principal, biblioteca central e biblioteca do Harry Potter. Esse último nome ficou famoso pois a arquitetura antiga, a iluminação baixa e o chão amadeirado remetem ao mundo bruxo.</li>
                    <li className="lista">Auditório Ruy Barbosa, É o maior auditório do campus Higienópolis e sede de eventos como formaturas, shows e palestras. O ambiente é agradável estruturalmente e sua estética lembra a de um grande Teatro, como também é conhecido. </li>
                    
                </ul>
                </div>

                
            </div>
            <div className="footer">
                <h5 className="curi_footer">CU<span>RI</span> <span>MA</span>CK</h5>
                <h2 className="h2">Isso é MACKENZIE!</h2>            
                <Api/>

                <p className="p">Copyright © 2023 Allan Cardoso dos Santos, Paola Polito, Lucas Delsoci e Guilherme Machado. All rights reserved</p>          
            </div>
        </div>
    );

}