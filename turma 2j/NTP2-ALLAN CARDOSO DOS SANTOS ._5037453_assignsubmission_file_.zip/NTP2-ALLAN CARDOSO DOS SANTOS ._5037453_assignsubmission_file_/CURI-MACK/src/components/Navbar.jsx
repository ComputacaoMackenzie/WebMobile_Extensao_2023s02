import React from "react";
import { Link } from "react-router-dom";

const Navbar = () =>{
    return(
        <nav>
            <Link to="/">Pagina_princ</Link>
            <Link to="/">Curiosidades</Link>
            <Link to="/">Formulario</Link>
        </nav>
    )
}
export default Navbar;