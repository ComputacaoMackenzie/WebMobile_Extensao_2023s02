import {React, useState } from 'react';

import './Formulario.css';




export default function Formulario (){
    return(
        <div className="geral">
            <div>
                <img className="img" src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/Mackenzie_M.svg/1200px-Mackenzie_M.svg.png"/>
            </div >
            <div className="formulario">
                <h1 className='h1'>FORM
                    <span className='ula'>ULÁ</span>
                    RIO</h1>
                <div id="nome" className="nome">
                    <label class="topicos">Nome:</label>
                    
                    <input className= "text" type="text" id="nome" name="nome" />
                </div>
                <div id="sobrenome" className="nome">
                    <label class="topicos">Sobrenome:</label>
                    <input className= "text" type="text" id="nome" name="nome" />
                </div>
                <div id="email" className="nome">
                    <label class="topicos">Email:</label>
                    <input className= "text" type="text" id="nome" name="nome" />
                </div>
                <div id="telefone" className="nome">
                    <label class="topicos">Telefone:</label>
                    <input className= "text" type="text" id="nome" name="nome" />
                </div>
                <div id="idade" className="nome">
                    <label class="">Idade:</label>
                    <select className="text" name="email" id="ema">
                        <option value=""> Selecione </option>
                        <option value=""> Menor de 18 anos </option>
                        <option value=""> 18 a 24 anos </option>
                        <option value=""> 25 a 35 anos </option>
                        <option value=""> Maior de 35 anos </option>
                    </select>
                </div>
                <div id="sexo" className="nome">
                    <label class="topicos">Sexo:</label>
                    <ul className="ordenada">
                        <li>
                            <input type="radio" />
                            <label htmlFor=""> Masculino</label>
                        </li>
                        <li>
                            <input type="radio" />
                            <label htmlFor=""> Feminino</label>
                        </li>
                        <li>
                            <input type="radio" />
                            <label htmlFor=""> Prefiro não dizer</label>
                        </li>
                    </ul>
                </div>
                <div id="sugestao" className="nome">
                <label className="topicos">Sugestão:</label>
                <input className= "sujest" type="text" id="nome" name="nome"/>
                </div>
                <button className='botao' href="" >Clique</button>
            </div>
        </div>
    )
}
