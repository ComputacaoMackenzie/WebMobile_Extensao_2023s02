import React from "react";
import './Mapa.css';
import { Link } from "react-router-dom";
import Api from "./api";

export default function Mapa(){
    return(
        <div>
             <header className="cabecalho">
                <h1>As Melhores Curiosidades Sobre O Mackenzie</h1>
                <ul className="topicos">
                    <li><Link className="links" to="/">Home</Link></li>              
                    <li><Link className="links" to="/Locais_comer">Locais Para Comer</Link></li>
                    <li><Link className="links" to="/Pontos_turisticos">Pontos Turisticos </Link></li>
                    <li className="links" >Mapa Campus</li>
                </ul>
            </header>
            

            <div className='conteudo2'>
                <h1>Mapa do Mackenzie campus Higienopolis!!!</h1>
                <img className="mapa_mack" src="mapa_mack.jpg" alt="" />
                
            </div>

                
           
            <div className="footer">
                <h5 className="curi_footer">CU<span>RI</span> <span>MA</span>CK</h5>
                <h2 className="h2">Isso é MACKENZIE!</h2>            
                <Api/>

                <p className="p">Copyright © 2023 Allan Cardoso dos Santos, Paola Polito, Lucas Delsoci e Guilherme Machado. All rights reserved</p>          
            </div>
        </div>
    );

}