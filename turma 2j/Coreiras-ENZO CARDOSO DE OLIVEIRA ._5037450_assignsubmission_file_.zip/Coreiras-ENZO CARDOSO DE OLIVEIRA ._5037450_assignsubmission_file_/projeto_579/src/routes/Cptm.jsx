import React, {useState} from "react";
import { Link } from "react-router-dom";
import imagemRubi from './imagens/rubi.jpg';
import imagemDiamante from './imagens/diamante.jpg';
import imagemEsmeralda from './imagens/esmeralda.jpg';
import imagemTurquesa from './imagens/turquesa.jpg';
import imagemCoral from './imagens/coral.jpg';
import imagemSafira from './imagens/saphira.jpg';
import imagemJade from './imagens/jade.jpg';

const MenuItem = ({ label, imagem, onClick }) => (
    <li onClick={onClick}>
      <a href="#">{label}</a>
    </li>
  );

const Cptm = () => {
    const [imagemAtual, setImagemAtual] = useState(null);

  const handleLinkClick = (imagem) => {
    setImagemAtual(imagem);
  };
    return (
        <>
            <header>
        <table border="0">
            <tr>
                <td width="700">
            <Link to="/"><h1><img src="imagens/logo.png" className="logo" /></h1></Link>
        </td>
        <td align="right" width="600">
        <p>
        	<ul class="cabecalho">
        		<li><Link to="/" class="paragrafo">HOME</Link></li>
        		<li><Link to="/Mapa" class="paragrafo">MAPA METRÔ & CPTM</Link></li>
                <li><Link to="/Dicas" class="paragrafo">DICAS</Link></li>
        	</ul>
        </p>
        </td>
        </tr>
        </table>
    </header>
        <div class="lista-Onibus2">
            <table border="0" width="100%">
                <tr>
                    <td width="50%" align="center">
                       <strong><p class="p-cptm">CPTM</p></strong>
                    </td>
                    <td align="center">
                    <Link to="/Cptm"><img src="imagens/cptm2.png" /></Link>
                    </td>
                </tr>
            </table>
            </div>
    <nav className="App-nav">
        <div className="lista-Onibus10">
          <h4 className="titulo-metro">Escolha uma linha para ver com detalhes.</h4>
          <ul>
            <MenuItem className="inclinado"
              label="LINHA 07 - RUBI"
              imagem={imagemRubi}
              onClick={(e) => {
                e.preventDefault(); handleLinkClick(imagemRubi)}}
            /><br /><br /><br />
            <MenuItem className="inclinado"
              label="LINHA 08 - DIAMANTE"
              imagem={imagemDiamante}
              onClick={(e) => {
                e.preventDefault(); handleLinkClick(imagemDiamante)}}
            /><br /><br /><br />
            <MenuItem
              label="LINHA 09 - ESMERALDA"
              imagem={imagemEsmeralda}
              onClick={(e) => {
                e.preventDefault(); handleLinkClick(imagemEsmeralda)}}
            /><br /><br /><br />
            <MenuItem
              label="LINHA 10 - TURQUESA"
              imagem={imagemTurquesa}
              onClick={(e) => {
                e.preventDefault(); handleLinkClick(imagemTurquesa)}}
            /><br /><br /><br />
            <MenuItem
              label="LINHA 11 - CORAL"
              imagem={imagemCoral}
              onClick={(e) => {
                e.preventDefault(); handleLinkClick(imagemCoral)}}
            /><br /><br /><br />
            <MenuItem
              label="LINHA 12 - SAFIRA"
              imagem={imagemSafira}
              onClick={(e) => {
                e.preventDefault(); handleLinkClick(imagemSafira)}}
            /><br /><br /><br />
            <MenuItem
              label="LINHA 13 - JADE"
              imagem={imagemJade}
              onClick={(e) => {
                e.preventDefault(); handleLinkClick(imagemJade)}}
            />
          </ul>
          </div>
        <div>
        {imagemAtual && (
          <div>
            <img src={imagemAtual} alt="Imagem Atual" className="imagem-Atual"/>
          </div>
        )}
        </div>
        </nav>
    <br /><br />
    <footer>
                <br />
                <table width="70%" align="center">
                    <tr>
                        <td align="left">
                            <img src="imagens/logo.png" className="logo-footer" alt="Logo" />
                        </td>
                        <td>
                            <p></p>
                            <p><a href="dicas.html"></a></p>
                        </td>
                    </tr>
                    <tr>
                        <td align="left">
                            <p className="p-footer">O MackTrilhos é a mais nova tecnologia para os estudantes mackenzistas conseguirem,<br /> de forma eficiente e organizada, chegarem à faculdade.</p>
                        </td>
                        <td>
                        <iframe title="Google Map" src="https://storage.googleapis.com/maps-solutions-tug5vj7m1c/commutes/3f2x/commutes.html"
                width="200" height="200" align='center'>
            </iframe>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p>&copy; 2023 MackTrilhos. Todos os direitos reservados.</p>
                        </td>
                    </tr>
                </table>
            </footer>
        </>
    )
}

export default Cptm;