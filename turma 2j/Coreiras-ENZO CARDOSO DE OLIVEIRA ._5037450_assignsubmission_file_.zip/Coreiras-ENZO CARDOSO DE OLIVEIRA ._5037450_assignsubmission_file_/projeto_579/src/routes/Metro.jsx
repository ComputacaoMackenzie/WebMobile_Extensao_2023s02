import React, {useState} from "react";
import { Link } from "react-router-dom";
import imagemAzul from './imagens/azul.jpg';
import imagemVerde from './imagens/verde.jpg';
import imagemVermelha from './imagens/vermelha.jpg';
import imagemAmarela from './imagens/amarela.jpg';
import imagemLilas from './imagens/lilás.jpg';
import imagemPrata from './imagens/prata.jpg';
import iconeazul from './imagens/iconeazul.jpg';
import { isDOMComponent } from "react-dom/test-utils";

const MenuItem = ({ label, imagem, onClick }) => (
    <li onClick={onClick}>
      <a href="#">{label}</a>
    </li>
  );

const Metro = () => {
    const [imagemAtual, setImagemAtual] = useState(null);

  const handleLinkClick = (imagem) => {
    setImagemAtual(imagem);
  };

    return (
        <>
    <header>
        <table border="0">
            <tr>
                <td width="700">
            <Link to="/"><h1><img src="imagens/logo.png" className="logo" /></h1></Link>
        </td>
        <td align="right" width="600">
        <p>
        	<ul class="cabecalho">
        		<li><Link to="/" class="paragrafo">HOME</Link></li>
        		<li><Link to="/Mapa" class="paragrafo">MAPA METRÔ & CPTM</Link></li>
                <li><Link to="/Dicas" class="paragrafo">DICAS</Link></li>
        	</ul>
        </p>
        </td>
        </tr>
        </table>
    </header>
    <div class="lista-Onibus2">
            <table border="0" width="100%">
                <tr>
                    <td width="50%" align="center">
                       <strong><p class="p-cptm">METRÔ</p></strong>
                      </td>
                    <td align="center">
                    <Link to="/Metro"><img src="imagens/metro.png" width={200}/></Link>
                    </td>
                </tr>
            </table>
            </div>
      <nav className="App-nav">
        <div className="lista-Onibus10">
          <h4 className="titulo-metro">Escolha uma linha para ver com detalhes.</h4>
          <ul>
            <MenuItem
              label="LINHA 01 - AZUL"
              imagem={imagemAzul}
              onClick={(e) => {
                e.preventDefault(); 
                handleLinkClick(imagemAzul);
              }}
            /><br /><br /><br />
            <MenuItem
              label="LINHA 02 - VERDE"
              imagem={imagemVerde}
              onClick={(e) => {
                e.preventDefault(); 
                handleLinkClick(imagemVerde);}}
            /><br /><br /><br />
            <MenuItem
              label="LINHA 03 - VERMELHA"
              imagem={imagemVermelha}
              onClick={(e) => {
                e.preventDefault(); handleLinkClick(imagemVermelha)}}
            /><br /><br /><br />
            <MenuItem
              label="LINHA 04 - AMARELA"
              imagem={imagemAmarela}
              onClick={(e) => {
                e.preventDefault(); handleLinkClick(imagemAmarela)}}
            /><br /><br /><br />
            <MenuItem
              label="LINHA 05 - LILÁS"
              imagem={imagemLilas}
              onClick={(e) => {
                e.preventDefault(); handleLinkClick(imagemLilas)}}
            /><br /><br /><br />
            <MenuItem
              label="LINHA 15 - PRATA"
              imagem={imagemPrata}
              onClick={(e) => {
                e.preventDefault(); handleLinkClick(imagemPrata)}}
            />
          </ul>
          </div>
        <div>
        {imagemAtual && (
          <div>
            <img src={imagemAtual} alt="Imagem Atual" className="imagem-Atual"/>
          </div>
        )}
        </div>
        </nav>
    <br /><br />
    <footer>
                <br />
                <table width="70%" align="center">
                    <tr>
                        <td align="left">
                            <img src="imagens/logo.png" className="logo-footer" alt="Logo" />
                        </td>
                        <td>
                            <p></p>
                            <p><a href="dicas.html"></a></p>
                        </td>
                    </tr>
                    <tr>
                        <td align="left">
                            <p className="p-footer">O MackTrilhos é a mais nova tecnologia para os estudantes mackenzistas conseguirem,<br /> de forma eficiente e organizada, chegarem à faculdade.</p>
                        </td>
                        <td>
                        <iframe title="Google Map" src="https://storage.googleapis.com/maps-solutions-tug5vj7m1c/commutes/3f2x/commutes.html"
                width="200" height="200" align='center'>
            </iframe>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p>&copy; 2023 MackTrilhos. Todos os direitos reservados.</p>
                        </td>
                    </tr>
                </table>
            </footer>
        </>
    )
}


export default Metro