import React from "react";
import { Link } from "react-router-dom";

const Mapa = () => {
    return (
        <>
        <header>
        <table border="0">
            <tr>
                <td width="700">
                <Link to="/"><h1><img src="imagens/logo.png" className="logo" /></h1></Link>
        </td>
        <td align="right" width="600">
        <p>
        	<ul class="cabecalho">
        		<li><Link to="/" class="paragrafo">HOME</Link></li>
        		<li><Link to="/Mapa" class="paragrafo">MAPA METRÔ & CPTM</Link></li>
                <li><Link to="/Dicas" class="paragrafo">DICAS</Link></li>
        	</ul>
        </p>
        </td>
        </tr>
        </table>
    </header>
    <br /><br /> 
    <div align="center" class="">
                <img src="imagens/mapaMetro.jpg" width="1000px" /> 
    </div>
    <br /><br />
    <footer>
                <br />
                <table width="70%" align="center">
                    <tr>
                        <td align="left">
                            <img src="imagens/logo.png" className="logo-footer" alt="Logo" />
                        </td>
                        <td>
                            <p></p>
                            <p><a href="dicas.html"></a></p>
                        </td>
                    </tr>
                    <tr>
                        <td align="left">
                            <p className="p-footer">O MackTrilhos é a mais nova tecnologia para os estudantes mackenzistas conseguirem,<br /> de forma eficiente e organizada, chegarem à faculdade.</p>
                        </td>
                        <td>
                        <iframe title="Google Map" src="https://storage.googleapis.com/maps-solutions-tug5vj7m1c/commutes/3f2x/commutes.html"
                width="200" height="200" align='center'>
            </iframe>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p>&copy; 2023 MackTrilhos. Todos os direitos reservados.</p>
                        </td>
                    </tr>
                </table>
            </footer>
        </>
    )
}

export default Mapa;