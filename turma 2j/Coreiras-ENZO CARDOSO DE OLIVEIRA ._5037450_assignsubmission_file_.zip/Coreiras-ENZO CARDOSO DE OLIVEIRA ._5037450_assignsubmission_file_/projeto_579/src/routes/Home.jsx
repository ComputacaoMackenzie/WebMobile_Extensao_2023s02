import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

const Home = () => {
    const [data, setData] = useState(null);
    const [error, setError] = useState(null);
  
    useEffect(() => {
      const apiUrl = "https://storage.googleapis.com/maps-solutions-tug5vj7m1c/commutes/3f2x/commutes.html";
  
      fetch(apiUrl)
        .then(response => {
          if (!response.ok) {
            throw new Error(`Failed to fetch: ${response.status} ${response.statusText}`);
          }
          return response.text();
        })
        .then(html => {
          setData({ html });
          setError(null);
        })
        .catch(err => {
          console.error("Error fetching data:", err);
          setError("Failed to fetch data. Please try again.");
        });
    }, []);

    return (
        <>
            <header>
                <table border="0">
                    <tr>
                        <td width="700">
                            <Link to="/"><h1><img src="imagens/logo.png" className="logo" alt="Logo" /></h1></Link>
                        </td>
                        <td align="right" width="600">
                            <p>
                                <ul className="cabecalho">
                                    <li><Link to='/' className="paragrafo">HOME</Link></li>
                                    <li><Link to='/Mapa' className="paragrafo">MAPA METRÔ & CPTM</Link></li>
                                    <li><Link to="/Dicas" className="paragrafo">DICAS</Link></li>
                                </ul>
                            </p>
                        </td>
                    </tr>
                </table>
            </header>
            <div className="imagemHome">
                <table width="900" align="center">
                    <tr>
                        <td align="center">
                            <h1 align="left" className="titulo1">O MackTrilhos</h1>
                            <h1 className="h1Boneco">está presente para uma ajuda diária aos nossos estudantes, visando<br /> a praticidade e a organização para uma <br /> rotina melhor.</h1>
                        </td>
                        <td>
                            <img src="imagens/boneco.png" alt="Boneco" />
                        </td>
                    </tr>
                </table>
            </div>
            <main>
                <section className="lista-Onibus">
                    <h1 align="center">Tipos de locomoção</h1>
                    <br /><br />
                    <Link to="/Cptm"><img src="imagens/cptm.png" className="cptm" alt="CPTM" /></Link>
                    <Link to="/Metro"><img src="imagens/metro.png" className="metro" alt="Metrô" /></Link>
                </section>
            </main>
            <br /><br /> 
            <section align='center'>
                <h3>Procure seu destino e escolha o melhor caminho!</h3>
            <iframe title="Google Map" src="https://storage.googleapis.com/maps-solutions-tug5vj7m1c/commutes/3f2x/commutes.html"
                width="800" height="600" align='center'>
            </iframe>
            </section>
            <br /><br />
            <table align="center" className="foto1" width="600">
                <tr>
                    <td align="center">
                        <h1 align="center" className="texto-Foto">BAIXE NOSSO APP</h1>
                        <img src="imagens/frame.png" align="center" width="100" alt="Frame" />
                    </td>
                </tr>
            </table>
            <br /><br />
            <footer>
                <br />
                <table width="70%" align="center">
                    <tr>
                        <td align="left">
                            <img src="imagens/logo.png" className="logo-footer" alt="Logo" />
                        </td>
                        <td>
                            <p></p>
                            <p><a href="dicas.html"></a></p>
                        </td>
                    </tr>
                    <tr>
                        <td align="left">
                            <p className="p-footer">O MackTrilhos é a mais nova tecnologia para os estudantes mackenzistas conseguirem,<br /> de forma eficiente e organizada, chegarem à faculdade.</p>
                        </td>
                        <td>
                        <iframe title="Google Map" src="https://storage.googleapis.com/maps-solutions-tug5vj7m1c/commutes/3f2x/commutes.html"
                width="200" height="200" align='center'>
            </iframe>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p>&copy; 2023 MackTrilhos. Todos os direitos reservados.</p>
                        </td>
                    </tr>
                </table>
            </footer>
        </>
    );
}

export default Home;
