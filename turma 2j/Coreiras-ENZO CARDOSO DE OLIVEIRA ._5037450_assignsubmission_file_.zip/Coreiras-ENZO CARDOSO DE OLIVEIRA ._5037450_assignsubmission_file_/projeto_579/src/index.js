import React from 'react';
import App from './App';
import ReactDOM from 'react-dom';
import './index.css';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import reportWebVitals from './reportWebVitals';

import Home from './routes/Home';
import Mapa from './routes/Mapa';
import Dicas from './routes/Dicas';
import Metro from './routes/Metro';
import Cptm from './routes/Cptm';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Home />,
  },
  {
    path: '/Mapa',
    element: <Mapa />,
  },
  {
    path: '/Dicas',
    element: <Dicas />
  },
  {
    path: '/Metro',
    element: <Metro />
  },
  {
    path: '/Cptm',
    element: <Cptm />
  },
]);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);

export default reportWebVitals;
