import React, { useState, useEffect } from "react";
import Weather from "../components/Weather";

const Home = () => {
  const [mensagem, setMensagem] = useState("");

  useEffect(() => {
    const attDia = () => {
      const horaAtual = new Date().getUTCHours() - 3;

      if (horaAtual >= 5 && horaAtual < 12) {
        setMensagem("Bom dia ");
      } else if (horaAtual >= 12 && horaAtual < 18) {
        setMensagem("Boa tarde ");
      } else {
        setMensagem("Boa noite ");
      }
    };

    attDia();
    const interval = setInterval(attDia, 60000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="homepage">
      <h1>{mensagem} aluno da FCI</h1>
      <h2>Confira o clima do Mackenzie Higienópolis agora!</h2>
      <Weather />

      <div className="wiki">
        <h3 className="wiki-title">FCI Wiki</h3>
        <div className="wiki-text">
          <p>
            No vasto e dinâmico universo da computação e informática, encontrar
            recursos confiáveis e relevantes para auxiliar estudantes pode ser
            uma tarefa desafiadora. Felizmente, o FCI Wiki surge como um farol
            nesse oceano de informações, oferecendo um refúgio digital completo
            e indispensável para estudantes que buscam se aprofundar nesse campo
            fascinante.
          </p>
          <p>
            O FCI Wiki é muito mais do que um simples site; ele é uma plataforma
            de aprendizado abrangente, meticulosamente projetada para atender às
            necessidades de estudantes de todos os níveis de conhecimento em
            computação e informática.
          </p>
        </div>
      </div>

      <div className="wiki">
        <h3 className="wiki-title">Desenvolvimento do FCI Wiki</h3>
        <div className="wiki-text">
          <p>
            Se você é um estudante universitário que busca a excelência nos
            estudos de computação e informática, o TechApoio é o seu melhor
            aliado. Este site foi projetado para atender às suas necessidades
            acadêmicas de maneira abrangente e eficaz.
          </p>
          <p>
            Com uma ampla gama de recursos educacionais, desde tutoriais
            detalhados até exercícios desafiadores. o FCI Wiki torna o
            aprendizado mais envolvente e eficiente. Encontre informações
            confiáveis e atualizadas sobre todos os tópicos relevantes em
            computação e informática e acesse o conteúdo quando e onde quiser,
            adaptando o aprendizado ao seu próprio ritmo.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Home;
