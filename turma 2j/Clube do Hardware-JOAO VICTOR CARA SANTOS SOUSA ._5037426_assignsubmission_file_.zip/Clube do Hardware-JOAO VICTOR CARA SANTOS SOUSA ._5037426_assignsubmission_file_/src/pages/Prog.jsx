import leandro from "../img/leandro.png";
import ale from "../img/alexandre.png";
import foto from "../img/logo-ps.png";
import psUm from "../pdf/psUm.pdf";
import psDois from "../pdf/psDois.pdf";
import psTres from "../pdf/psTres.pdf";
import psQuatro from "../pdf/psQuatro.pdf";

export default function Prog() {
  return (
    <div className="prog">
      <div class="foto" style={{ backgroundImage: `url(${foto})` }}>
        <h1 class="text-img"> Programação de Sistemas I </h1>
        <p class="text-img m">
          {" "}
          Fundamentos da linguagem Java e a forma como os conceitos da
          Orientação à Objetos são implementados nela.{" "}
        </p>
        <p class="text-img"> Dificuldade da matéria: ★★★★☆ </p>
      </div>

      <div class="container">
        <div class="resume">
          <h1 class="resume-title"> Conteúdo </h1>
          <p class="resume-text">
            {" "}
            Potencializando a Tecnologia para o Mundo Moderno A programação de
            sistemas desempenha um papel fundamental na infraestrutura
            tecnológica que impulsiona o nosso mundo moderno. Ela se refere ao
            processo de criação de software de baixo nível e sistemas de
            computador que são essenciais para o funcionamento de dispositivos,
            servidores, sistemas operacionais e muito mais. Em outras palavras,
            é a base invisível que sustenta muitas das tecnologias que usamos
            diariamente.{" "}
          </p>
          <h1 class="resume-subtitle">
            {" "}
            O que faz um programador de sistemas?{" "}
          </h1>
          <div class="resume-subtext">
            <p>
              {" "}
              <strong> - Desenvolvimento de Drivers: </strong> Criar os
              controladores de dispositivos que permitem a comunicação entre o
              hardware e o software. Isso inclui drivers de impressoras, placas
              gráficas, discos rígidos e outros periféricos.{" "}
            </p>
            <p>
              {" "}
              <strong> - Sistemas Operacionais: </strong> Projetar e contribuir
              para o desenvolvimento de sistemas operacionais, como Windows,
              Linux e macOS, que são a base de todos os aplicativos e serviços
              que usamos.{" "}
            </p>
            <p>
              {" "}
              <strong> - Segurança: </strong> Implementar medidas de segurança
              robustas para proteger sistemas contra ameaçascibernéticas,
              garantindo que dados confidenciais permaneçam seguros.{" "}
            </p>
            <p>
              {" "}
              <strong> - Otimização de Desempenho: </strong> Aprimorar a
              eficiência e o desempenho dos sistemas para garantir que eles
              funcionem de maneira rápida.{" "}
            </p>
            <p>
              {" "}
              <strong> - Sistemas Embarcados: </strong> Trabalhar em sistemas
              incorporados em dispositivos como carros, eletrodomésticos
              inteligentes e equipamentos médicos, tornando-os mais inteligentes
              e eficientes.{" "}
            </p>
            <p>
              {" "}
              <strong> - Manutenção e Atualização: </strong> Realizar
              atualizações regulares, correções de bugs e melhorias nos sistemas
              para garantir sua relevância contínua.{" "}
            </p>
          </div>
        </div>
        <div class="information">
          <h1 class="info-h1"> Informações </h1>
          <div class="info-plano">
            <li>
              <a href={psUm} target="_blank" download>
                {" "}
                Plano de aula 1{" "}
              </a>
            </li>
            <li>
              <a href={psDois} target="_blank" download>
                {" "}
                Programação das Aulas 1{" "}
              </a>
            </li>
            <li>
              <a href={psTres} target="_blank" download>
                {" "}
                Plano de Ensino 2{" "}
              </a>
            </li>
            <li>
              <a href={psQuatro} target="_blank" download>
                {" "}
                Programação das Aulas 2{" "}
              </a>
            </li>
          </div>
          <div class="info-align">
            <div class="info-alexandre">
              <img src={ale} alt="alexandre" />
              <div class="info-text-alexandre">
                <p> Prof. Alexandre dos Santos Mignon </p>
                <p> Contato: alexandre.mignon@mackenzie.br</p>
                <a
                  href="http://lattes.cnpq.br/6850069426509336"
                  target="_blank"
                >
                  {" "}
                  Currículo{" "}
                </a>
              </div>
            </div>
            <div class="info-leandro">
              <img src={leandro} alt="alexandre" />
              <div class="info-text-leandro">
                <p> Prof. Leandro Pupo Natale </p>
                <p> Contato: leandro.natale@mackenzie.br </p>
                <a
                  href="http://lattes.cnpq.br/1246484246442782"
                  target="_blank"
                >
                  {" "}
                  Currículo{" "}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
