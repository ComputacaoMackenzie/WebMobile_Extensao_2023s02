import joaquim from "../img/joaquim.png";
import ale from "../img/alexandre.png";
import foto from "../img/logo-ps.png";
import web from "../pdf/web.pdf";
import webDois from "../pdf/webDois.pdf";

export default function Web() {
  return (
    <div className="prog">
      <div class="foto" style={{ backgroundImage: `url(${foto})` }}>
        <h1 class="text-img"> Web Mobile</h1>
        <p class="text-img m">
          {" "}
          Fundamentos da linguagem HTML, CSS e JavaScript e como são
          implementados na construção de sites.{" "}
        </p>
        <p class="text-img"> Dificuldade da matéria: ★★★☆☆ </p>
      </div>

      <div class="container">
        <div class="resume">
          <h1 class="resume-title"> Conteúdo </h1>
          <p class="resume-text">
            {" "}
            O desenvolvimento web mobile é uma disciplina na área de tecnologia
            que se concentra na criação de aplicativos e sites otimizados para
            dispositivos móveis, como smartphones e tablets. Envolve o uso de
            linguagens de programação, frameworks e tecnologias específicas para
            criar interfaces de usuário responsivas e funcionais que se adaptam
            perfeitamente às telas menores desses dispositivos.{" "}
          </p>
          <h1 class="resume-subtitle">
            {" "}
            O que faz um programador de Web Mobile?{" "}
          </h1>
          <div class="resume-subtext">
            <p>
              {" "}
              <strong> - Desenvolvimento de Aplicativos e Sites: </strong>{" "}
              Programadores de web mobile escrevem o código necessário para
              criar aplicativos móveis e sites responsivos que funcionem bem em
              dispositivos móveis. Eles utilizam linguagens de programação como
              HTML, CSS, JavaScript e muitas vezes frameworks específicos para a
              plataforma móvel, como React Native, Flutter ou Xamarin.{" "}
            </p>

            <p>
              {" "}
              <strong> - Design Responsivo: </strong> Garantir que a interface
              do usuário se adapte perfeitamente a diferentes tamanhos de tela e
              dispositivos é fundamental. Isso envolve a criação de layouts
              flexíveis e a aplicação de técnicas de design responsivo para
              oferecer a melhor experiência de usuário em dispositivos móveis.
            </p>

            <p>
              {" "}
              <strong> - Colaboração em Equipe: </strong> Em muitos casos,
              programadores de web mobile trabalham em equipes
              multidisciplinares, colaborando com designers de interface,
              especialistas em UX (Experiência do Usuário) e gerentes de projeto
              para criar produtos móveis de alta qualidade.
            </p>

            <p>
              {" "}
              <strong> - Integração de Dados e APIs: </strong> Programadores de
              web mobile frequentemente trabalham com APIs (Interfaces de
              Programação de Aplicativos) para integrar dados externos, como
              informações de bancos de dados, mídia social ou serviços de
              terceiros, em seus aplicativos.{" "}
            </p>
          </div>
        </div>
        <div class="information">
          <h1 class="info-h1"> Informações </h1>
          <div class="info-plano">
            <li>
              <a href={web} target="_blank" download>
                {" "}
                Plano de aula 1{" "}
              </a>
            </li>
            <li>
              <a href={webDois} target="_blank" download>
                {" "}
                Programação das Aulas 1{" "}
              </a>
            </li>
            <li>
              <a href={web} target="_blank" download>
                {" "}
                Plano de Ensino 2{" "}
              </a>
            </li>
            <li>
              <a href={webDois} target="_blank" download>
                {" "}
                Programação das Aulas 2{" "}
              </a>
            </li>
          </div>
          <div class="info-align">
            <div class="info-alexandre">
              <img src={ale} alt="alexandre" />
              <div class="info-text-alexandre">
                <p> Prof. Alexandre dos Santos Mignon </p>
                <p> Contato: alexandre.mignon@mackenzie.br</p>
                <a
                  href="http://lattes.cnpq.br/6850069426509336"
                  target="_blank"
                >
                  {" "}
                  Currículo{" "}
                </a>
              </div>
            </div>
            <div class="info-leandro">
              <img src={joaquim} alt="alexandre" />
              <div class="info-text-leandro">
                <p> Prof. Joaquim Pessôa Filho </p>
                <p> Contato: joaquim@mackenzie.br</p>
                <a
                  href="http://lattes.cnpq.br/9286292529694339"
                  target="_blank"
                >
                  {" "}
                  Currículo{" "}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
