import React, { useState, useEffect } from "react";
import axios from "axios";
import clima from "../imgClima/clima.png";
import clima1 from "../imgClima/clima1.png";
import clima2 from "../imgClima/clima2.png";
import clima3 from "../imgClima/clima3.png";
import clima4 from "../imgClima/clima4.png";
import clima5 from "../imgClima/clima5.png";
import sol from "../imgClima/sol.png";
import lua from "../imgClima/lua.png";

const weatherDescriptions = {
  "clear sky": "Céu limpo",
  "few clouds": "Poucas nuvens",
  "scattered clouds": "Poucas nuvens",
  "broken clouds": "Nublado",
  "shower rain": "Chuva",
  rain: "Chuva",
  thunderstorm: "Tempestade",
  snow: "Neve",
  mist: "Névoa",
};

const Weather = () => {
  const [weatherData, setWeatherData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isDay, setIsDay] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          "https://api.openweathermap.org/data/2.5/weather",
          {
            params: {
              q: "Higienópolis, São Paulo, BR",
              appid: "caf20e41a2c8b3facaa4cc00ea488766",
              units: "metric",
            },
          },
        );

        setWeatherData(response.data);
      } catch (error) {
        console.error("Erro ao obter dados meteorológicos:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const checkDayTime = () => {
      const horaAtual = new Date().getUTCHours() - 3;
      setIsDay(horaAtual >= 6 && horaAtual < 18);
    };

    checkDayTime();
    const interval = setInterval(checkDayTime, 60000);

    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return <div>Carregando...</div>;
  }

  const condition = weatherData.weather[0].description.toLowerCase();
  let mensagemExtra;

  switch (condition) {
    case "clear sky":
      isDay
        ? (mensagemExtra = <img className="fotos" src={clima2} alt="" />)
        : (mensagemExtra = <img className="fotos" src={clima5} alt="" />);
      break;
    case "few clouds":
    case "scattered clouds":
      mensagemExtra = <img className="fotos" src={clima1} alt="" />;
      break;
    case "broken clouds":
      mensagemExtra = <img className="fotos" src={clima1} alt="" />;
      break;
    case "shower rain":
    case "rain":
      mensagemExtra = <img className="fotos" src={clima4} alt="" />;
      break;
    case "thunderstorm":
      mensagemExtra = <img className="fotos" src={clima3} alt="" />;
      break;
    case "mist":
      mensagemExtra = <img className="fotos" src={clima1} alt="" />;
      break;
    default:
      mensagemExtra = null;
  }

  const mensagemDiaNoite = isDay ? (
    <div className="env-astro">
      <img className="astro" src={sol} />
    </div>
  ) : (
    <div className="env-astro">
      <img className="astro" src={lua} />
    </div>
  );

  return (
    <div className="env-tudo">
      <div className="climaTempo">
        <div className="env-clima">
          <div className="ceu">{mensagemDiaNoite}</div>
          <p className="temp">{Math.round(weatherData.main.temp)}°C</p>
        </div>
        <p className="cond">{weatherDescriptions[condition]}</p>
        {mensagemExtra}
      </div>
    </div>
  );
};

export default Weather;
