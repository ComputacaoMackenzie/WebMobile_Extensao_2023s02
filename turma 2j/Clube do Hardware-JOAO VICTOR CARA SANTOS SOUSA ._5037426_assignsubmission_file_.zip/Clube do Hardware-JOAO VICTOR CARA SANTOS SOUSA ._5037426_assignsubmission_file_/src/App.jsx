import "./styles.css";
import "./mobile.css";
import React, { useRef, useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import Prog from "./pages/Prog";
import Web from "./pages/Web";
import logo from "./img/FCI.png";
import tia from "./img/tia.png";
import moodle from "./img/moodle.png";

export default function App() {
  const nav = useRef(null);
  const [cont, setCont] = useState(0);

  function OpenNav() {
    if (cont === 0) {
      nav.current.style.display = "block";
      setCont(cont + 1);
    } else {
      nav.current.style.display = "none";
      setCont(cont - 1);
    }
  }

  return (
    <Router>
      <div id="desktop" className="env-navbar">
        <div className="logo">
          <img src={logo} alt="" />
        </div>
        <div className="navbar">
          <Link to="/" className="link">
            Home
          </Link>
          <Link to="/prog" className="link">
            Programação de Sistemas I
          </Link>
          <Link to="/web" className="link">
            Web Mobile
          </Link>
          <a
            href="https://www3.mackenzie.br/tia/index.php"
            className="link icon"
            target="_blank"
          >
            <img src={tia} alt="" />
          </a>
          <a
            href="https://graduacao.mackenzie.br/login/index.php"
            className="link icon"
            target="_blank"
          >
            <img src={moodle} alt="" />
          </a>
        </div>
      </div>

      <div id="mobile" className="env-navbar">
        <div onClick={OpenNav} className="aba">
          <div className="line" />
          <div className="line" />
          <div className="line" />
        </div>
        <div className="logo logo-m">
          <img src={logo} alt="" />
        </div>
      </div>

      <div ref={nav} className="mobile-nav">
        <div onClick={OpenNav} className="aba mob">
          <div className="line" />
          <div className="line" />
          <div className="line" />
        </div>
        <Link onClick={OpenNav} to="/" className="link">
          Home
        </Link>
        <Link onClick={OpenNav} to="/prog" className="link">
          Programação de Sistemas I
        </Link>
        <Link onClick={OpenNav} to="/web" className="link">
          Web Mobile
        </Link>
        <a
          onClick={OpenNav}
          href="https://www3.mackenzie.br/tia/index.php"
          className="link icon"
          target="_blank"
        >
          <img src={tia} alt="" />
        </a>
        <a
          onClick={OpenNav}
          href="https://graduacao.mackenzie.br/login/index.php"
          className="link icon"
          target="_blank"
        >
          <img src={moodle} alt="" />
        </a>
      </div>

      <div className="footer">
        {" "}
        Desenvolvido por Lucas Meyer de Souza, Pedro Henrique Leite, Pedro
        Henrique Pereira Obeid e João Victor Cara
      </div>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/prog" element={<Prog />} />
        <Route path="/web" element={<Web />} />
      </Routes>
    </Router>
  );
}
